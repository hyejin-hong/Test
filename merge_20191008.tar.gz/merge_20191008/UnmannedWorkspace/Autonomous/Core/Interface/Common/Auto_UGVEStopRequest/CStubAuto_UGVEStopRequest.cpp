#include "CStubAuto_UGVEStopRequest.h"

namespace AUTONOMOUS
{
namespace Interface
{
namespace Common
{

CStubAuto_UGVEStopRequest::CStubAuto_UGVEStopRequest()
{
    m_snStubAuto_UGVEStopRequest = 0;
}

CStubAuto_UGVEStopRequest::~CStubAuto_UGVEStopRequest()
{ 

}

bool CStubAuto_UGVEStopRequest::CreateLogStubAuto_UGVEStopRequest(char *logName)
{
    char fname[1024] = "";
    sprintf(fname, "./%s.Auto_UGVEStopRequest", logName);

    return m_logStubAuto_UGVEStopRequest.Create(fname);
}

void CStubAuto_UGVEStopRequest::CloseLogStubAuto_UGVEStopRequest()
{
    m_logStubAuto_UGVEStopRequest.Destroy();
}


}
}
}
