#ifndef AUTO_PATHRESPONSE_H
#define AUTO_PATHRESPONSE_H

#include <CFW.h>
#include "../Common/Common.h"

namespace AUTONOMOUS
{
namespace Data
{
namespace Terrain
{

typedef struct _StAuto_PathResponse
{
    flt64_t     SyncTime;   // 동기화 시간
    uint8_t     GPPID;      // 전역경로 ID  0 ~ 255

    // 전역경로 Type
    // 1 : GlobalPath
    // 2 : IntersectionPath
    // 3 : RoadLinePath
    // 4 : FlowwingPath
    uint8_t     GPPType;
    uint16_t    GPPCount;   // GPP 생성 경로점 수 1 ~ 5000
    uint8_t     Result;     // GPP 처리 결과 0 : 정상 , 1 : 중복 수신
    uint8_t     Reserved[1];

} StAuto_PathResponse;


typedef struct _StAuto_PathResponseComm : public AUTONOMOUS::COMMLIB::Header, public StAuto_PathResponse
{
    virtual void setFrameData(uint8_t* buff)
    {
        buff = deserializeData(buff, SyncTime);
        buff = deserializeData(buff, GPPID);
        buff = deserializeData(buff, GPPType);
        buff = deserializeData(buff, GPPCount);
        buff = deserializeData(buff, Result);
        buff = deserializeData(buff, Reserved);
    }

    virtual void getFrameData(std::vector<uint8_t>& buff)
    {
        serializeData(buff, SyncTime);
        serializeData(buff, GPPID);
        serializeData(buff, GPPType);
        serializeData(buff, GPPCount);
        serializeData(buff, Result);
        serializeData(buff, Reserved);
    }

} StAuto_PathResponseComm;

}
}
}

#endif // AUTO_PATHRESPONSE_H
