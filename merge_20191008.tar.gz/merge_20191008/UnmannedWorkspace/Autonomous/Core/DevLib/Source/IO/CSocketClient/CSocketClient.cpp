#include "../../../Include/IO/CSocketClient/CSocketClient.h"

#include <stdio.h>
#include <arpa/inet.h>
#include <errno.h>

namespace DevLib
{
namespace IO
{

CObserverClient::CObserverClient()
{

}

CObserverClient::~CObserverClient()
{

}

CSocketClient::CSocketClient(CObserverClient *pObserver)
    : m_pObserverClient(pObserver)
{

}

void CSocketClient::Create(int port, char *ip, bool bAutoConnection)
{
    DevLib::IO::CSocketReceiver::Create(SOCK_STREAM);
    SetOptionReuse(true);

    m_sockAddrRemote.sin_family 		= AF_INET;
    m_sockAddrRemote.sin_port 			= htons(port);
    m_sockAddrRemote.sin_addr.s_addr	= inet_addr(ip);

    DevLib::CTimer::TimerStart(1000);
}

void CSocketClient::OnConnected(char *ip, int port)
{
    if( m_pObserverClient ) m_pObserverClient->OnConneted(ip, port);
}

void CSocketClient::OnDisconnected(char *ip, int port)
{
    if( m_pObserverClient ) m_pObserverClient->OnDisconneted(ip, port);
}

void CSocketClient::OnDataServer(char *ip, int port)
{
    if( m_pObserverClient ) m_pObserverClient->OnDataServer(ip, port);
}

void CSocketClient::OnTimer(void *)
{
    if( Connect(htons(GetSocketAddrRemote().sin_port), inet_ntoa(GetSocketAddrRemote().sin_addr) ))
    {
        DevLib::CTimer::TimerStop();
        OnConnected(inet_ntoa(GetSocketAddrRemote().sin_addr), htons(GetSocketAddrRemote().sin_port));
        DevLib::IO::CSocketReceiver::ServiceStart();
    }
}

void CSocketClient::OnReceive()
{
    // Data Alarm
    OnDataServer(inet_ntoa(GetSocketAddrRemote().sin_addr), htons(GetSocketAddrRemote().sin_port));
}

void CSocketClient::OnClosed()
{
    DevLib::IO::CSocketReceiver::Create(SOCK_STREAM);
    SetOptionReuse(true);
    DevLib::CTimer::TimerStart(1000);

    OnDisconnected(inet_ntoa(GetSocketAddrRemote().sin_addr), htons(GetSocketAddrRemote().sin_port));
}


}
}
