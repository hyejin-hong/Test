#include "CStubAuto_Obstacle.h"

namespace AUTONOMOUS
{
namespace Interface
{
namespace Terrain
{

CStubAuto_Obstacle::CStubAuto_Obstacle()
{
    m_snStubAuto_Obstacle = 0;
}

CStubAuto_Obstacle::~CStubAuto_Obstacle()
{ 

}

bool CStubAuto_Obstacle::CreateLogStubAuto_Obstacle(char *logName)
{
    char fname[1024] = "";
    sprintf(fname, "./%s.Auto_Obstacle", logName);

    return m_logStubAuto_Obstacle.Create(fname);
}

void CStubAuto_Obstacle::CloseLogStubAuto_Obstacle()
{
    m_logStubAuto_Obstacle.Destroy();
}


}
}
}
