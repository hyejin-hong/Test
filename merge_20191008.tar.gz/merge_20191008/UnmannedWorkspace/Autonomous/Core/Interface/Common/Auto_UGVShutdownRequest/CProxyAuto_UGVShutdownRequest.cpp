#include "CProxyAuto_UGVShutdownRequest.h"

namespace AUTONOMOUS
{
namespace Interface
{
namespace Common
{

CProxyAuto_UGVShutdownRequest::CProxyAuto_UGVShutdownRequest()
{
    AUTONOMOUS::COMMLIB::CFW::GetInstance().RegisterSub(MSG_CODE_COMMON_AUTO_UGVSHUTDOWNREQUEST, &CProxyAuto_UGVShutdownRequest::_OnAuto_UGVShutdownRequest, this);
}

CProxyAuto_UGVShutdownRequest::~CProxyAuto_UGVShutdownRequest()
{

}

bool CProxyAuto_UGVShutdownRequest::CreateLogProxyAuto_UGVShutdownRequest(char *logName)
{
    char fname[1024] = "";
    sprintf(fname, "./%s.Auto_UGVShutdownRequest", logName);

    return m_logProxyAuto_UGVShutdownRequest.Create(fname);
}

void CProxyAuto_UGVShutdownRequest::CloseLogProxyAuto_UGVShutdownRequest()
{
    m_logProxyAuto_UGVShutdownRequest.Destroy();
}

void CProxyAuto_UGVShutdownRequest::_OnAuto_UGVShutdownRequest(AUTONOMOUS::Data::Common::StAuto_UGVShutdownRequestComm& data)
{
    OnAuto_UGVShutdownRequest(data);
    if( m_logProxyAuto_UGVShutdownRequest.IsRun() )
    {
        m_vBuffProxyAuto_UGVShutdownRequest.clear();
        data.getFrameData(m_vBuffProxyAuto_UGVShutdownRequest);
        m_logProxyAuto_UGVShutdownRequest.WriteData(m_vBuffProxyAuto_UGVShutdownRequest.data(), m_vBuffProxyAuto_UGVShutdownRequest.size());
    }
}

}
}
}
