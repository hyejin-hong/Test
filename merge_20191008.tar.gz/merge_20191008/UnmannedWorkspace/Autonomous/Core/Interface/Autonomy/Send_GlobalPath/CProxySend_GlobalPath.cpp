#include "CProxySend_GlobalPath.h"

namespace AUTONOMOUS
{
namespace Interface
{
namespace Autonomy
{

CProxySend_GlobalPath::CProxySend_GlobalPath()
{
    AUTONOMOUS::COMMLIB::CFW::GetInstance().RegisterSub(MSG_CODE_AUTONOMY_SEND_GLOBALPATH, &CProxySend_GlobalPath::_OnSend_GlobalPath, this);
}

CProxySend_GlobalPath::~CProxySend_GlobalPath()
{

}

bool CProxySend_GlobalPath::CreateLogProxySend_GlobalPath(char *logName)
{
    char fname[1024] = "";
    sprintf(fname, "./%s.Send_GlobalPath", logName);

    return m_logProxySend_GlobalPath.Create(fname);
}

void CProxySend_GlobalPath::CloseLogProxySend_GlobalPath()
{
    m_logProxySend_GlobalPath.Destroy();
}

void CProxySend_GlobalPath::_OnSend_GlobalPath(AUTONOMOUS::Data::Autonomy::StSend_GlobalPathComm& data)
{
    OnSend_GlobalPath(data);
    if( m_logProxySend_GlobalPath.IsRun() )
    {
        m_vBuffProxySend_GlobalPath.clear();
        data.getFrameData(m_vBuffProxySend_GlobalPath);
        m_logProxySend_GlobalPath.WriteData(m_vBuffProxySend_GlobalPath.data(), m_vBuffProxySend_GlobalPath.size());
    }
}

}
}
}
