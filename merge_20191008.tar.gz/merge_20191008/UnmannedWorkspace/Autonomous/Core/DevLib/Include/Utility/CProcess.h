#ifndef CPROCESS_H
#define CPROCESS_H

#include "../Core/CThread/CThread.h"
#include "../Core/CTimer/CTimer.h"

namespace DevLib
{
namespace Utility
{

class CProcess : public DevLib::CThread
{
public:
	CProcess();

    void Create();
    void Start();       // 초기 대기상태에서 시작
    void Shutdown();    // 상태가 수행중 일때만 호출 가능
    void StartReportTimer(int ms = 1000);

    // 프로그램 시작시 초기화 : 완료후 대기 모드 로 전
    virtual void OnPreCreate() = 0;

    // 작업 함수 호출
    virtual void OnRunning() = 0;

    // 종료를 위한 호출
    virtual void OnShutdown() = 0;

    // 현재 상태를 보고 하기 위한 타이머
    virtual void OnTimerReportStatus() = 0;

    // 키보드 입력
    virtual void OnCommand(char value) = 0;

    // 현재 서비스 상태 확인
    inline bool IsRunning(){ return (IsRun() == true); }


    //
    void ServiceRun();

private :
    // 상태 보고용 타이머
    DevLib::CTimer              m_timerReportStatus;
    static void 		_OnTimerReportStatus(void*p ){ (reinterpret_cast<CProcess*>(p))->OnTimerReportStatus(); }   // OnTimerReportStatus(); 호

    void Run();
};

}
}

#endif // CPROCESS_H
