#ifndef CSTUBAUTO_PATHRESPONSE_H
#define CSTUBAUTO_PATHRESPONSE_H

#include <CFW.h>
#include <Core/DevLib/Include/IO/CLogWriter/CLogWriter.h>

// ICD Data
#include "../../../Data/Terrain/Auto_PathResponse.h"

namespace AUTONOMOUS
{
namespace Interface
{
namespace Terrain
{

class CStubAuto_PathResponse
{
public :
    CStubAuto_PathResponse();
    virtual ~CStubAuto_PathResponse();

    inline void WriteAuto_PathResponse(AUTONOMOUS::Data::Terrain::StAuto_PathResponseComm& data)
    {
        data.message_type   = MSG_TYPE_TERRAIN;
        data.message_ID     = MSG_CODE_TERRAIN_AUTO_PATHRESPONSE;
        data.QoS            = MSG_QOS_TERRAIN_AUTO_PATHRESPONSE;
        data.SN             = m_snStubAuto_PathResponse++;

        AUTONOMOUS::COMMLIB::CFW::GetInstance().Send(data);

        if( m_logStubAuto_PathResponse.IsRun() )
        {
            m_vBuffStubAuto_PathResponse.clear();
            data.getFrameData(m_vBuffStubAuto_PathResponse);
            m_logStubAuto_PathResponse.WriteData(m_vBuffStubAuto_PathResponse.data(), m_vBuffStubAuto_PathResponse.size());
        }
    }

    // Log
    bool CreateLogStubAuto_PathResponse(char* logName);
    void CloseLogStubAuto_PathResponse();

private:
    std::vector<uint8_t>   m_vBuffStubAuto_PathResponse;
    uint8_t                m_snStubAuto_PathResponse;
protected:
    DevLib::IO::CLogWriter m_logStubAuto_PathResponse;
};


}
}
}

#endif /* CSTUBAUTO_PATHRESPONSE_H */
