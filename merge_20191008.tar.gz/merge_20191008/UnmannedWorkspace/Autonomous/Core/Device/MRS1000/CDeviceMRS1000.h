/*
 * CDeviceSick.h
 *
 *  Created on: 2019. 4. 23.
 *      Author: fm
 */

#ifndef CDEVICEMRS1000_H_
#define CDEVICEMRS1000_H_

#include "CMRS1000Object.h"

namespace AUTONOMOUS
{
namespace Device
{
namespace MRS1000
{

class CDeviceMRS1000 : public AUTONOMOUS::Device::MRS1000::CObserverMRS1000
{
public:
    CDeviceMRS1000()
    : m_devMRS1000(this)
    {
    }

    virtual ~CDeviceMRS1000()
    {
    }

    virtual void OnMRS1000PackRecv( AUTONOMOUS::Device::MRS1000::StMRS1000Packet* pMRS1000Pack ) = 0;

    AUTONOMOUS::Device::MRS1000::CMRS1000* GetDeviceMRS1000() { return &m_devMRS1000; }

private :
    AUTONOMOUS::Device::MRS1000::CMRS1000 	m_devMRS1000;

    virtual void OnMRS1000Pack( AUTONOMOUS::Device::MRS1000::StMRS1000Packet* pMRS1000Pack )
    {
        OnMRS1000PackRecv(pMRS1000Pack);
    }
};

}
}
}

#endif /* CDEVICESMRS1000_H */
