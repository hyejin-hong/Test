#include "CProxySensorData_LIDAR_RthetaFrontRight.h"

namespace AUTONOMOUS
{
namespace Interface
{
namespace Sensor
{

CProxySensorData_LIDAR_RthetaFrontRight::CProxySensorData_LIDAR_RthetaFrontRight()
{
    AUTONOMOUS::COMMLIB::CFW::GetInstance().RegisterSub(MSG_CODE_SENSOR_SENSORDATA_LIDAR_RTHETAFRONTRIGHT, &CProxySensorData_LIDAR_RthetaFrontRight::_OnSensorData_LIDAR_RthetaFrontRight, this);
}

CProxySensorData_LIDAR_RthetaFrontRight::~CProxySensorData_LIDAR_RthetaFrontRight()
{

}

bool CProxySensorData_LIDAR_RthetaFrontRight::CreateLogProxySensorData_LIDAR_RthetaFrontRight(char *logName)
{
    char fname[1024] = "";
    sprintf(fname, "./%s.SensorData_LIDAR_RthetaFrontRight", logName);

    return m_logProxySensorData_LIDAR_RthetaFrontRight.Create(fname);
}

void CProxySensorData_LIDAR_RthetaFrontRight::CloseLogProxySensorData_LIDAR_RthetaFrontRight()
{
    m_logProxySensorData_LIDAR_RthetaFrontRight.Destroy();
}

void CProxySensorData_LIDAR_RthetaFrontRight::_OnSensorData_LIDAR_RthetaFrontRight(AUTONOMOUS::Data::Sensor::StSensorData_LIDAR_RthetaComm& data)
{
    OnSensorData_LIDAR_RthetaFrontRight(data);
    if( m_logProxySensorData_LIDAR_RthetaFrontRight.IsRun() )
    {
        m_vBuffProxySensorData_LIDAR_RthetaFrontRight.clear();
        data.getFrameData(m_vBuffProxySensorData_LIDAR_RthetaFrontRight);
        m_logProxySensorData_LIDAR_RthetaFrontRight.WriteData(m_vBuffProxySensorData_LIDAR_RthetaFrontRight.data(), m_vBuffProxySensorData_LIDAR_RthetaFrontRight.size());
    }
}

}
}
}
