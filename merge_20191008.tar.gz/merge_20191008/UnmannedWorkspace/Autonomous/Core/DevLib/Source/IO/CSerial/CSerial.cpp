#include "../../../Include/IO/CSerial/CSerial.h"

namespace DevLib
{
namespace IO
{

CSerial::CSerial(int serialFd)
    : m_fdSerial(serialFd)
{

}

CSerial::~CSerial()
{

}

bool CSerial::OpenPort(char* dev_name)
{
    bool bRet = false;

    m_fdSerial = open(dev_name, O_RDWR|O_NOCTTY , 0666);

    if(m_fdSerial != -1)
    {
        bRet = true;
    }

    return bRet;
}

bool CSerial::SetConfigurePort(speed_t baud_rate)
{
    bool bRet = false;

    if(tcgetattr(m_fdSerial, &m_ttycfg) != -1)
    {
        m_ttycfg.c_iflag = 0;               // clear input modes (raw)
        m_ttycfg.c_oflag = 0;               // clear output modes (raw)
        m_ttycfg.c_lflag = 0;               // clear line disciplines (raw)
        m_ttycfg.c_cc[VMIN] = 0;
        m_ttycfg.c_cc[VTIME] = 1;
        m_ttycfg.c_cflag = 0;               // clear out port control bits
        m_ttycfg.c_cflag = CLOCAL|CREAD;    // direct connect (no modem)

        m_ttycfg.c_cflag &= ~(CSIZE|CSTOPB|PARENB);

        // baud rate configurable thru
        // Set those baud rates for input and output
        cfsetispeed(&m_ttycfg, (speed_t)baud_rate);
        cfsetospeed(&m_ttycfg, (speed_t)baud_rate);

        // Set the parity bit
        m_ttycfg.c_cflag &= ~PARENB;          // parity disable

        // Set the character size
        m_ttycfg.c_cflag |= CS8;

        // Set the stop bits
        m_ttycfg.c_cflag &= ~CSTOPB;          // 1 stop bit

        tcflush(m_fdSerial, TCIFLUSH);

        // Program the port with our configuration
        if (::tcsetattr(m_fdSerial, TCSAFLUSH, &m_ttycfg) != -1)
        {
            bRet = true;
        }
    }

    if(bRet == false)
    {
        close(m_fdSerial);
    }

    return bRet;
}

void CSerial::DestroyPort()
{
    close(m_fdSerial);
    m_fdSerial = -1;
}

bool CSerial::IsCreated()
{
    return ( m_fdSerial != -1 ) ?  true : false;
}

int CSerial::Send(void* pData, int size)
{
    return write(m_fdSerial, pData, size);
}

int CSerial::Recv(void* pData, int size)
{
    return read(m_fdSerial, pData, size);
}

}
}
