#ifndef AUTO_PATHREQUEST_H
#define AUTO_PATHREQUEST_H

#include <CFW.h>
#include "../Common/Common.h"

namespace AUTONOMOUS
{
namespace Data
{
namespace Terrain
{

typedef struct _StAuto_PathRequest
{
    flt64_t     SyncTime;   // 동기화 시간
    uint8_t     GPPID;      // 전역경로 ID  0 ~ 255

    // 전역경로 Type
    // 1 : GlobalPath
    // 2 : ReturnPath
    // 3 : RoadLinePath
    // 4 : FlowwingPath
    uint8_t     GPPType;
    uint16_t    GPPCount;   // GPP 생성 경로점 수 1 ~ 5000

    StGPP       GPPResult[5000];

} StAuto_PathRequest;

typedef struct _StAuto_PathRequestComm : public AUTONOMOUS::COMMLIB::Header, public StAuto_PathRequest
{
    virtual void setFrameData(uint8_t* buff)
    {
        buff = deserializeData(buff, SyncTime);
        buff = deserializeData(buff, GPPID);
        buff = deserializeData(buff, GPPType);
        buff = deserializeData(buff, GPPCount);

        std::for_each(GPPResult, GPPResult + GPPCount, [&](StGPP& d)
        {
            buff = deserializeData(buff, d.Zone[0]);
            buff = deserializeData(buff, d.Zone[1]);
            buff = deserializeData(buff, d.North);
            buff = deserializeData(buff, d.East);
            buff = deserializeData(buff, d.CommandVelocity);
        });
    }

    virtual void getFrameData(std::vector<uint8_t>& buff)
    {
        serializeData(buff, SyncTime);
        serializeData(buff, GPPID);
        serializeData(buff, GPPType);
        serializeData(buff, GPPCount);

        std::for_each(GPPResult, GPPResult + GPPCount, [&](StGPP d)
        {
            serializeData(buff, d.Zone[0]);
            serializeData(buff, d.Zone[1]);
            serializeData(buff, d.North);
            serializeData(buff, d.East);
            serializeData(buff, d.CommandVelocity);
        });
    }

} StAuto_PathRequestComm;
}
}
}

#endif // AUTO_PATHREQUEST_H
