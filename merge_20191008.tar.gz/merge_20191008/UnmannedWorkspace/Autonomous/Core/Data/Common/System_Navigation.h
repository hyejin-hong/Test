#ifndef SYSTEM_NAVIGATION_H
#define SYSTEM_NAVIGATION_H

#include "../Common/Common.h"

namespace AUTONOMOUS
{
namespace Data
{
namespace Common
{

typedef struct _StSystemNavigation
{
    struct
    {
        // GPS 상태
        // 00 : Invalid 모드
        // 01 : GPS 1 모드 : HDOP 3 이상
        // 10 : GPS 2 모드 : HDOP 3 이하
        int8_t GPSStatus : 2;

        // 정렬 상태
        // 00 : 미동작
        // 01 : 미비
        // 10 : 정렬 중
        // 11 : 정상
        int8_t AlignStatus : 2;

        int8_t Reserved : 1;

        // IMU 상태
        // 0 : 정상
        // 1 : 비정상
        int8_t IMUStatus : 1;

        // 항법 모드
        // 11 : 통합항법 모드
        // 01 : INS 단독항법 모드
        int8_t NavigationMode : 2;

    } INS_GPS;

    // 항법 정렬시간
    uint16_t    AlignTime;

    flt64_t	TimeStamp;          // 시간정보

    struct
    {
        int8_t	Zone[2];            // Zone 정보

        // UTM 위치 정보
        flt64_t	East;               // 항법 East( Meter )
        flt64_t	North;              // 항법 North( Meter )
        flt64_t	Elevation;          // 항법 Elevation( Meter )
    } Position;

    // 플랫폼 자세
    struct
    {
        flt64_t	Roll;               // 항법 Roll ( -PI ~ PI )
        flt64_t	Pitch;              // 항법 Pitch ( -PI ~ PI )
        flt64_t	Heading;            // 항법 Heading ( -PI ~ PI )
    } Attitude;

    struct
    {
        // 선속도
        flt64_t	VelocityLinearX;    // 항법 X축 방향 선속도
        flt64_t	VelocityLinearY;	// 항법 Y축 방향 선속도
        flt64_t	VelocityLinearZ;	// 항법 Z축 방향 선속도

        // 각속도
        flt64_t	VelocityAngluarX;	// 항법 X축 방향 각속도
        flt64_t	VelocityAngluarY;	// 항법 Y축 방향 각속도
        flt64_t	VelocityAngluarZ;	// 항법 Z축 방향 각속도
    } Velocity;

} __attribute__((packed)) StSystemNavigation;


}
}
}

#endif // SYSTEM_NAVIGATION_H
