#ifndef SENSORDATA_IMAGE_H
#define SENSORDATA_IMAGE_H

#include <CFW.h>
#include "../Common/Common.h"
#include "../Common/Auto_Navigation.h"
#include "SensorType.h"

#include <stdio.h>

namespace AUTONOMOUS
{
namespace Data
{
namespace Sensor
{

/*
 * Image
 */


typedef struct _StSensorData_Image
{
    flt64_t                                         SyncTime;						// 동기화 시간
    AUTONOMOUS::Data::Common::StNavigationDetail    Navigation;						// 항법 정보
    uint16_t                                        SensorType;						// 센서 종류
    // 이미지 크기
    struct
    {
        uint16_t Width;                                                             // 영상의 폭(Default : 640)
        uint16_t Height;                                                            // 영상의 높이(Default : 480)
    } ImageSize;

    uint8_t                                         BitPixel;						// 픽셀 당 비트 수(Default : 24bit)
    uint8_t                                         Channels;						// 이미지 채널 수(Default : 3Ch)
    uint8_t                                         ImageCount;						// 이미지의 개수(Default : 1)

    uint8_t                                         ImageData[640*480*3];			// 영상 정보(Default : 640 * 480 * 24 * 3 * 1)

} StSensorData_Image;


typedef struct _StSensorData_ImageComm : public AUTONOMOUS::COMMLIB::Header, public StSensorData_Image
{
    virtual void setFrameData(uint8_t* buff)
    {
        buff = deserializeData(buff, SyncTime);

        buff = deserializeData(buff, Navigation.TimeStamp);
                std::for_each(Navigation.Zone, Navigation.Zone + 2, [&](int8_t& d)
        {
            buff = deserializeData(buff, d);
        });
        buff = deserializeData(buff, Navigation.East);
        buff = deserializeData(buff, Navigation.North);
        buff = deserializeData(buff, Navigation.Elevation);
        buff = deserializeData(buff, Navigation.Roll);
        buff = deserializeData(buff, Navigation.Pitch);
        buff = deserializeData(buff, Navigation.Heading);
        buff = deserializeData(buff, Navigation.VelocityLinearX);
        buff = deserializeData(buff, Navigation.VelocityLinearY);
        buff = deserializeData(buff, Navigation.VelocityLinearZ);
        buff = deserializeData(buff, Navigation.VelocityAngluarX);
        buff = deserializeData(buff, Navigation.VelocityAngluarY);
        buff = deserializeData(buff, Navigation.VelocityAngluarZ);

        buff = deserializeData(buff, SensorType);
        buff = deserializeData(buff, ImageSize.Width);
        buff = deserializeData(buff, ImageSize.Height);
        buff = deserializeData(buff, BitPixel);
        buff = deserializeData(buff, Channels);
        buff = deserializeData(buff, ImageCount);

        std::for_each(ImageData, ImageData + (ImageSize.Width * ImageSize.Height * (BitPixel/8) * Channels), [&](uint8_t& d)
        {
            buff = deserializeData(buff, d);
        });
    }

    virtual void getFrameData(std::vector<uint8_t>& buff)
    {
        serializeData(buff, SyncTime);

        serializeData(buff, Navigation.TimeStamp);
        std::for_each(Navigation.Zone, Navigation.Zone + 2, [&](int8_t d)
        {
            serializeData(buff, d);
        });
        serializeData(buff, Navigation.East);
        serializeData(buff, Navigation.North);
        serializeData(buff, Navigation.Elevation);
        serializeData(buff, Navigation.Roll);
        serializeData(buff, Navigation.Pitch);
        serializeData(buff, Navigation.Heading);
        serializeData(buff, Navigation.VelocityLinearX);
        serializeData(buff, Navigation.VelocityLinearY);
        serializeData(buff, Navigation.VelocityLinearZ);
        serializeData(buff, Navigation.VelocityAngluarX);
        serializeData(buff, Navigation.VelocityAngluarY);
        serializeData(buff, Navigation.VelocityAngluarZ);

        serializeData(buff, SensorType);
        serializeData(buff, ImageSize.Width);
        serializeData(buff, ImageSize.Height);
        serializeData(buff, BitPixel);
        serializeData(buff, Channels);
        serializeData(buff, ImageCount);

        std::for_each(ImageData, ImageData + (ImageSize.Width * ImageSize.Height * (BitPixel/8) * Channels), [&](uint8_t d)
        {
            serializeData(buff, d);
        });
    }

} StSensorData_ImageComm;

}
}
}

#endif // SENSORDATA_IMAGE_H
