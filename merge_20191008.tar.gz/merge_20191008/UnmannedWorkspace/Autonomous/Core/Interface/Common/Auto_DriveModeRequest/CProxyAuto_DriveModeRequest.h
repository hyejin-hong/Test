#ifndef CPROXYEAUTO_DRIVEMODEREQUEST_H
#define CPROXYEAUTO_DRIVEMODEREQUEST_H

#include <Core/DevLib/Include/IO/CLogWriter/CLogWriter.h>

// ICD Data
#include "../../../Data/Common/Auto_DriveModeRequest.h"

namespace AUTONOMOUS
{
namespace Interface
{
namespace Common
{

class CProxyAuto_DriveModeRequest
{
public :
    CProxyAuto_DriveModeRequest();
    virtual ~CProxyAuto_DriveModeRequest();

    virtual void OnAuto_DriveModeRequest(AUTONOMOUS::Data::Common::StAuto_DriveModeRequestComm& data) = 0;

    // Log
    bool CreateLogProxyAuto_DriveModeRequest(char* logName);
    void CloseLogProxyAuto_DriveModeRequest();

private:
    std::vector<uint8_t>   m_vBuffProxyAuto_DriveModeRequest;
protected:
    DevLib::IO::CLogWriter m_logProxyAuto_DriveModeRequest;

    void _OnAuto_DriveModeRequest(AUTONOMOUS::Data::Common::StAuto_DriveModeRequestComm& data);
};


}
}
}

#endif /* CPROXYEAUTO_DRIVEMODEREQUEST_H */
