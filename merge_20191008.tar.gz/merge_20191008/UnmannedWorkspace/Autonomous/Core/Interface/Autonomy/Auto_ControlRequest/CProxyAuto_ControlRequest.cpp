#include "CProxyAuto_ControlRequest.h"

namespace AUTONOMOUS
{
namespace Interface
{
namespace Autonomy
{

CProxyAuto_ControlRequest::CProxyAuto_ControlRequest()
{
    AUTONOMOUS::COMMLIB::CFW::GetInstance().RegisterSub(MSG_CODE_AUTONOMY_AUTO_CONTROLREQUEST, &CProxyAuto_ControlRequest::_OnAuto_ControlRequest, this);
}

CProxyAuto_ControlRequest::~CProxyAuto_ControlRequest()
{

}

bool CProxyAuto_ControlRequest::CreateLogProxyAuto_ControlRequest(char *logName)
{
    char fname[1024] = "";
    sprintf(fname, "./%s.Auto_ControlRequest", logName);

    return m_logProxyAuto_ControlRequest.Create(fname);
}

void CProxyAuto_ControlRequest::CloseLogProxyAuto_ControlRequest()
{
    m_logProxyAuto_ControlRequest.Destroy();
}

void CProxyAuto_ControlRequest::_OnAuto_ControlRequest(AUTONOMOUS::Data::Autonomy::StAuto_ControlRequestComm& data)
{
    OnAuto_ControlRequest(data);
    if( m_logProxyAuto_ControlRequest.IsRun() )
    {
        m_vBuffProxyAuto_ControlRequest.clear();
        data.getFrameData(m_vBuffProxyAuto_ControlRequest);
        m_logProxyAuto_ControlRequest.WriteData(m_vBuffProxyAuto_ControlRequest.data(), m_vBuffProxyAuto_ControlRequest.size());
    }
}

}
}
}
