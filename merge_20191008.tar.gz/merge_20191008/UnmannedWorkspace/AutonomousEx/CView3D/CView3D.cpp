#include "CView3D.h"

CView3D::CView3D(const QWidget *parent, char *titleName)
    : QGLWidget(const_cast<QWidget*>(parent))
{
    m_xRot = 0;
    m_yRot = 0;
    m_zRot = 0;

    m_scale = 0;

    connect(this, SIGNAL(RotationX(float)), this, SLOT(OnRotationX(float)));
    connect(this, SIGNAL(RotationY(float)), this, SLOT(OnRotationY(float)));
    connect(this, SIGNAL(RotationZ(float)), this, SLOT(OnRotationZ(float)));
    connect(this, SIGNAL(AddModel(StModel)), this, SLOT(OnAddModel(StModel)));
    connect(this, SIGNAL(Redraw()), this, SLOT(OnRedraw()));

    setToolTip(QString(titleName));
    setWindowTitle(QString(titleName));
}

void CView3D::initializeGL()
{
    qglClearColor(Qt::black);

    glColor3f(1.0, 1.0, 1.0);

    glShadeModel(GL_SMOOTH);
    glEnable(GL_DEPTH_TEST);
    glDepthFunc(GL_LEQUAL);
    glHint(GL_PERSPECTIVE_CORRECTION_HINT, GL_NICEST);

//    GLfloat AmbientColor[]    = { 0.1F, 0.1F, 0.1F, 0.0F };
//    GLfloat DiffuseColor[]    = { 0.6F, 0.6F, 0.6F, 0.0F };
//    GLfloat SpecularColor[]   = { 0.0F, 0.0F, 0.0F, 0.0F };
//    GLfloat Position1[]        = { 1.0F, 1.0F, 1.0F, 1.0F };
//    GLfloat Position2[]        = { -1.0F, -1.0F, 1.0F, 1.0F };

//    glLightfv(GL_LIGHT0, GL_AMBIENT, AmbientColor);
//    glLightfv(GL_LIGHT0, GL_DIFFUSE, DiffuseColor);
//    glLightfv(GL_LIGHT0, GL_SPECULAR, SpecularColor);
//    glLightfv(GL_LIGHT0, GL_POSITION, Position1);

//    glLightfv(GL_LIGHT1, GL_AMBIENT, AmbientColor);
//    glLightfv(GL_LIGHT1, GL_DIFFUSE, DiffuseColor);
//    glLightfv(GL_LIGHT1, GL_SPECULAR, SpecularColor);
//    glLightfv(GL_LIGHT1, GL_POSITION, Position2);

//    glEnable(GL_LIGHTING);
//    glEnable(GL_LIGHT0);
//    glEnable(GL_LIGHT1);

//    glColorMaterial(GL_FRONT, GL_AMBIENT_AND_DIFFUSE);
    glEnable(GL_COLOR_MATERIAL);
}

void CView3D::paintGL()
{
    glClear(GL_DEPTH_BUFFER_BIT | GL_COLOR_BUFFER_BIT);

    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();

    glRotatef(m_xRot, 1.0f, 0.0f, 0.0f);
    glRotatef(m_yRot, 0.0f, 1.0f, 0.0f);
    glRotatef(m_zRot, 0.0f, 0.0f, 1.0f);

    glScalef(m_scale, m_scale, m_scale);


    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();

    for(int i =0 ; i < m_modelsMem.size(); i++ )
    {

        glPushMatrix();


//        QMatrix4x4 mat;
//        mat.setToIdentity();
//        mat.rotate(m_modelsMem[i].pitch, 1.0f, 0.0f, 0.0f);
//        mat.rotate(m_modelsMem[i].roll,  0.0f, 1.0f, 0.0f);
//        mat.rotate(m_modelsMem[i].yaw,   0.0f, 0.0f, 1.0f);
//        mat.translate(m_modelsMem[i].x, m_modelsMem[i].y, m_modelsMem[i].z);


//        glMultMatrixf(mat.data());


        glRotatef(m_modelsMem[i].yaw,   0.0f, 0.0f, 1.0f);
        glRotatef(m_modelsMem[i].pitch, 1.0f, 0.0f, 0.0f);
        glRotatef(m_modelsMem[i].roll,  0.0f, 1.0f, 0.0f);

        glTranslatef(m_modelsMem[i].x, m_modelsMem[i].y, m_modelsMem[i].z);

        glEnableClientState(GL_VERTEX_ARRAY);
        glEnableClientState(GL_COLOR_ARRAY);

        glVertexPointer(3, GL_FLOAT, 0, &m_modelsMem[i].points[0]);
        glColorPointer(3, GL_FLOAT, 0, &m_modelsMem[i].colors[0]);
        glDrawArrays(GL_POINTS, 0, m_modelsMem[i].points.size());

        glPopMatrix();
        glDisableClientState(GL_COLOR_ARRAY);
        glDisableClientState(GL_VERTEX_ARRAY);

        glPopMatrix();

    }
}

void CView3D::resizeGL(int width, int height)
{
    QGLWidget::makeCurrent();
    glViewport(0, 0, static_cast<GLint>(width), static_cast<GLint>(height));
    m_scale = 1.f/(float)width;
    QGLWidget::doneCurrent();
}

void CView3D::mousePressEvent(QMouseEvent *event)
{
    lastPos = event->pos();
}

void CView3D::mouseMoveEvent(QMouseEvent *event)
{
    float dx = event->x() - lastPos.x();
    float dy = event->y() - lastPos.y();

    if ((event->buttons() & Qt::LeftButton) == Qt::LeftButton)
    {
        OnRotationX(m_xRot + dy);
        OnRotationY(m_yRot + dx);
    } else if ((event->buttons() & Qt::RightButton) == Qt::RightButton )
    {
        OnRotationX(m_zRot + dx);
    }
    else
    {
        /* exception */
    }

    lastPos = event->pos();
}

void CView3D::wheelEvent(QWheelEvent *event)
{
    if(event->delta() > 0)
    {
        m_scale *= 1.05f;
    }
    else
    {
        m_scale *= 0.95f;
    }

    updateGL();
}

static void qNormalizeAngle(float &angle)
{
    while (angle < 0)
    {
        angle += 360 * 16;
    }
    while (angle > 360 * 16)
    {
        angle -= 360 * 16;
    }
}

void CView3D::OnRotationX(float angle)
{
    qNormalizeAngle(angle);
    if (angle != m_xRot) {
        m_xRot = angle;
        updateGL();
    }
}

void CView3D::OnRotationY(float angle)
{
    qNormalizeAngle(angle);
    if (angle != m_yRot) {
        m_yRot = angle;
        updateGL();
    }
}

void CView3D::OnRotationZ(float angle)
{
    qNormalizeAngle(angle);
    if (angle != m_zRot) {
        m_zRot = angle;
        updateGL();
    }
}

void CView3D::OnAddModel(StModel model)
{
    m_models.push_back(model);
}

void CView3D::OnRedraw()
{
    m_modelsMem = m_models;
    m_models.clear();
    updateGL();
}
