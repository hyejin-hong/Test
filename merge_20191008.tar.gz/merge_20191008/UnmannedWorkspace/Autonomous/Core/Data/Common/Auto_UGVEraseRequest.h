#ifndef AUTO_ERASEREQUEST_H
#define AUTO_ERASEREQUEST_H

#include <CFW.h>
#include "../Common/Common.h"

namespace AUTONOMOUS
{
namespace Data
{
namespace Common
{

typedef struct _StAuto_EraseRequest
{
    flt64_t     SyncTime;   // 동기화 시간

} StAuto_UGVEraseRequest;

typedef struct _StAuto_EraseRequestComm : public AUTONOMOUS::COMMLIB::Header, public StAuto_UGVEraseRequest
{
    virtual void setFrameData(uint8_t* buff)
    {
        buff = deserializeData(buff, SyncTime);
    }

    virtual void getFrameData(std::vector<uint8_t>& buff)
    {
        serializeData(buff, SyncTime);
    }

} StAuto_UGVEraseRequestComm;

}
}
}

#endif // AUTO_ERASEREQUEST_H
