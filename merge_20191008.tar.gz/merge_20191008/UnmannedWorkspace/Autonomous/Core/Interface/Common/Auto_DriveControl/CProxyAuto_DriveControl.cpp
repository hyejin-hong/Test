#include "CProxyAuto_DriveControl.h"

namespace AUTONOMOUS
{
namespace Interface
{
namespace Common
{

CProxyAuto_DriveControl::CProxyAuto_DriveControl()
{
    AUTONOMOUS::COMMLIB::CFW::GetInstance().RegisterSub(MSG_CODE_COMMON_AUTO_DRIVECONTROL, &CProxyAuto_DriveControl::_OnAuto_DriveControl, this);
}

CProxyAuto_DriveControl::~CProxyAuto_DriveControl()
{

}

bool CProxyAuto_DriveControl::CreateLogProxyAuto_DriveControl(char *logName)
{
    char fname[1024] = "";
    sprintf(fname, "./%s.Auto_DriveControl", logName);

    return m_logProxyAuto_DriveControl.Create(fname);
}

void CProxyAuto_DriveControl::CloseLogProxyAuto_DriveControl()
{
    m_logProxyAuto_DriveControl.Destroy();
}

void CProxyAuto_DriveControl::_OnAuto_DriveControl(AUTONOMOUS::Data::Common::StAuto_DriveControlComm& data)
{
    OnAuto_DriveControl(data);
    if( m_logProxyAuto_DriveControl.IsRun() )
    {
        m_vBuffProxyAuto_DriveControl.clear();
        data.getFrameData(m_vBuffProxyAuto_DriveControl);
        m_logProxyAuto_DriveControl.WriteData(m_vBuffProxyAuto_DriveControl.data(), m_vBuffProxyAuto_DriveControl.size());
    }
}

}
}
}
