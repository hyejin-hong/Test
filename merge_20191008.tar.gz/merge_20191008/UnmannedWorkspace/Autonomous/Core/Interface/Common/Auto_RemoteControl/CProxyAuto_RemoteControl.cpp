#include "CProxyAuto_RemoteControl.h"

namespace AUTONOMOUS
{
namespace Interface
{
namespace Common
{

CProxyAuto_RemoteControl::CProxyAuto_RemoteControl()
{
    AUTONOMOUS::COMMLIB::CFW::GetInstance().RegisterSub(MSG_CODE_COMMON_AUTO_REMOTECONTROL, &CProxyAuto_RemoteControl::_OnAuto_RemoteControl, this);
}

CProxyAuto_RemoteControl::~CProxyAuto_RemoteControl()
{

}

bool CProxyAuto_RemoteControl::CreateLogProxyAuto_RemoteControl(char *logName)
{
    char fname[1024] = "";
    sprintf(fname, "./%s.Auto_RemoteControl", logName);

    return m_logProxyAuto_RemoteControl.Create(fname);
}

void CProxyAuto_RemoteControl::CloseLogProxyAuto_RemoteControl()
{
    m_logProxyAuto_RemoteControl.Destroy();
}

void CProxyAuto_RemoteControl::_OnAuto_RemoteControl(AUTONOMOUS::Data::Common::StAuto_RemoteControlComm& data)
{
    OnAuto_RemoteControl(data);
    if( m_logProxyAuto_RemoteControl.IsRun() )
    {
        m_vBuffProxyAuto_RemoteControl.clear();
        data.getFrameData(m_vBuffProxyAuto_RemoteControl);
        m_logProxyAuto_RemoteControl.WriteData(m_vBuffProxyAuto_RemoteControl.data(), m_vBuffProxyAuto_RemoteControl.size());
    }
}

}
}
}
