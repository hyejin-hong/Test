#ifndef CSOCKETCLIENT_H
#define CSOCKETCLIENT_H

#include "../../Core/CMutex/CMutex.h"
#include "../CSocketReceiver/CSocketReceiver.h"
#include "../../Core/CTimer/CTimer.h"
#include <list>

namespace DevLib
{
namespace IO
{

class CObserverClient
{
public :
    CObserverClient();
    virtual ~CObserverClient();

    virtual void OnConneted(char* ip, int port) = 0;
    virtual void OnDisconneted(char* ip, int port) = 0;
    virtual void OnDataServer(char* ip, int port) = 0;
};

class CSocketClient
        : public DevLib::IO::CSocketReceiver
        , public DevLib::CTimer
{
public:
    CSocketClient(CObserverClient* pObserver = nullptr);

    void Create(int port, char* ip, bool bAutoConnection = true);

    virtual void OnConnected(char* ip, int port);
    virtual void OnDisconnected(char* ip, int port);
    virtual void OnDataServer(char* ip, int port);

private:
    virtual void OnTimer(void* p);
    virtual void OnReceive();
    virtual void OnClosed();

    CObserverClient*    m_pObserverClient;

};

}
}
#endif // CSOCKETCLIENT_H
