#include "CStubAuto_Navigation.h"

namespace AUTONOMOUS
{
namespace Interface
{
namespace Common
{

CStubAuto_Navigation::CStubAuto_Navigation()
{
    m_snStubAuto_Navigation = 0;
}

CStubAuto_Navigation::~CStubAuto_Navigation()
{ 

}

bool CStubAuto_Navigation::CreateLogStubAuto_Navigation(char *logName)
{
    char fname[1024] = "";
    sprintf(fname, "./%s.Auto_Navigation", logName);

    return m_logStubAuto_Navigation.Create(fname);
}

void CStubAuto_Navigation::CloseLogStubAuto_Navigation()
{
    m_logStubAuto_Navigation.Destroy();
}


}
}
}
