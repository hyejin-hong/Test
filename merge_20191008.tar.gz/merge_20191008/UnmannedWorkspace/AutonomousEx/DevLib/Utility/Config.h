#ifndef CONFIG_H
#define CONFIG_H

#include "Mathematics.h"
#include <QCoreApplication>
#include <QFileInfo>
#include <QSettings>
#include <QVariant>
#include <QString>


namespace DevLib { namespace Utility {

char* GetProcessorName();
char* GetMakeConfigName();

int GetConfigInt(const char* GroupName, const char* Idendity, int defValue, const char* configName = "./Config.ini");
void GetConfigString(const char* GroupName, const char* Idendity, const char* defValue, char* resultValue, int resultSize, const char* configName = "./Config.ini");
//void GetConfigString(const char* GroupName, const char* Idendity, const char* defValue, QString& str, const char* configName = "./Config.ini");
double GetConfigDouble(const char* GroupName, const char* Idendity, double defValue, const char* configName = "./Config.ini");

void SetConfigInt(const char* GroupName, const char* Idendity, int value, const char* configName = "./Config.ini");
void SetConfigString(const char* GroupName, const char* Idendity, const char* value, const char* configName = "./Config.ini");
void SetConfigDouble(const char* GroupName, const char* Idendity, double value, const char* configName = "./Config.ini");


static char __g_processor_name__[512] = "";
static char __g_config_name__[512] = "";

char* GetProcessorName()
{
    if( strlen(__g_processor_name__) == 0 )
    {
        QString pName = QFileInfo( QCoreApplication::applicationFilePath() ).fileName();
        strcpy(__g_processor_name__, pName.toLatin1().data());

        QString cName = pName;
        int pos = cName.indexOf("exe");
        if( pos >= 0 )
        {
            cName.replace("exe", "ini");
            cName.prepend("./");
        }
        else
        {
            cName.append(".ini");
            cName.prepend("./");
        }

        strcpy(__g_config_name__, cName.toLatin1().data());
    }

    return __g_processor_name__;
}

char* GetMakeConfigName()
{
    if( strlen(__g_config_name__) == 0 ) GetProcessorName();
    return __g_config_name__;
}

int GetConfigInt(const char *GroupName, const char *Idendity, int defValue, const char *configName)
{
    int rVal = defValue;

    QString str;
    str.sprintf("%d", defValue);

    QSettings config(configName, QSettings::IniFormat);

    config.beginGroup(GroupName);
    QVariant var = config.value(Idendity, defValue);
    config.endGroup();

    if( str.compare(var.toString()) == 0 )
    {
        SetConfigInt(GroupName, Idendity, defValue, configName);
    }
    else
    {
        rVal = var.toInt();
    }


    return rVal;
}

void GetConfigString(const char *GroupName, const char *Idendity, const char *defValue, char *resultValue, int resultSize, const char *configName)
{
    QString str;
    str.sprintf("%s", defValue);

    QSettings config(configName, QSettings::IniFormat);
    config.beginGroup(GroupName);
    QVariant var = config.value(Idendity, defValue);
    config.endGroup();

    if( str.compare(var.toString()) == 0 )
    {
        SetConfigString(GroupName, Idendity, defValue, configName);
    }
    else
    {
        str = var.toString();
    }

    if( str.compare(defValue) == 0 ) SetConfigString(GroupName, Idendity, defValue, configName);
    if( resultSize < str.length() ) printf("resultSize Error\n");
    else strcpy(resultValue, str.toLatin1().data());

}

//void GetConfigString(const char *GroupName, const char *Idendity, const char *defValue, QString &str, const char *configName)
//{
//    QString _str;
//    _str.sprintf("%d", defValue);

//    QSettings config(configName, QSettings::IniFormat);
//    config.beginGroup(GroupName);
//    QVariant var = config.value(Idendity, defValue);
//    config.endGroup();

//    if( _str.compare(var.toString()) == 0 )
//    {
//        SetConfigString(GroupName, Idendity, defValue, configName);
//    }
//    else
//    {
//        str = var.toString();
//    }
//}

double GetConfigDouble(const char *GroupName, const char *Idendity, double defValue, const char *configName)
{
    double rVal = defValue;

    QSettings config(configName, QSettings::IniFormat);
    config.beginGroup(GroupName);
    QVariant var = config.value(Idendity, defValue);
    config.endGroup();
    if( IsEqual(rVal, var.toDouble()) )
    {
        SetConfigDouble(GroupName, Idendity, defValue, configName);
    }
    else
    {
        rVal = var.toDouble();
    }

    return rVal;
}

void SetConfigInt(const char *GroupName, const char *Idendity, int value, const char *configName)
{
    QSettings config(QString(configName), QSettings::IniFormat);
    config.beginGroup(GroupName);
    config.setValue(Idendity, value);
    config.endGroup();
}

void SetConfigString(const char *GroupName, const char *Idendity, const char *value, const char *configName)
{
    QSettings config(QString(configName), QSettings::IniFormat);
    config.beginGroup(GroupName);
    config.setValue(Idendity, value);
    config.endGroup();
}

void SetConfigDouble(const char *GroupName, const char *Idendity, double value, const char *configName)
{
    QSettings config(QString(configName), QSettings::IniFormat);
    config.beginGroup(GroupName);
    config.setValue(Idendity, value);
    config.endGroup();
}
} }


#endif // CONFIG_H
