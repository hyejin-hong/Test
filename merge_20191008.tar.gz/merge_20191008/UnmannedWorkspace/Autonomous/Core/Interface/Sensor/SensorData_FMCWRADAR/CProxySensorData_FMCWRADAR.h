#ifndef CPROXYESENSORDATA_FMCWRADAR_H
#define CPROXYESENSORDATA_FMCWRADAR_H

#include <Core/DevLib/Include/IO/CLogWriter/CLogWriter.h>

// ICD Data
#include "../../../Data/Sensor/SensorData_FMCWRADAR.h"

namespace AUTONOMOUS
{
namespace Interface
{
namespace Sensor
{

class CProxySensorData_FMCWRADAR
{
public :
    CProxySensorData_FMCWRADAR();
    virtual ~CProxySensorData_FMCWRADAR();

    virtual void OnSensorData_FMCWRADAR(AUTONOMOUS::Data::Sensor::StSensorData_FMCWRADARComm& data) = 0;

    // Log
    bool CreateLogProxySensorData_FMCWRADAR(char* logName);
    void CloseLogProxySensorData_FMCWRADAR();

private:
    std::vector<uint8_t>   m_vBuffProxySensorData_FMCWRADAR;
protected:
    DevLib::IO::CLogWriter m_logProxySensorData_FMCWRADAR;

    void _OnSensorData_FMCWRADAR(AUTONOMOUS::Data::Sensor::StSensorData_FMCWRADARComm& data);
};


}
}
}

#endif /* CPROXYESENSORDATA_FMCWRADAR_H */
