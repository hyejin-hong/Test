#include "CProxyMapData_PerceptionResult.h"

namespace AUTONOMOUS
{
namespace Interface
{
namespace Terrain
{

CProxyMapData_PerceptionResult::CProxyMapData_PerceptionResult()
{
    AUTONOMOUS::COMMLIB::CFW::GetInstance().RegisterSub(MSG_CODE_TERRAIN_MAPDATA_PERCEPTIONRESULT, &CProxyMapData_PerceptionResult::_OnMapData_PerceptionResult, this);
}

CProxyMapData_PerceptionResult::~CProxyMapData_PerceptionResult()
{

}

bool CProxyMapData_PerceptionResult::CreateLogProxyMapData_PerceptionResult(char *logName)
{
    char fname[1024] = "";
    sprintf(fname, "./%s.MapData_PerceptionResult", logName);

    return m_logProxyMapData_PerceptionResult.Create(fname);
}

void CProxyMapData_PerceptionResult::CloseLogProxyMapData_PerceptionResult()
{
    m_logProxyMapData_PerceptionResult.Destroy();
}

void CProxyMapData_PerceptionResult::_OnMapData_PerceptionResult(AUTONOMOUS::Data::Terrain::StMapData_PerceptionResultComm& data)
{
    OnMapData_PerceptionResult(data);
    if( m_logProxyMapData_PerceptionResult.IsRun() )
    {
        m_vBuffProxyMapData_PerceptionResult.clear();
        data.getFrameData(m_vBuffProxyMapData_PerceptionResult);
        m_logProxyMapData_PerceptionResult.WriteData(m_vBuffProxyMapData_PerceptionResult.data(), m_vBuffProxyMapData_PerceptionResult.size());
    }
}

}
}
}
