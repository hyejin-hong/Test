#ifndef CPROXYEAUTO_UGVSHUTDOWNREQUEST_H
#define CPROXYEAUTO_UGVSHUTDOWNREQUEST_H

#include <Core/DevLib/Include/IO/CLogWriter/CLogWriter.h>

// ICD Data
#include "../../../Data/Common/Auto_UGVShutdownRequest.h"

namespace AUTONOMOUS
{
namespace Interface
{
namespace Common
{

class CProxyAuto_UGVShutdownRequest
{
public :
    CProxyAuto_UGVShutdownRequest();
    virtual ~CProxyAuto_UGVShutdownRequest();

    virtual void OnAuto_UGVShutdownRequest(AUTONOMOUS::Data::Common::StAuto_UGVShutdownRequestComm& data) = 0;

    // Log
    bool CreateLogProxyAuto_UGVShutdownRequest(char* logName);
    void CloseLogProxyAuto_UGVShutdownRequest();

private:
    std::vector<uint8_t>   m_vBuffProxyAuto_UGVShutdownRequest;
protected:
    DevLib::IO::CLogWriter m_logProxyAuto_UGVShutdownRequest;

    void _OnAuto_UGVShutdownRequest(AUTONOMOUS::Data::Common::StAuto_UGVShutdownRequestComm& data);
};


}
}
}

#endif /* CPROXYEAUTO_UGVSHUTDOWNREQUEST_H */
