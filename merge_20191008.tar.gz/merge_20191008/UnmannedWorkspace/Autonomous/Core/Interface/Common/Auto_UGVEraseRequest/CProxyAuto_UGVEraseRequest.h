#ifndef CPROXYEAUTO_UGVERASEREQUEST_H
#define CPROXYEAUTO_UGVERASEREQUEST_H

#include <Core/DevLib/Include/IO/CLogWriter/CLogWriter.h>

// ICD Data
#include "../../../Data/Common/Auto_UGVEraseRequest.h"

namespace AUTONOMOUS
{
namespace Interface
{
namespace Common
{

class CProxyAuto_UGVEraseRequest
{
public :
    CProxyAuto_UGVEraseRequest();
    virtual ~CProxyAuto_UGVEraseRequest();

    virtual void OnAuto_UGVEraseRequest(AUTONOMOUS::Data::Common::StAuto_UGVEraseRequestComm& data) = 0;

    // Log
    bool CreateLogProxyAuto_UGVEraseRequest(char* logName);
    void CloseLogProxyAuto_UGVEraseRequest();

private:
    std::vector<uint8_t>   m_vBuffProxyAuto_UGVEraseRequest;
protected:
    DevLib::IO::CLogWriter m_logProxyAuto_UGVEraseRequest;

    void _OnAuto_UGVEraseRequest(AUTONOMOUS::Data::Common::StAuto_UGVEraseRequestComm& data);
};


}
}
}

#endif /* CPROXYEAUTO_UGVERASEREQUEST_H */
