#ifndef CPROXYEMAPDATA_PROBABILITYFUSED_H
#define CPROXYEMAPDATA_PROBABILITYFUSED_H

#include <Core/DevLib/Include/IO/CLogWriter/CLogWriter.h>

// ICD Data
#include "../../../Data/Terrain/MapData_Probability.h"

namespace AUTONOMOUS
{
namespace Interface
{
namespace Terrain
{

class CProxyMapData_ProbabilityFused
{
public :
    CProxyMapData_ProbabilityFused();
    virtual ~CProxyMapData_ProbabilityFused();

    virtual void OnMapData_ProbabilityFused(AUTONOMOUS::Data::Terrain::StMapData_ProbabilityComm& data) = 0;

    // Log
    bool CreateLogProxyMapData_ProbabilityFused(char* logName);
    void CloseLogProxyMapData_ProbabilityFused();

private:
    std::vector<uint8_t>   m_vBuffProxyMapData_ProbabilityFused;
protected:
    DevLib::IO::CLogWriter m_logProxyMapData_ProbabilityFused;

    void _OnMapData_ProbabilityFused(AUTONOMOUS::Data::Terrain::StMapData_ProbabilityComm& data);
};


}
}
}

#endif /* CPROXYEMAPDATA_PROBABILITYFUSED_H */
