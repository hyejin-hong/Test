/*
 * Report_Component_Status.h
 *
 *  Created on: 2019. 4. 4.
 *      Author: fme
 */

#ifndef REPORT_COMPONENTSTATUS_H
#define REPORT_COMPONENTSTATUS_H

#include <CFW.h>
#include "../Common/Common.h"

namespace AUTONOMOUS
{
namespace Data
{
namespace Common
{

// SoftwareID
typedef enum
{
    SOFTWARE_ID_AUTONOMOUS_MANAGER                  = 1,	// 자율주행 매니저
    SOFTWARE_ID_NAVIGATION_REPEATER                 = 2,	// 항법 Repeater

    SOFTWARE_ID_3D_LIDAR_IF                         = 11,	// 3D LIDAR I/F
    SOFTWARE_ID_2D_LIDAR_IF                         = 12,	// 2D LIDAR I/F
    SOFTWARE_ID_FMCW_IF                             = 13,	// FMCW I/F
    SOFTWARE_ID_CAMERA_IF                           = 14,	// CAMERA I/F

    SOFTWARE_ID_3D_LIDAR_TRAVELABILITY           	= 21,	// 3D LIDAR기반 주행영역분석
    SOFTWARE_ID_3D_LIDAR_TRAVELABILITY_FUSED     	= 22,	// 주행영역 융합
    SOFTWARE_ID_OBSTOCK_DETECTION_TRACKING          = 23,	// 장애물 탐지/추적
    SOFTWARE_ID_PERCEPTION_RESULT                   = 24,	// 정적/동적 환경 융합
    SOFTWARE_ID_LANE_DEPARTURE_PREVENTION           = 25,	// 차선이탈방지

    SOFTWARE_ID_LOCAL_PATHPLAN                      = 31,	// 지역경로계획
    SOFTWARE_ID_FOLLOW_PATH                         = 32,	// 경로추종
    SOFTWARE_ID_ANTI_COLLISION                      = 33,	// 충돌방지

    SOFTWARE_ID_LOG_MANAGER                         = 41,	// Log Manager
    SOFTWARE_ID_AUTONOMOUS_DEBUG                    = 42	// 자율주행 Debug
} eSoftwareID;

// SoftwareStatus
typedef enum
{
    STANDBY                         = 1,        // 전원 On / 대기
    NORMAL                          = 2,        // 전원 On / 정상(구동) (Default)
    UNNORMAL                        = 3         // 전원 On / 비정상
} eSoftwareStatus;

typedef enum
{
    ERROR_NO                            = 00,	// 오류없음(Default)
    ERROR_HARDWARE                      = 01,	// 연동하드웨어 오류(센서, 제어기 등)
    ERROR_DB_INPUT_FILE                 = 02,	// DB/입력 파일 오류(Not Exist)
    ERROR_INPUT_COMPONENT_CONNECTION    = 11,	// 입력단 컴포넌트 연결 오류
    ERROR_DATA_UPDATE                   = 12,	// 입력 데이터 갱신 오류
    ERROR_OUTPUT_COMPONENT_CONNECTION   = 21,	// 출력단 컴포넌트 연결 오류
    ERROR_OUTPUT_DATA_SEND              = 22    // 출력 데이터 송신 오류
} eErrorCode;

// 주행모드 Bit 7~4
typedef enum
{
    MODE_DONT_CARE 					= 0,        // 전원 인가(Don't Care)
    MODE_WAIT 						= 1,        // 운용 대기
    MODE_NORMAL                     = 2,        // 정상 운용
    MODE_EMERGENCY_STOP 			= 3,        // 비상정지
    MODE_BUILT_TRAINING             = 4,        // 내장 훈련
    MODE_USER_CHECK                 = 5,        // 사용자 점검
    MODE_POWER_OFF 					= 6         // 전원 차단
} eSystemMode;

// 주행모드 Bit 3~0
typedef enum
{
    DRIVE_REMOTE                    = 1,        // 원격 주행
    DRIVE_MANUAL                    = 3,        // 수동 주행
    DRIVE_ROUTE                     = 4,        // 경로 주행
    DRIVE_SUBORDINATION             = 5,        // 종속 주행
    DRIVE_AUTONOMOUS_RETURN         = 6         // 자율 복귀
} eDriveMode;


// Report_ComponentStatus
typedef struct _StAuto_ComponentStatus
{
    flt64_t             SyncTime;               // 동기화 시간
    uint8_t             SoftwareID;             // 프로그램 구분
    uint8_t             SoftwareStatus;         // 프로그램 상태
    uint8_t             ErrorCode[4];           // 에러코드
    uint8_t             SoftwareConfidence;     // 프로그램 신뢰도(0~100)
    StMode              Mode;                   // 주행 모드

} StAuto_ComponentStatus;

typedef struct _StAuto_ComponentStatusComm : public AUTONOMOUS::COMMLIB::Header, public StAuto_ComponentStatus
{
    virtual void setFrameData(uint8_t* buff)
    {
        buff = deserializeData(buff, SyncTime);
        buff = deserializeData(buff, SoftwareID);
        buff = deserializeData(buff, SoftwareStatus);
        std::for_each(ErrorCode, ErrorCode + 4, [&](uint8_t& d)
        {
            buff = deserializeData(buff, d);
        });
        buff = deserializeData(buff, SoftwareConfidence);
        buff = deserializeData(buff, Mode.Mode);
    }

    virtual void getFrameData(std::vector<uint8_t>& buff)
    {
        serializeData(buff, SyncTime);
        serializeData(buff, SoftwareID);
        serializeData(buff, SoftwareStatus);
        std::for_each(ErrorCode, ErrorCode + 4, [&](uint8_t d)
        {
            serializeData(buff, d);
        });
        serializeData(buff, SoftwareConfidence);
        serializeData(buff, Mode.Mode);
    }

} StAuto_ComponentStatusComm;

}
}
}

#endif /* REPORT_COMPONENTSTATUS_H */
