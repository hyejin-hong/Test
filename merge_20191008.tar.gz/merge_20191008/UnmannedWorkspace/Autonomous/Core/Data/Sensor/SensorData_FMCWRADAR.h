#ifndef SENSORDATA_FMCWRADAR_H
#define SENSORDATA_FMCWRADAR_H

#include <CFW.h>
#include "../Common/Common.h"
#include "../Common/Auto_Navigation.h"
#include "SensorType.h"

namespace AUTONOMOUS
{
namespace Data
{
namespace Sensor
{

#define bswap_64(x) \
    ((((x) & 0xff00000000000000ull) >> 56)                                  \
    | (((x) & 0x00ff000000000000ull) >> 40)                                 \
    | (((x) & 0x0000ff0000000000ull) >> 24)                                 \
    | (((x) & 0x000000ff00000000ull) >> 8)                                  \
    | (((x) & 0x00000000ff000000ull) << 8)                                  \
    | (((x) & 0x0000000000ff0000ull) << 24)                                 \
    | (((x) & 0x000000000000ff00ull) << 40)                                 \
    | (((x) & 0x00000000000000ffull) << 56))


// FMCW_MODE
typedef enum
{
    NONE 	= 0,														// NONE
    MR		= 1,														// MR
    LR		= 2,														// LR
    MR_LR	= 3															// MR + LR
} eCan_Tx_Track_Range_Mode;

/************************************************************************/
/* Const Definition                                                     */
/************************************************************************/
static const int g_sizeTrack = 64;
static const int g_startTrackID = 0x500;
static const int g_endTrackID = 0x53F;

enum TRACK_STATUS
{
    STAT_NO_TARGET = 0,				//
    STAT_NEW_TARGET = 1,			//
    STAT_NEW_UPDATED_TARGET = 2,	//
    STAT_UPDATED_TARGET = 3,		//
    STAT_COASTED_TARGET = 4,		//
    STAT_MERGED_TARGET = 5,			//
    STAT_INVALID_COASTED_TARGET = 6,//
    STAT_NEW_COASTED_TARGET = 7		//
};

/************************************************************************/
/* Message Definition                                                   */
/************************************************************************/
typedef struct _StFMCWRadar
{
    unsigned int can_id;
    union
    {
        struct
        {
            long			can_tx_track_range_rate			: 14;	//
            unsigned long	can_tx_track_med_range_mode		:  2;	//
            long			can_tx_track_range_accel		: 10;	//
            unsigned long	can_tx_track_width				:  4;	//
            unsigned long	can_tx_track_rolling_count		:  1;	//
            unsigned long	can_tx_track_bridge_object		:  1;	//
            unsigned long	can_tx_track_range				: 11;	//
            long			can_tx_track_angle				: 10;	//
            unsigned long	can_tx_track_status				:  3;	//
            unsigned long	can_tx_track_oncoming			:  1;	//
            unsigned long	can_tx_track_grouping_changed	:  1;	//
            long			can_tx_track_lat_rate			:  6;	//
        };
        unsigned char		dataByte[8];
        unsigned long long	dataUINT64;
    } ;

    inline unsigned int GetSize() { return (sizeof(_StFMCWRadar)); }

} StFMCWRadar;

/*
 * FMCW ESR
 */
typedef struct _StSensorData_FMCWRADAR
{
    flt64_t                                         SyncTime;				// 동기화 시간
    AUTONOMOUS::Data::Common::StNavigationDetail    Navigation;				// 항법
    uint32_t                                        SensorType;				// 센서 종류

    StFMCWRadar                                     ESRData[64];			// FMCW ESR 센서 데이터

} StSensorData_FMCWRADAR;

typedef struct _StSensorData_FMCWRADARComm : public AUTONOMOUS::COMMLIB::Header, public StSensorData_FMCWRADAR
{
    virtual void setFrameData(uint8_t* buff)
    {
        buff = deserializeData(buff, SyncTime);

        buff = deserializeData(buff, Navigation.TimeStamp);
        std::for_each(Navigation.Zone, Navigation.Zone + 2, [&](int8_t& d)
        {
            buff = deserializeData(buff, d);
        });
        buff = deserializeData(buff, Navigation.East);
        buff = deserializeData(buff, Navigation.North);
        buff = deserializeData(buff, Navigation.Elevation);
        buff = deserializeData(buff, Navigation.Roll);
        buff = deserializeData(buff, Navigation.Pitch);
        buff = deserializeData(buff, Navigation.Heading);
        buff = deserializeData(buff, Navigation.VelocityLinearX);
        buff = deserializeData(buff, Navigation.VelocityLinearY);
        buff = deserializeData(buff, Navigation.VelocityLinearZ);
        buff = deserializeData(buff, Navigation.VelocityAngluarX);
        buff = deserializeData(buff, Navigation.VelocityAngluarY);
        buff = deserializeData(buff, Navigation.VelocityAngluarZ);

        buff = deserializeData(buff, SensorType);

        std::for_each(ESRData, ESRData + 64, [&](StFMCWRadar& d)
        {
            buff = deserializeData(buff, d.dataUINT64);
        });
    }

    virtual void getFrameData(std::vector<uint8_t>& buff)
    {
        serializeData(buff, SyncTime);

        serializeData(buff, Navigation.TimeStamp);
        std::for_each(Navigation.Zone, Navigation.Zone + 2, [&](int8_t d)
        {
            serializeData(buff, d);
        });
        serializeData(buff, Navigation.East);
        serializeData(buff, Navigation.North);
        serializeData(buff, Navigation.Elevation);
        serializeData(buff, Navigation.Roll);
        serializeData(buff, Navigation.Pitch);
        serializeData(buff, Navigation.Heading);
        serializeData(buff, Navigation.VelocityLinearX);
        serializeData(buff, Navigation.VelocityLinearY);
        serializeData(buff, Navigation.VelocityLinearZ);
        serializeData(buff, Navigation.VelocityAngluarX);
        serializeData(buff, Navigation.VelocityAngluarY);
        serializeData(buff, Navigation.VelocityAngluarZ);

        std::for_each(ESRData, ESRData + 64, [&](StFMCWRadar d)
        {
            serializeData(buff, d.dataUINT64);
        });
    }

} StSensorData_FMCWRADARComm;

}
}
}


#endif /* SENSORDATA_FMCWRADAR_H */
