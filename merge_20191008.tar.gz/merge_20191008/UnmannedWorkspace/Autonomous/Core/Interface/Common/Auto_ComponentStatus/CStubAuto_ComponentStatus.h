#ifndef CSTUBAUTO_COMPONENTSTATUS_H
#define CSTUBAUTO_COMPONENTSTATUS_H

#include <CFW.h>
#include <Core/DevLib/Include/IO/CLogWriter/CLogWriter.h>

// ICD Data
#include "../../../Data/Common/Auto_ComponentStatus.h"

namespace AUTONOMOUS
{
namespace Interface
{
namespace Common
{

class CStubAuto_ComponentStatus
{
public :
    CStubAuto_ComponentStatus();
    virtual ~CStubAuto_ComponentStatus();

    inline void WriteAuto_ComponentStatus(AUTONOMOUS::Data::Common::StAuto_ComponentStatusComm& data)
    {
        data.message_type   = MSG_TYPE_COMMON;
        data.message_ID     = MSG_CODE_COMMON_AUTO_COMPONENTSTATUS;
        data.QoS            = MSG_QOS_COMMON_AUTO_COMPONENTSTATUS;
        data.SN             = m_snStubAuto_ComponentStatus++;

        AUTONOMOUS::COMMLIB::CFW::GetInstance().Send(data);

        if( m_logStubAuto_ComponentStatus.IsRun() )
        {
            m_vBuffStubAuto_ComponentStatus.clear();
            data.getFrameData(m_vBuffStubAuto_ComponentStatus);
            m_logStubAuto_ComponentStatus.WriteData(m_vBuffStubAuto_ComponentStatus.data(), m_vBuffStubAuto_ComponentStatus.size());
        }
    }

    // Log
    bool CreateLogStubAuto_ComponentStatus(char* logName);
    void CloseLogStubAuto_ComponentStatus();

private:
    std::vector<uint8_t>   m_vBuffStubAuto_ComponentStatus;
    uint8_t                m_snStubAuto_ComponentStatus;
protected:
    DevLib::IO::CLogWriter m_logStubAuto_ComponentStatus;
};


}
}
}

#endif /* CSTUBAUTO_COMPONENTSTATUS_H */
