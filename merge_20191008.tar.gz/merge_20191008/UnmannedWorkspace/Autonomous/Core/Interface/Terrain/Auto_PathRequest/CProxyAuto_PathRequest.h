#ifndef CPROXYEAUTO_PATHREQUEST_H
#define CPROXYEAUTO_PATHREQUEST_H

#include <Core/DevLib/Include/IO/CLogWriter/CLogWriter.h>

// ICD Data
#include "../../../Data/Terrain/Auto_PathRequest.h"

namespace AUTONOMOUS
{
namespace Interface
{
namespace Terrain
{

class CProxyAuto_PathRequest
{
public :
    CProxyAuto_PathRequest();
    virtual ~CProxyAuto_PathRequest();

    virtual void OnAuto_PathRequest(AUTONOMOUS::Data::Terrain::StAuto_PathRequestComm& data) = 0;

    // Log
    bool CreateLogProxyAuto_PathRequest(char* logName);
    void CloseLogProxyAuto_PathRequest();

private:
    std::vector<uint8_t>   m_vBuffProxyAuto_PathRequest;
protected:
    DevLib::IO::CLogWriter m_logProxyAuto_PathRequest;

    void _OnAuto_PathRequest(AUTONOMOUS::Data::Terrain::StAuto_PathRequestComm& data);
};


}
}
}

#endif /* CPROXYEAUTO_PATHREQUEST_H */
