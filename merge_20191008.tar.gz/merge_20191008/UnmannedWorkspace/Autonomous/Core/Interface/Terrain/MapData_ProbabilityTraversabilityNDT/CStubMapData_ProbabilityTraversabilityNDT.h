#ifndef CSTUBMAPDATA_PROBABILITYTRAVERSABILITYNDT_H
#define CSTUBMAPDATA_PROBABILITYTRAVERSABILITYNDT_H

#include <CFW.h>
#include <Core/DevLib/Include/IO/CLogWriter/CLogWriter.h>

// ICD Data
#include "../../../Data/Terrain/MapData_Probability.h"

namespace AUTONOMOUS
{
namespace Interface
{
namespace Terrain
{

class CStubMapData_ProbabilityTraversabilityNDT
{
public :
    CStubMapData_ProbabilityTraversabilityNDT();
    virtual ~CStubMapData_ProbabilityTraversabilityNDT();

    inline void WriteMapData_ProbabilityTraversabilityNDT(AUTONOMOUS::Data::Terrain::StMapData_ProbabilityComm& data)
    {
        data.message_type   = MSG_TYPE_TERRAIN;
        data.message_ID     = MSG_CODE_TERRAIN_MAPDATA_PROBABILITYTRAVERSABILITYNDT;
        data.QoS            = MSG_QOS_TERRAIN_MAPDATA_PROBABILITYTRAVERSABILITYNDT;
        data.SN             = m_snStubMapData_ProbabilityTraversabilityNDT++;

        AUTONOMOUS::COMMLIB::CFW::GetInstance().Send(data);

        if( m_logStubMapData_ProbabilityTraversabilityNDT.IsRun() )
        {
            m_vBuffStubMapData_ProbabilityTraversabilityNDT.clear();
            data.getFrameData(m_vBuffStubMapData_ProbabilityTraversabilityNDT);
            m_logStubMapData_ProbabilityTraversabilityNDT.WriteData(m_vBuffStubMapData_ProbabilityTraversabilityNDT.data(), m_vBuffStubMapData_ProbabilityTraversabilityNDT.size());
        }
    }

    // Log
    bool CreateLogStubMapData_ProbabilityTraversabilityNDT(char* logName);
    void CloseLogStubMapData_ProbabilityTraversabilityNDT();

private:
    std::vector<uint8_t>   m_vBuffStubMapData_ProbabilityTraversabilityNDT;
    uint8_t                m_snStubMapData_ProbabilityTraversabilityNDT;
protected:
    DevLib::IO::CLogWriter m_logStubMapData_ProbabilityTraversabilityNDT;
};


}
}
}

#endif /* CSTUBMAPDATA_PROBABILITYTRAVERSABILITYNDT_H */
