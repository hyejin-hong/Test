#ifndef CPROXYESENSORDATA_LIDAR_RTHETA2DLIDAR_H
#define CPROXYESENSORDATA_LIDAR_RTHETA2DLIDAR_H

#include <Core/DevLib/Include/IO/CLogWriter/CLogWriter.h>

// ICD Data
#include "../../../Data/Sensor/SensorData_LIDAR_Rtheta.h"

namespace AUTONOMOUS
{
namespace Interface
{
namespace Sensor
{

class CProxySensorData_LIDAR_Rtheta2DLidar
{
public :
    CProxySensorData_LIDAR_Rtheta2DLidar();
    virtual ~CProxySensorData_LIDAR_Rtheta2DLidar();

    virtual void OnSensorData_LIDAR_Rtheta2DLidar(AUTONOMOUS::Data::Sensor::StSensorData_LIDAR_RthetaComm& data) = 0;

    // Log
    bool CreateLogProxySensorData_LIDAR_Rtheta2DLidar(char* logName);
    void CloseLogProxySensorData_LIDAR_Rtheta2DLidar();

private:
    std::vector<uint8_t>   m_vBuffProxySensorData_LIDAR_Rtheta2DLidar;
protected:
    DevLib::IO::CLogWriter m_logProxySensorData_LIDAR_Rtheta2DLidar;

    void _OnSensorData_LIDAR_Rtheta2DLidar(AUTONOMOUS::Data::Sensor::StSensorData_LIDAR_RthetaComm& data);
};


}
}
}

#endif /* CPROXYESENSORDATA_LIDAR_RTHETA2DLIDAR_H */
