#include "CMRS1000Object.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

namespace AUTONOMOUS
{
namespace Device
{
namespace MRS1000
{

CMRS1000::CMRS1000(CObserverMRS1000* pObserver)
 : m_pObserverMRS1000Object(pObserver)
{
}

CMRS1000::~CMRS1000()
{
}

void CMRS1000::Create(char* connectIP, int port)
{
    m_connetIP  = connectIP;
    m_port      = port;

    DevLib::IO::CSocketClient::Create(port, connectIP);
}

void CMRS1000::OnConnected(char *ip, int port)
{
    char sendMsg[128];

    sprintf(sendMsg, "%c%s %s %d%c", g_stx, g_TypeCmdScan, g_CmdRecvDataCont, true, g_etx);

    Send(sendMsg, strlen(sendMsg));
}

void CMRS1000::OnDisconnected(char *ip, int port)
{
}

void CMRS1000::OnDataServer(char *ip, int port)
{
    bool bSuccess = true;
    char szStx[] = {g_stx, NULL};
    char szEtx[] = {g_etx, NULL};
    int nRecv = 0;
    memset(m_bufRecv, 0, g_maxLength);

    // stx가 들어올 때 까지 읽기
    char tmpStx = 0;
    while(tmpStx != g_stx )
    {
        bool bWait = true;//waitForReadyRead(1000);

        if( bWait == true )
        {
            Recv(&tmpStx, 1);
        }
    }

    // 메시지 헤더 읽기
    char tmpMsgType[4]="";
    nRecv = RecvUltil(tmpMsgType, 4, g_sep, GetSocket());
    if( nRecv<=0 ) bSuccess = false;

    if( bSuccess )
    {
        if( !strcmp(tmpMsgType, g_TypeAnswer) ) // -- 메시지 : 응답 메시지
        {
            const int	nMaxSize = 32;
            char		tmpMsg[nMaxSize] = "";
            char		tmpVal[nMaxSize] = "";
            int			nVal=0;

            // 메시지 헤더 읽기
            nRecv = RecvUltil(tmpMsg, nMaxSize, g_sep, GetSocket());
            if( nRecv<=0 ) bSuccess = false;

            if( bSuccess )
            {
                // 값 읽기
                nRecv = RecvUltil(tmpVal, nMaxSize, g_etx, GetSocket());
                if( nRecv<=0 ) bSuccess = false;

                if( bSuccess )
                {
                    for( int i=0; i<nMaxSize; i++ ) // -- 끝 문자가 etx가 아닌 ' '일 수도 있어 끝을 처리, StringToInt에서 끊어서 읽음
                    {
                        if( tmpVal[i]==' ' ) tmpVal[i]=0;
                    }

                    nVal = StringToInt(tmpVal, 16);

                    // 수신 메시지 출력
                    printf("Recv Command : %s => ", tmpMsg);
                    if( !strcmp(tmpMsg, g_CmdConfig) )
                    {
                        switch( nVal )
                        {
                        case 0:
                            printf("succeed\n");
                        break;
                        case 1:
                            printf("invalid freq.\n");
                        break;
                        case 2:
                            printf("invalid angular res.\n");
                        break;
                        case 3:
                            printf("invalid freq. and angular res.\n");
                        break;
                        case 4:
                            printf("invalid scan area\n");
                        break;
                        default:
                            printf("other error\n");
                        }
                    }
                    else if( !strcmp(tmpMsg, g_CmdStart) || !strcmp(tmpMsg, g_CmdStop) )
                    {
                        if(nVal == 0) printf("succeed\n");
                        else if( nVal==1) printf("error\n");
                        else ;
                    }
                    else
                    {
                        if(nVal == 0) printf("error\n");
                        else if( nVal==1) printf("succeed\n");
                        else ;
                    }
                }
            }
        }
        else if( !strcmp(tmpMsgType, g_TypeAnsScan) ) // -- 메시지 : 스캔 데이터
        {
            // 메시지 헤더 읽기
            char tmpMsgHeader[32]="";
            nRecv = RecvUltil(tmpMsgHeader, 32, g_sep, GetSocket());
            if( nRecv<=0 ) bSuccess = false;

            if( bSuccess )
            {
                // 읽지 않는 메시지 스킵
                char tmpMsgUnused[150]="";
                int count = 0;

                while( count < 13 ) // -- 24번째 메시지가 데이터 길이를 나타내므로 그 앞의 23개는 버림.
                {
                    nRecv = RecvUltil(tmpMsgUnused, 150, g_sep, GetSocket());
                    if( nRecv<=0 ) bSuccess = false;

                    if( bSuccess == false ) break;
                    count++;
                }

                // Layer Angle 읽기
                char tmpMsgLayer[5]="";
                nRecv = RecvUltil(tmpMsgLayer, 5, g_sep, GetSocket());

                int layer = StringToInt(tmpMsgLayer, 16);

                short layerIndex = (short)layer;

                count = 0;

                while( count < 9 ) // -- 24번째 메시지가 데이터 길이를 나타내므로 그 앞의 23개는 버림.
                {
                    nRecv = RecvUltil(tmpMsgUnused, 150, g_sep, GetSocket());
                    if( nRecv<=0 ) bSuccess = false;

                    if( bSuccess == false ) break;
                    count++;
                }

                if( bSuccess )
                {
                    // Length 읽기
                    char tmpMsgLength[5]="";
                    nRecv = RecvUltil(tmpMsgLength, 5, g_sep, GetSocket());
                    if( nRecv<=0 ) bSuccess = false;

                    if( bSuccess)
                    {
                        int length = StringToInt(tmpMsgLength, 16);

                        unsigned short scanData[1101]={ 0, };
                        // 데이터 읽기
                        for(int i = 0; i <= length; i++)
                        {
                            char strRange[5] = { 0, };
                            nRecv = RecvUltil(strRange, 5, g_sep, GetSocket());
                            if( nRecv<=0 ) bSuccess = false;
                            if( bSuccess == false ) break;
                            scanData[i] = StringToInt(strRange, 16);
                        }

                        if( bSuccess )
                        {
                            // 271 = 1      deg
                            // 541 = 0.5    deg
                            // 1081 = 0.25  deg
                            // 2161 = 0.125 deg
                            float res = 0.0f;
                            switch (length) {
                            case 271 :
                                res = 1.0f;
                                break;
                            case 541 :
                                res = 0.5f;
                                break;
                            case 1101 :
                                res = 0.25f;
                                break;
                            case 2161 :
                                res = 0.125f;
                                break;
                            default:
                                res = 0.0f;
                                break;
                            }
                            // Callback
                            //m_eUpdateLMS151.SetEvent();
//							printf("res: %0.2f\n", res);
//							printf("scanData: %hd\n", scanData[5]);
//							printf("length: %d\n", length);

                            AUTONOMOUS::Device::MRS1000::StMRS1000Packet data;

                            data.resolution	= res;
                            data.scanData	= scanData;
                            data.length		= length;

                            switch (layerIndex)
                            {
                            case 250:
                                data.layerIndex = 0;
                                break;
                            case 0:
                                data.layerIndex = 1;
                                break;
                            case -250:
                                data.layerIndex = 2;
                                break;
                            case -500:
                                data.layerIndex = 3;
                                break;
                            default:
                                break;
                            }

                            //OnScanData(res, scanData, length);

                            if( m_pObserverMRS1000Object )
                            {
                                m_pObserverMRS1000Object->OnMRS1000Pack(&data);
                            }
                        }
                    }
                }
            }
        }
        else if( !strcmp(tmpMsgType, g_TypeAnsStatus) ) // -- 메시지 : 상태값 쿼리
        {
            const int	nMaxSize = 32;
            char		tmpMsg[nMaxSize] = "";
            char		tmpVal1[nMaxSize] = "";
            char		tmpVal2[nMaxSize] = "";
            int			nVal=0;

            // 메시지 헤더 읽기
            nRecv = RecvUltil(tmpMsg, nMaxSize, g_sep, GetSocket());
            if( nRecv<=0 ) bSuccess = false;

            if( bSuccess )
            {
                // 데이터 읽기
                nRecv = RecvUltil(tmpVal1, nMaxSize, g_sep, GetSocket());
                if( nRecv<=0 ) bSuccess = false;

                if( bSuccess )
                {
                    nRecv = RecvUltil(tmpVal2, nMaxSize, g_sep, GetSocket());
                    if( nRecv<=0 ) bSuccess = false;

                    if( bSuccess )
                    {
                        int status = StringToInt(tmpVal1, 16); // -- 상태 값
                        bool bOperatingTemperature = StringToInt(tmpVal2, 16)==0?false:true; // -- 동작 가능 온도 여부

                        // 수신완료
                        m_sensorStatus = status;
                        m_bOperatingTemperature = bOperatingTemperature;
                        //m_eLMS151.SetEvent();
                    }
                }
            }

        }
        else // -- 정의되지 않은 메시지 헤더
        {
            printf("Recv : Undefined message header => %s \n", tmpMsgType);
        }
    }
}

int CMRS1000::RecvUltil(void* dst, int length, char findChar, int sock)
{
    int nRecv = 0;
    int nTotal = 0;
    char* pDst = (char*)dst;

//    QByteArray buf = comm->peek(8196);
//    if( buf.size() == 0 )
//    {
//        printf("waitForReadyRead1 %d, %s\n", __LINE__, __FILE__);
//        comm->waitForReadyRead(1000);
//    }

    nRecv = recv(sock, &pDst[nTotal], 1, 0);

    //nRecv = comm->read(&pDst[nTotal], 1);

    if( nRecv >  0 )
    {
        nTotal += nRecv;

        while( *(pDst+nTotal-1) != findChar && nTotal < length ) // -- nRecv가 length를 초과하거나, 수신된 1바이트가 findChar일 때 까지.
        {
//            buf = comm->peek(8196);
//            if( buf.size() == 0 )
//            {
//                printf("waitForReadyRead2 %d, %s\n", __LINE__, __FILE__);
//                comm->waitForReadyRead(1000);
//            }

            nRecv = recv(sock, &pDst[nTotal], 1, 0);
//            nRecv = comm->read(&pDst[nTotal], 1);
           if( nRecv <=  0 )
            {
                printf("Error %d, %s\n", __LINE__, __FILE__);
                nTotal = -1;
                break;
            }
            nTotal += nRecv;
        }
        pDst[nTotal-1] = '\0';
    }
    else
    {
        nTotal = -1;
        printf("Error %d, %s\n", __LINE__, __FILE__);
    }

    return nTotal;
}

int CMRS1000::StringToInt(char* strSrc, int radix)
{
    int sum = 0;

    if(radix==10)
    {
        sum = atoi(strSrc);
    }
    else if(radix==16)
    {
        if(!*strSrc) sum = -1;
        else
        {
            while(*strSrc)
            {
                int num=0;
                if( '0' <= *strSrc && *strSrc <= '9' ) num = *strSrc - '0';
                else if( 'a' <= *strSrc && *strSrc <= 'f' ) num = (*strSrc - 'a')+10;
                else if( 'A' <= *strSrc && *strSrc <= 'F' ) num = (*strSrc - 'A')+10;
                else
                {
                    sum = -1;
                    break;
                }
                sum = ((unsigned int)sum<<4) | (unsigned int)num;
                strSrc++;
            }
        }
    }
    else if(radix==2)
    {
        while(*strSrc)
        {
            int num=0;
            if(!*strSrc)
            {
                sum = -1;
                break;
            }
            if( *strSrc=='0' || *strSrc=='1' ) num = *strSrc - '0';
            else
            {
                sum = -1;
                break;
            }
            sum = ((unsigned int)sum<<1) | (unsigned int)num;
            strSrc++;
        }
    }
    else
    {
        sum = -1;
    }

    return sum;
}

}
}
}
