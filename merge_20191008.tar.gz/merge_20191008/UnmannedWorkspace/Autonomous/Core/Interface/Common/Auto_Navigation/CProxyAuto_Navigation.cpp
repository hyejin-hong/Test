#include "CProxyAuto_Navigation.h"

namespace AUTONOMOUS
{
namespace Interface
{
namespace Common
{

CProxyAuto_Navigation::CProxyAuto_Navigation()
{
    AUTONOMOUS::COMMLIB::CFW::GetInstance().RegisterSub(MSG_CODE_COMMON_AUTO_NAVIGATION, &CProxyAuto_Navigation::_OnAuto_Navigation, this);
}

CProxyAuto_Navigation::~CProxyAuto_Navigation()
{

}

bool CProxyAuto_Navigation::CreateLogProxyAuto_Navigation(char *logName)
{
    char fname[1024] = "";
    sprintf(fname, "./%s.Auto_Navigation", logName);

    return m_logProxyAuto_Navigation.Create(fname);
}

void CProxyAuto_Navigation::CloseLogProxyAuto_Navigation()
{
    m_logProxyAuto_Navigation.Destroy();
}

void CProxyAuto_Navigation::_OnAuto_Navigation(AUTONOMOUS::Data::Common::StAuto_NavigationComm& data)
{
    OnAuto_Navigation(data);
    if( m_logProxyAuto_Navigation.IsRun() )
    {
        m_vBuffProxyAuto_Navigation.clear();
        data.getFrameData(m_vBuffProxyAuto_Navigation);
        m_logProxyAuto_Navigation.WriteData(m_vBuffProxyAuto_Navigation.data(), m_vBuffProxyAuto_Navigation.size());
    }
}

}
}
}
