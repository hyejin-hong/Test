#ifndef CPROXYEAUTO_UGVESTOPREQUEST_H
#define CPROXYEAUTO_UGVESTOPREQUEST_H

#include <Core/DevLib/Include/IO/CLogWriter/CLogWriter.h>

// ICD Data
#include "../../../Data/Common/Auto_UGVEStopRequest.h"

namespace AUTONOMOUS
{
namespace Interface
{
namespace Common
{

class CProxyAuto_UGVEStopRequest
{
public :
    CProxyAuto_UGVEStopRequest();
    virtual ~CProxyAuto_UGVEStopRequest();

    virtual void OnAuto_UGVEStopRequest(AUTONOMOUS::Data::Common::StAuto_UGVEStopRequestComm& data) = 0;

    // Log
    bool CreateLogProxyAuto_UGVEStopRequest(char* logName);
    void CloseLogProxyAuto_UGVEStopRequest();

private:
    std::vector<uint8_t>   m_vBuffProxyAuto_UGVEStopRequest;
protected:
    DevLib::IO::CLogWriter m_logProxyAuto_UGVEStopRequest;

    void _OnAuto_UGVEStopRequest(AUTONOMOUS::Data::Common::StAuto_UGVEStopRequestComm& data);
};


}
}
}

#endif /* CPROXYEAUTO_UGVESTOPREQUEST_H */
