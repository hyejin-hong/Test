#ifndef SEND_LPPRESULT_H
#define SEND_LPPRESULT_H

#include <CFW.h>
#include "../Common/Common.h"

namespace AUTONOMOUS
{
namespace Data
{
namespace Autonomy
{

typedef struct _StLocalPathInfo
{
    uint8_t LPPAlgorithm;   // LPP 알고리즘  0 : 국과연, 1 : 한화
    flt64_t MapTimeStamp;   // 경로계획시 사용된 맵 Timestamp_sec
    flt64_t TimeStamp;      // 항법기준 기역경로 생성 시간
} StLocalPathInfo;

typedef struct _StLPPoint
{
    int8_t      Zone[2];    // UTM Zone 정보
    flt64_t     North;      // North 좌표
    flt64_t     East;       // East 좌표
    uint16_t    Velocity;   // 목표 속도
} StLPPoint;

typedef struct _StSend_LPPResult
{
    flt64_t         SyncTime;       // 동기화 시간
    uint32_t        MessageIndex;   // 메시지 전송 순서 : 전송시마다 1씩 증가
    StLocalPathInfo LocalPathInfo;  // LPP 정보

    // 속도계획 결과 기준 속도 ( KPH )
    // Range : 0 ~ 50000
    // scale : 0.001
    uint16_t                    ReferenceSpeed;

    // X축 경로생성계수
    // Interface 1 : 사용
    // Interface 2 : 미사용
    // Scale : 0.01
    int16_t                    PathGenerationCofficient_X_1;
    int16_t                    PathGenerationCofficient_X_2;
    int16_t                    PathGenerationCofficient_X_3;
    int16_t                    PathGenerationCofficient_X_4;
    int16_t                    PathGenerationCofficient_X_5;

    // Y축 경로생성계수
    // Interface 1 : 미사용
    // Interface 2 : 사용
    // Scale : 0.01
    int16_t                    PathGenerationCofficient_Y_1;
    int16_t                    PathGenerationCofficient_Y_2;
    int16_t                    PathGenerationCofficient_Y_3;
    int16_t                    PathGenerationCofficient_Y_4;
    int16_t                    PathGenerationCofficient_Y_5;

} StSend_LPPResult;

typedef struct _StSend_LPPResultComm : public AUTONOMOUS::COMMLIB::Header, public StSend_LPPResult
{
    virtual void setFrameData(uint8_t* buff)
    {
        buff = deserializeData(buff, SyncTime);
        buff = deserializeData(buff, MessageIndex);
        buff = deserializeData(buff, LocalPathInfo.LPPAlgorithm);
        buff = deserializeData(buff, LocalPathInfo.MapTimeStamp);
        buff = deserializeData(buff, LocalPathInfo.TimeStamp);
        buff = deserializeData(buff, ReferenceSpeed);
        buff = deserializeData(buff, PathGenerationCofficient_X_1);
        buff = deserializeData(buff, PathGenerationCofficient_X_2);
        buff = deserializeData(buff, PathGenerationCofficient_X_3);
        buff = deserializeData(buff, PathGenerationCofficient_X_4);
        buff = deserializeData(buff, PathGenerationCofficient_X_5);
        buff = deserializeData(buff, PathGenerationCofficient_Y_1);
        buff = deserializeData(buff, PathGenerationCofficient_Y_2);
        buff = deserializeData(buff, PathGenerationCofficient_Y_3);
        buff = deserializeData(buff, PathGenerationCofficient_Y_4);
        buff = deserializeData(buff, PathGenerationCofficient_Y_5);

    }

    virtual void getFrameData(std::vector<uint8_t>& buff)
    {
        serializeData(buff, SyncTime);
        serializeData(buff, MessageIndex);
        serializeData(buff, LocalPathInfo.LPPAlgorithm);
        serializeData(buff, LocalPathInfo.MapTimeStamp);
        serializeData(buff, LocalPathInfo.TimeStamp);
        serializeData(buff, ReferenceSpeed);
        serializeData(buff, PathGenerationCofficient_X_1);
        serializeData(buff, PathGenerationCofficient_X_2);
        serializeData(buff, PathGenerationCofficient_X_3);
        serializeData(buff, PathGenerationCofficient_X_4);
        serializeData(buff, PathGenerationCofficient_X_5);
        serializeData(buff, PathGenerationCofficient_Y_1);
        serializeData(buff, PathGenerationCofficient_Y_2);
        serializeData(buff, PathGenerationCofficient_Y_3);
        serializeData(buff, PathGenerationCofficient_Y_4);
        serializeData(buff, PathGenerationCofficient_Y_5);

    }

} StSend_LPPResultComm;

}
}
}


#endif // SEND_LPPRESULT_H
