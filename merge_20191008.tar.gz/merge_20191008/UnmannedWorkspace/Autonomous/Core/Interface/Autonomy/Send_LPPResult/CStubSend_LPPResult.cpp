#include "CStubSend_LPPResult.h"

namespace AUTONOMOUS
{
namespace Interface
{
namespace Autonomy
{

CStubSend_LPPResult::CStubSend_LPPResult()
{
    m_snStubSend_LPPResult = 0;
}

CStubSend_LPPResult::~CStubSend_LPPResult()
{ 

}

bool CStubSend_LPPResult::CreateLogStubSend_LPPResult(char *logName)
{
    char fname[1024] = "";
    sprintf(fname, "./%s.Send_LPPResult", logName);

    return m_logStubSend_LPPResult.Create(fname);
}

void CStubSend_LPPResult::CloseLogStubSend_LPPResult()
{
    m_logStubSend_LPPResult.Destroy();
}


}
}
}
