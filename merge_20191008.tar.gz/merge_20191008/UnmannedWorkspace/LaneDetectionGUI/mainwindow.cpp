#include "mainwindow.h"
#include "ui_mainwindow.h"

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    connect(&m_timer,SIGNAL(timeout()), this, SLOT(OnTimer()));

    AUTONOMOUS::COMMLIB::CFW::GetInstance().Initialize();
    AUTONOMOUS::COMMLIB::CFW::GetInstance().StartCFW();

    m_lane = new CLaneDetector;
    m_lane->Create();
    m_lane->Start();
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_pushButton_clicked()
{
    QString fileName = QFileDialog::getOpenFileName(this,
        tr("Open Log File"), nullptr, tr("Image (*.SensorData_Image)"));

    m_logFileFC.setFileName(fileName);
    if( m_logFileFC.open(QFile::ReadOnly) )
    {
        m_timer.stop();
    }
}

void MainWindow::OnTimer()
{
    int size = 0;


    if( m_logFileFC.isOpen() )
    {
        if( m_logFileFC.read((char*)&size, sizeof(int)) )
        {
            QVector<AUTONOMOUS::Data::Sensor::StSensorData_ImageComm> vData;
            QVector<unsigned char> buff;
            buff.resize(size);
            vData.resize(1);

            m_logFileFC.read((char*)buff.data(), size);
            vData[0].setFrameData(buff.data());

            ui->widget->ShowImage(vData[0].ImageData, 640, 480, 3);
            m_lane->OnSensorData_Image(vData[0]);


        }
    }
}

void MainWindow::on_pushButton_2_clicked()
{
    if( m_timer.isActive() ) m_timer.stop();
    else m_timer.start(50);
}
