#include "CStubMapData_Object.h"

namespace AUTONOMOUS
{
namespace Interface
{
namespace Terrain
{

CStubMapData_Object::CStubMapData_Object()
{
    m_snStubMapData_Object = 0;
}

CStubMapData_Object::~CStubMapData_Object()
{ 

}

bool CStubMapData_Object::CreateLogStubMapData_Object(char *logName)
{
    char fname[1024] = "";
    sprintf(fname, "./%s.MapData_Object", logName);

    return m_logStubMapData_Object.Create(fname);
}

void CStubMapData_Object::CloseLogStubMapData_Object()
{
    m_logStubMapData_Object.Destroy();
}


}
}
}
