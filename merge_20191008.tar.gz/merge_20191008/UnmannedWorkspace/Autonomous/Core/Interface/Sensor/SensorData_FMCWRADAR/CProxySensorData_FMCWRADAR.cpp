#include "CProxySensorData_FMCWRADAR.h"

namespace AUTONOMOUS
{
namespace Interface
{
namespace Sensor
{

CProxySensorData_FMCWRADAR::CProxySensorData_FMCWRADAR()
{
    AUTONOMOUS::COMMLIB::CFW::GetInstance().RegisterSub(MSG_CODE_SENSOR_SENSORDATA_FMCWRADAR, &CProxySensorData_FMCWRADAR::_OnSensorData_FMCWRADAR, this);
}

CProxySensorData_FMCWRADAR::~CProxySensorData_FMCWRADAR()
{

}

bool CProxySensorData_FMCWRADAR::CreateLogProxySensorData_FMCWRADAR(char *logName)
{
    char fname[1024] = "";
    sprintf(fname, "./%s.SensorData_FMCWRADAR", logName);

    return m_logProxySensorData_FMCWRADAR.Create(fname);
}

void CProxySensorData_FMCWRADAR::CloseLogProxySensorData_FMCWRADAR()
{
    m_logProxySensorData_FMCWRADAR.Destroy();
}

void CProxySensorData_FMCWRADAR::_OnSensorData_FMCWRADAR(AUTONOMOUS::Data::Sensor::StSensorData_FMCWRADARComm& data)
{
    OnSensorData_FMCWRADAR(data);
    if( m_logProxySensorData_FMCWRADAR.IsRun() )
    {
        m_vBuffProxySensorData_FMCWRADAR.clear();
        data.getFrameData(m_vBuffProxySensorData_FMCWRADAR);
        m_logProxySensorData_FMCWRADAR.WriteData(m_vBuffProxySensorData_FMCWRADAR.data(), m_vBuffProxySensorData_FMCWRADAR.size());
    }
}

}
}
}
