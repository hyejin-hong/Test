#include "../../../Include/IO/CFile/CFile.h"

#include <fcntl.h>
#include <unistd.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <string.h>
#include <stdio.h>

namespace DevLib
{
namespace IO
{

CFile::CFile()
    : m_fp(nullptr)
{
}

CFile::~CFile()
{
    Destroy();
}

bool CFile::Create(const char* fname, const char* mode)
{
    bool bRet = false;

    if(IsCreated() == false)
    {
        if( (m_fp = fopen(fname, mode) ) != nullptr)
        {
            bRet = true;
        }
        else
        {
            perror("Error");
        }
    }
    return bRet;
}

bool CFile::IsCreated()
{
    return ( m_fp != nullptr ) ? true : false;
}

int CFile::Write(void* pData, int size)
{
    return fwrite(pData, size, 1, m_fp);
}

int CFile::Read(void* pData, int size)
{
    return fread(pData, 1, size, m_fp);
}

int CFile::GetSize()
{
    int oldPos = fseek(m_fp, 0, SEEK_CUR);

    SeekEnd();
    int size = SeekCur();
    SeekPos(oldPos);

    return size;

}

int CFile::SeekBegin()
{
    return fseek(m_fp, 0, SEEK_SET);
}

int CFile::SeekEnd()
{
    return fseek(m_fp, 0, SEEK_END);
}

int CFile::SeekCur()
{
    return ftell(m_fp);
}

int CFile::SeekPos(int nPos)
{
    return fseek(m_fp, nPos, SEEK_SET);
}

void CFile::Destroy()
{
    if( m_fp )
    {
        fclose(m_fp);
        m_fp = nullptr;
    }
}

}
}
