#ifndef AUTO_CONTROLREQUEST_H
#define AUTO_CONTROLREQUEST_H

#include <CFW.h>
#include "../Common/Common.h"

namespace AUTONOMOUS
{
namespace Data
{
namespace Autonomy
{

typedef struct _StAuto_ControlRequest
{
    //flt64_t     SyncTime;   // 동기화 시간

    union
    {
        struct
        {
            // 자율주행 명령 ( 7 ~ 4 )
        int8_t      Reserved : 4;

        // 0 : 미적용
        // 1 : 자율주행시작
        // 2 : 자율주행 일시정지
        // 4 : 자율주행 취소
        int8_t      Control : 4;
        };

        int8_t  Value;
    };


} StAuto_ControlRequest;

typedef struct _StAuto_ControlRequestComm : public AUTONOMOUS::COMMLIB::Header, public StAuto_ControlRequest
{
    virtual void setFrameData(uint8_t* buff)
    {
        //buff = deserializeData(buff, SyncTime);
        buff = deserializeData(buff, Value);
    }

    virtual void getFrameData(std::vector<uint8_t>& buff)
    {
        //serializeData(buff, SyncTime);
        serializeData(buff, Value);
    }

} StAuto_ControlRequestComm;

}
}
}

#endif // AUTO_CONTROLREQUEST_H
