#ifndef CSTUBAUTO_LOG_CONTROL_H
#define CSTUBAUTO_LOG_CONTROL_H

#include <CFW.h>
#include <Core/DevLib/Include/IO/CLogWriter/CLogWriter.h>

// ICD Data
#include "../../../Data/Analysis/Auto_Log_Control.h"

namespace AUTONOMOUS
{
namespace Interface
{
namespace Analysis
{

class CStubAuto_Log_Control
{
public :
    CStubAuto_Log_Control();
    virtual ~CStubAuto_Log_Control();

    inline void WriteAuto_Log_Control(AUTONOMOUS::Data::Analysis::StAuto_Log_ControlComm& data)
    {
        data.message_type   = MSG_TYPE_ANALYSIS;
        data.message_ID     = MSG_CODE_ANALYSIS_AUTO_LOG_CONTROL;
        data.QoS            = MSG_QOS_ANALYSIS_AUTO_LOG_CONTROL;
        data.SN             = m_snStubAuto_Log_Control++;

        AUTONOMOUS::COMMLIB::CFW::GetInstance().Send(data);

        if( m_logStubAuto_Log_Control.IsRun() )
        {
            m_vBuffStubAuto_Log_Control.clear();
            data.getFrameData(m_vBuffStubAuto_Log_Control);
            m_logStubAuto_Log_Control.WriteData(m_vBuffStubAuto_Log_Control.data(), m_vBuffStubAuto_Log_Control.size());
        }
    }

    // Log
    bool CreateLogStubAuto_Log_Control(char* logName);
    void CloseLogStubAuto_Log_Control();

private:
    std::vector<uint8_t>   m_vBuffStubAuto_Log_Control;
    uint8_t                m_snStubAuto_Log_Control;
protected:
    DevLib::IO::CLogWriter m_logStubAuto_Log_Control;
};


}
}
}

#endif /* CSTUBAUTO_LOG_CONTROL_H */
