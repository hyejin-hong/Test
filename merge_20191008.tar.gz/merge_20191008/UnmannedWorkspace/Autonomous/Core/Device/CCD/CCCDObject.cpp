/*
 * CCCDObject.cpp
 *
 *  Created on: 2019. 4. 8.
 *      Author: fme
 */

#include "CCCDObject.h"

#include <stdlib.h>

namespace AUTONOMOUS
{
namespace Device
{
namespace CCD
{


CCCDObject::CCCDObject(CObserverCCDObject* pObserver)
 : m_pObserverCCDObject(pObserver)
{
	m_bufferImage.resize(640 * 480 * 3);
}

CCCDObject::~CCCDObject()
{
}

bool CCCDObject::Create(char* bindIP, int port)
{
	bool bRet = false;
	if( DevLib::IO::CSocketReceiver::Create(DevLib::IO::CSocket::SOCK_UDP) )
	{
		if( Bind(port, bindIP) )
		{
			bRet = true;

			ServiceStart();
		}
	}

	return bRet;
}


void CCCDObject::OnReceive()
{
	char ip[32] = "";				// 송신 측의 IP주소
	int port = 0;					// 송신 측의 Port번호
	if( RecvFrom(m_bufferImage.data(), m_bufferImage.size(), ip, &port, 0) == signed(m_bufferImage.size()) )
	{
		if( m_pObserverCCDObject )
		{
			m_pObserverCCDObject->OnCCDPack(m_bufferImage.data());
		}
	}
}

bool CCCDObject::Create()
{
	bool bRet = false;

	if(DevLib::CTimer::IsTimerOn() == false)
	{
		DevLib::CTimer::TimerStart(33);								// 10Hz
		bRet = true;
	}

	return bRet;
}

void CCCDObject::OnTimer(void*)
{
	uint8_t* data = m_bufferImage.data();

	for( int i = 0; i < 600; i++ )
	{
		data[rand()%(640*480*3)] = rand()%255;
	}

	m_pObserverCCDObject->OnCCDPack(m_bufferImage.data());

}



}
}
}

