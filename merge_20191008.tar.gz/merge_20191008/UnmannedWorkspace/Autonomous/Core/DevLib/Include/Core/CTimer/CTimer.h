#ifndef CTIMER_H
#define CTIMER_H


#include <signal.h>
#include <time.h>

namespace DevLib
{

typedef void (*TIMER_CALLBACK)(void* p);

class CTimer
{
public:
	CTimer();
	virtual ~CTimer();

	bool TimerStart(int ms, TIMER_CALLBACK func = 0, void* param = 0);	// 타이머 시작
	void TimerStop();									// 타이머 정지

	bool IsTimerOn();									// 타이머 작동 여부

	virtual void OnTimer(void* p);

private:
	bool			m_bTimer;

	timer_t 		m_timerId;

protected :
	struct
    {
        TIMER_CALLBACK pCallBack;
        void* pParam;
    } m_param;
};

}
#endif /* CTIMER_H */
