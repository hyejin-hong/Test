#ifndef DRIVE_REMOTECONTROL_H
#define DRIVE_REMOTECONTROL_H

#include <CFW.h>
#include "../Common/Common.h"

namespace AUTONOMOUS
{
namespace Data
{
namespace Common
{

typedef struct _StAuto_RemoteControl
{
    flt64_t             SyncTime;       // 동기화 시간
    int8_t              SteeringWheel;  // Wheel 조향 : -100 ~ 100 %
    int8_t              Accelator;      // 가속 페달 : 0 ~ 100 %
    int8_t              Break;          // 감속 페달 : 0 ~ 100 %
    AUTONOMOUS::StGear  Gear;

} StAuto_RemoteControl;


typedef struct _StAuto_RemoteControlComm : public AUTONOMOUS::COMMLIB::Header, public StAuto_RemoteControl
{
    virtual void setFrameData(uint8_t* buff)
    {
        buff = deserializeData(buff, SyncTime);
        buff = deserializeData(buff, SteeringWheel);
        buff = deserializeData(buff, Accelator);
        buff = deserializeData(buff, Break);
        buff = deserializeData(buff, Gear.Gear);
    }

    virtual void getFrameData(std::vector<uint8_t>& buff)
    {
        serializeData(buff, SyncTime);
        serializeData(buff, SteeringWheel);
        serializeData(buff, Accelator);
        serializeData(buff, Break);
        serializeData(buff, Gear.Gear);
    }

} StAuto_RemoteControlComm;

}
}
}


#endif // DRIVE_REMOTECONTROL_H
