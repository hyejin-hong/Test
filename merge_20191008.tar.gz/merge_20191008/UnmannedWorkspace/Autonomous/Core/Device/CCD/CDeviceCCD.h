/*
 * CDeviceCCD.h
 *
 *  Created on: 2019. 4. 8.
 *      Author: fme
 */

#ifndef CDEVICECCD_H
#define CDEVICECCD_H

#include "CCCDObject.h"

namespace AUTONOMOUS
{
namespace Device
{
namespace CCD
{

class CDeviceCCD : public AUTONOMOUS::Device::CCD::CObserverCCDObject
{
public:
	CDeviceCCD()
	: m_devCCD(this)
	{

	}

	virtual ~CDeviceCCD()
	{

	}

	virtual void OnCCDPackRecv(uint8_t* pCCDPack) = 0;

	AUTONOMOUS::Device::CCD::CCCDObject* GetDeviceCCD() { return &m_devCCD; }


private :
	AUTONOMOUS::Device::CCD::CCCDObject 	m_devCCD;

	virtual void OnCCDPack(uint8_t* pCCDPack)
	{
		OnCCDPackRecv(pCCDPack);
	}

};

}
}
}


#endif /* CDEVICECCD_H */

