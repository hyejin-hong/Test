#include "clanedetector.h"
#include <opencv/cv.h>
#include <opencv/highgui.h>
#include <opencv2/imgproc/imgproc.hpp>
#include <math.h>
#include <stdlib.h>
#include <vector>


/* 결과 확인용 display function만을 함수로 .. */
void displayWorldPoint(Mat TOPView, wpoint* left_world, wpoint* right_world,int  left_marker_num,int right_marker_num ,float X_MIN,float Z_MIN, int X_NUM, int Z_NUM, float GRID);
void displayimgPoint(Mat View, ipoint* left_world, ipoint* right_world,int  left_marker_num, int right_marker_num);
void displayTOPView(Mat TOPView, int left_valid, int right_valid, float *left_coeff, float* right_coeff, float X_MIN, float Z_MIN, int X_NUM, int Z_NUM, float GRID);
void display1stTOPView(Mat TOPView, int left_valid, int right_valid, float *left_coeff, float* right_coeff, float X_MIN, float Z_MIN, int X_NUM, int Z_NUM, float GRID);
void displayGPP(Mat TOPView, float* gpp,float X_MIN, float Z_MIN, int X_NUM, int Z_NUM, float GRID);
void displayGPP2(Mat TOPView, float* gpp, float* tpl, float*tpr, float X_MIN, float Z_MIN, int X_NUM, int Z_NUM, float GRID);

struct Test_GPP : public AUTONOMOUS::COMMLIB::Header
{
    float_t c_x_min = -10.0;
    float_t c_z_min = 0.0;
    float_t c_grid = 0.1;
    uint32_t c_x_num = 200;
    uint32_t c_z_num = 300;
    int32_t c_left_valid = -1;
    int32_t c_right_valid = -1;
    float_t c_left_coeff[3] = {0,};
    float_t c_right_coeff[3] = {0,};

    float_t GPP[2] = {0,};
    uint8_t confidence[2] = {0,};

    float_t _tracking_plf[2] = {0,};
    float_t _tracking_prf[2] = {0,};

    Test_GPP()
    {
        message_ID = 15;
    }

    void getFrameData(std::vector<uint8_t>& buff)
    {
        serializeData(buff, c_left_valid );
        serializeData(buff, c_right_valid);

        std::for_each(confidence, confidence+2, [&](uint8_t d)
        {
            serializeData(buff, d);
        });

        std::for_each(c_left_coeff, c_left_coeff+3, [&](float_t d)
        {
            serializeData(buff, d);
        });

        std::for_each(c_right_coeff, c_right_coeff+3, [&](float_t d)
        {
            serializeData(buff, d);
        });

        std::for_each(GPP, GPP+2, [&](float_t d)
        {
            serializeData(buff, d);
        });

        std::for_each(_tracking_plf, _tracking_plf+2, [&](float_t d)
        {
            serializeData(buff, d);
        });

        std::for_each(_tracking_prf, _tracking_prf+2, [&](float_t d)
        {
            serializeData(buff, d);
        });
    }

    void setFrameData(uint8_t* buff)
    {
        buff = deserializeData(buff, c_left_valid );
        buff = deserializeData(buff, c_right_valid);

        std::for_each(confidence, confidence+2, [&](uint8_t& d)
        {
            buff = deserializeData(buff, d);
        });

        std::for_each(c_left_coeff, c_left_coeff+3, [&](float_t& d)
        {
            buff = deserializeData(buff, d);
        });

        std::for_each(c_right_coeff, c_right_coeff+3, [&](float_t& d)
        {
            buff = deserializeData(buff, d);
        });

        std::for_each(GPP, GPP+2, [&](float_t& d)
        {
            buff = deserializeData(buff, d);
        });

        std::for_each(_tracking_plf, _tracking_plf+2, [&](float_t& d)
        {
            buff = deserializeData(buff, d);
        });

        std::for_each(_tracking_prf, _tracking_prf+2, [&](float_t& d)
        {
            buff = deserializeData(buff, d);
        });
    }
};
CLaneDetector::CLaneDetector()
{
    DL.InitializeParams();
    m_eUpdate.Create();

    m_imgData = new AUTONOMOUS::Data::Sensor::StSensorData_ImageComm;
    m_imgDataBuff = new AUTONOMOUS::Data::Sensor::StSensorData_ImageComm;

}

void CLaneDetector::OnPreCreate()
{
    // ------------------------------
    detectcross::DetectCross p{"file_name.json"};
    p.readJson();


    // --------------------------------------------------------------------------------------
    // Draw Map

    Mat result_img = Mat::zeros(1000, 1000, CV_8UC3);

    for (int i = 0; i < result_img.rows; i++)
    {
        for (int j = 0; j < result_img.cols; j++)
        {
            result_img.at<Vec3b>(i, j)[2] = 100; // R
            result_img.at<Vec3b>(i, j)[1] = 100; // G
            result_img.at<Vec3b>(i, j)[0] = 100; // B
        }
    }

    // Draw Node
    for (int i = 0; i < p.node_size; i++) {
        circle(result_img, Point(p.lon[i]*1000, p.lat[i]*1000), 5, Scalar(255, 255, 255), 2, 8);
    }


    // Draw Link
    double lon1, lat1, lon2, lat2;

    for (int j = 0; j < p.link_size; j++) {
        for (int i = 0; i < p.node_size; i++) {
            if(p.nid[i] == p.src[j])
            {
                lon1 = p.lon[i];
                lat1 = p.lat[i];
                break;
            }
        }

        for (int i = 0; i < p.node_size; i++) {
            if(p.nid[i] == p.tag[j])
            {
                lon2 = p.lon[i];
                lat2 = p.lat[i];
                break;
            }
        }

        // cout << "lon1 : " << lon1 << endl;
        // cout << "lat1 : " << lat1 << endl;
        // cout << "lon2 : " << lon2 << endl;
        // cout << "lat2 : " << lat2 << endl;

        line(result_img, Point(lon1*1000, lat1*1000), Point(lon2*1000, lat2*1000), Scalar(50, 0, 220), 2, 8);
    }

    static CViewImage viewMap;
    viewMap.ShowImage(result_img.ptr(), 1000, 1000, 3);


    // --------------------------------------------------------------------------------------
    // Draw GPS Point Map
    // --------------------------------------------------------------------------------------

    result_gpp_img = Mat::zeros(1000, 1000, CV_8UC3);

    for (int i = 0; i < result_gpp_img.rows; i++)
    {
        for (int j = 0; j < result_gpp_img.cols; j++)
        {
            result_gpp_img.at<Vec3b>(i, j)[2] = 100; // R
            result_gpp_img.at<Vec3b>(i, j)[1] = 100; // G
            result_gpp_img.at<Vec3b>(i, j)[0] = 100; // B
        }
    }

}

void CLaneDetector::OnRunning()
{
    while( IsRunning() )
    {
        if( m_eUpdate.WaitForEvent(1000) )
        {
            //memcpy(m_imgDataBuff, m_imgData, sizeof(AUTONOMOUS::Data::Sensor::StSensorData_ImageComm));

            *m_imgDataBuff = *m_imgData;
            AUTONOMOUS::Data::Sensor::StSensorData_ImageComm &data = *m_imgDataBuff;

            static CViewImage inputView(nullptr, "InputImage");
            inputView.ShowImage(data.ImageData, data.ImageSize.Width, data.ImageSize.Height, 3);
            printf("data.Navigation.East : %lf\n", data.Navigation.East);
            printf("data.Navigation.North : %lf\n", data.Navigation.North);


            DevLib::CElapsedTimer elap;
            // 알고리즘 수행.
            Mat RoadImgMat = Mat(DL.img_height, DL.img_width, CV_8UC3, data.ImageData);
            Mat TOPView;
            TOPView = Mat::zeros(DL.Z_NUM,DL.X_NUM,CV_8UC3);
            Mat LidarMat = Mat(DL.img_height, DL.img_width, CV_8UC3);
            DL.Process(data.ImageData);

            elap.PrintElapsedTime("ProcessTime");
            Test_GPP m_gpp;

            //client에게 보내는 정보
            m_gpp.c_left_valid = DL.left_valid;
            m_gpp.c_right_valid = DL.right_valid;

            for(int i=0; i<2; i++)
            {
                m_gpp.c_left_coeff[i] = DL.left_coeff[i];
                m_gpp.c_right_coeff[i] = DL.right_coeff[i];
            }

            m_gpp._tracking_plf[0]= DL.m_Track._tracking_points_l[0];
            m_gpp._tracking_plf[1]= DL.Z_MIN;
            m_gpp._tracking_prf[0]= DL.m_Track._tracking_points_r[0];
            m_gpp._tracking_prf[1]= DL.Z_MIN;

            std::cout << "m_gpp.left_coeff : " << m_gpp.c_left_coeff[0]<<", "<<m_gpp.c_left_coeff[1]<< std::endl;
            std::cout << "m_gpp.right_coeff : " << m_gpp.c_right_coeff[0]<<", "<<m_gpp.c_right_coeff[1]<< std::endl;

            displayimgPoint(RoadImgMat, DL.left_lane_marker, DL.right_lane_marker, DL.left_imarker_num, DL.right_imarker_num);

            // Lidar Debug -----------------------------
                LidarMat = Scalar(0);

                //allocation
                int Lidar_pnum = 0;
                LidarWpoint *LPoint = new LidarWpoint[10000];

                for(int j=0; j < LidarMat.rows; j += 50){
                    for(int i=0; i < LidarMat.cols; i++){
                        LPoint[Lidar_pnum].x = i;
                        LPoint[Lidar_pnum].y = j;
                        LPoint[Lidar_pnum].z = 0;

                        if(Lidar_pnum < 10000-10) Lidar_pnum++;
                        else break;
                    }
                }

                DL.findLidarPoints(Lidar_pnum, LPoint);

                displayimgPoint(LidarMat, DL.left_lane_marker, DL.right_lane_marker, DL.left_imarker_num, DL.right_imarker_num);

                for(int i=0; i<DL.Lidar_left_pnum; i++){
                    circle(LidarMat, Point((int)DL.Lidar_left_point[i].x, (int)DL.Lidar_left_point[i].y), 1, Scalar(0,255,255), 2,8);
                }

                for(int i=0; i<DL.Lidar_right_pnum; i++){
                    circle(LidarMat, Point((int)DL.Lidar_right_point[i].x, (int)DL.Lidar_right_point[i].y), 1, Scalar(255,255,0), 2,8);
                }


                delete [] LPoint;

                // ---------------------------------------------------

            TOPView = Scalar(0);
            display1stTOPView(TOPView, DL.left_valid, DL.right_valid,DL.left_coeff, DL.right_coeff, DL.X_MIN, DL.Z_MIN, DL.X_NUM, DL.Z_NUM, DL.GRID);

            displayGPP2(TOPView, DL.m_Track.GPP, DL.m_Track._tracking_points_l, DL.m_Track._tracking_points_r, DL.X_MIN, DL.Z_MIN, DL.X_NUM, DL.Z_NUM, DL.GRID);


            static CViewImage view;
            view.ShowImage(TOPView.ptr(), 200, 300, 3);
            static CViewImage view_ori;
            view_ori.ShowImage(RoadImgMat.ptr(), 640, 480, 3);
            static CViewImage view2;
            view2.ShowImage(DL.GImage, 640, 480, 1);
            static CViewImage viewLidar;
            viewLidar.ShowImage(LidarMat.ptr(), 640, 480, 3);

//            AUTONOMOUS::COMMLIB::CFW::GetInstance().Send(m_gpp);

            // --------------------------------------------------------------------------------------
            // Draw GPS Point Map
            // --------------------------------------------------------------------------------------
//            m_gpp.GPP[0];   // x -> left to right
//            m_gpp.GPP[1];   // z -> forward

            double cam_x, cam_y, cam_th;
            double gpp_x, gpp_y;

//            gpp_x = 10*cos(data.Navigation.Heading*M_PI) - 10*sin(data.Navigation.Heading*M_PI) + data.Navigation.East;
//            gpp_y = 10*sin(data.Navigation.Heading*M_PI) + 10*cos(data.Navigation.Heading*M_PI) + data.Navigation.North;
            cam_x = data.Navigation.East - 47772;
            cam_y = data.Navigation.North - 30567;
            cam_th = 0*M_PI/180.0 - (data.Navigation.Heading*M_PI);

            printf("cam_th : %lf", cam_th);

            gpp_x = m_gpp.GPP[0]*cos(cam_th) - m_gpp.GPP[1]*sin(cam_th) + cam_x;
            gpp_y = m_gpp.GPP[0]*sin(cam_th) + m_gpp.GPP[1]*cos(cam_th) + cam_y;

            circle(result_gpp_img, Point(cam_x + 500, cam_y + 500), 5, Scalar(255, 255, 255), 2, 8);
            circle(result_gpp_img, Point(gpp_x + 500, gpp_y + 500), 5, Scalar(0, 255, 0), 2, 8);

            static CViewImage viewMap(nullptr, "GPP Image");
            viewMap.ShowImage(result_gpp_img.ptr(), 1000, 1000, 3);

//            // --------------------------------------------------------------------------------------
//            // Send GPP
//            // --------------------------------------------------------------------------------------
//            AUTONOMOUS::Data::Terrain::StAuto_PathRequestComm* result_gpp;
//            result_gpp = new AUTONOMOUS::Data::Terrain::StAuto_PathRequestComm;

//            result_gpp->GPPID = 100;
//            result_gpp->GPPType = 2;
//            result_gpp->GPPCount = 1;
//            result_gpp->GPPResult[0].East = data.Navigation.East;
//            result_gpp->GPPResult[0].North = data.Navigation.North;
//            result_gpp->GPPResult[0].CommandVelocity = 10;

//            WriteAuto_PathRequest(*result_gpp);
//            std::cout << "WriteAuto_PathRequest(*result_gpp)" << std::endl;
        }
    }
}

void CLaneDetector::OnShutdown()
{

}

void CLaneDetector::OnTimerReportStatus()
{
    AUTONOMOUS::Data::Common::StAuto_ComponentStatusComm data;
    data.SoftwareID = AUTONOMOUS::Data::Common::SOFTWARE_ID_LANE_DEPARTURE_PREVENTION;
    data.SoftwareStatus = AUTONOMOUS::Data::Common::NORMAL;
    data.SoftwareConfidence = 100;
    WriteAuto_ComponentStatus(data);
}

void CLaneDetector::OnCommand(char value)
{

}

void CLaneDetector::OnSensorData_Image(AUTONOMOUS::Data::Sensor::StSensorData_ImageComm &data)
{
//    memcpy(m_imgData, &data, sizeof(AUTONOMOUS::Data::Sensor::StSensorData_ImageComm));
    *m_imgData = data;

//    AUTONOMOUS::Data::Sensor::StSensorData_ImageComm &data = *m_imgData;
//    static CViewImage inputView(nullptr, "InputImage");
//    inputView.ShowImage(data.ImageData, data.ImageSize.Width, data.ImageSize.Height, 3);

    m_eUpdate.SetEvent();
}

void CLaneDetector::OnAuto_DriveModeRequest(AUTONOMOUS::Data::Common::StAuto_DriveModeRequestComm &data)
{
    printf("-------------------------- data.Mode : %d\n", data.Mode);
}

void CLaneDetector::OnSensorData_LIDAR_RthetaFrontCenter(AUTONOMOUS::Data::Sensor::StSensorData_LIDAR_RthetaComm &data)
{
    printf("OnVelodyneFrontCenter : %d\n", data.length);
}

void displayWorldPoint(Mat TOPView, wpoint* left_world, wpoint* right_world,int  left_marker_num,int right_marker_num ,float X_MIN,float Z_MIN, int X_NUM, int Z_NUM, float GRID)
{
    float x, z;
    int nx, nz;

    for(int i=0; i<left_marker_num; i++){
        x=left_world[i].x;
        z=left_world[i].z;
        nx = (int)((x-X_MIN + GRID*0.5)/GRID);
        nz = (int)((z-Z_MIN + GRID*0.5)/GRID);
        nz = Z_NUM-1-nz;
        if(nx<0 || nx>X_NUM-1 || nz<0 || nz>Z_NUM-1) continue;
        circle(TOPView, Point(nx, nz), 3, Scalar(255,0,0), 1);
    }

    for(int i=0; i<right_marker_num; i++){
        x=right_world[i].x;
        z=right_world[i].z;
        nx = (int)((x-X_MIN + GRID*0.5)/GRID);
        nz = (int)((z-Z_MIN + GRID*0.5)/GRID);
        nz = Z_NUM-1-nz;

        if(nx<0 || nx>X_NUM-1 || nz<0 || nz>Z_NUM-1) continue;
        circle(TOPView, Point(nx, nz), 3, Scalar(255,0,0), 1);
    }
}

void displayimgPoint(Mat View, ipoint* left_world, ipoint* right_world,int  left_marker_num, int right_marker_num)
{
    int x, z;

    for(int i=0; i<left_marker_num; i++){
        x=(int)left_world[i].x;
        z=(int)left_world[i].y;
        circle(View, Point(x, z), 5, Scalar(255,0,0), 2,8);
    }

    for(int i=0; i<right_marker_num; i++){
        x=(int)right_world[i].x;
        z=(int)right_world[i].y;
        circle(View, Point(x, z), 5, Scalar(0,0,255), 2,8);
    }
}

void displayTOPView(Mat TOPView, int left_valid, int right_valid, float *left_coeff, float* right_coeff, float X_MIN, float Z_MIN, int X_NUM, int Z_NUM, float GRID)
{
    float x1, x2;
    float z1, z2;

    int nx1, nx2;
    int nz1, nz2;


    if(left_valid != -1){

         x1= left_coeff[0];
         nx1=(int)((x1-X_MIN + GRID*0.5)/GRID);
         nx1= max(nx1, 0);
         nx1= min(nx1, X_NUM-1);

         z1=0;
         nz1=(int)((z1-Z_MIN + GRID*0.5)/GRID);
         nz1= max(nz1, 0);
         nz1= min(nz1, Z_NUM-1);
         nz1 = Z_NUM-1-nz1;

        int cnt = 1;
        for(float z=0;z<=10; z=z+1)
        {
             x2 = left_coeff[2]*z*z+left_coeff[1]*z + left_coeff[0];
             nx2=(int)((x2-X_MIN + GRID*0.5)/GRID);

             if(nx2<0 || nx2>X_NUM-1) break;


             z2=z;
             nz2=(int)((z2-Z_MIN + GRID*0.5)/GRID);
             nz2= max(nz2, 0);
             nz2= min(nz2, Z_NUM-1);
             nz2 = Z_NUM-1-nz2;

             line(TOPView, Point(nx1, nz1), Point(nx2, nz2), Scalar(255,0,0), 1);
             //printf("cnt = %d", cnt);
             cnt++;
             //printf("Left :(nx1,nz1)=(%d, %d), (nx2,nz2)=(%d,%d)",nx1,nz1,nx2,nz2);
             nx1=nx2;
             nz1=nz2;

        }

    }


    if(right_valid != -1){

         x1= right_coeff[0];
         nx1=(int)((x1-X_MIN + GRID*0.5)/GRID);
         nx1= max(nx1, 0);
         nx1= min(nx1, X_NUM-1);

         z1=0;
         nz1=(int)((z1-Z_MIN + GRID*0.5)/GRID);
         nz1 = Z_NUM-1-nz1;

        for(float z=0;z<=10; z=z+1)
        {
             x2 = right_coeff[2]*z*z+right_coeff[1]*z + right_coeff[0];
             nx2=(int)((x2-X_MIN + GRID*0.5)/GRID);

             if(nx2<0 || nx2>X_NUM-1) break;

             z2=z;
             nz2=(int)((z2-Z_MIN + GRID*0.5)/GRID);
             nz2 = Z_NUM-1-nz2;

             line(TOPView, Point(nx1, nz1), Point(nx2, nz2), Scalar(0,0,255), 1);
            //printf("Right :(nx1,nz1)=(%d,%d), (nx2,nz2)=(%d,%d)",nx1,nz1,nx2,nz2);
             nx1=nx2;
             nz1=nz2;

        }

    }

}

void display1stTOPView(Mat TOPView, int left_valid, int right_valid, float *left_coeff, float* right_coeff, float X_MIN, float Z_MIN, int X_NUM, int Z_NUM, float GRID)
{
    float x1, x2;
    float z1, z2;

    int nx1, nx2;
    int nz1, nz2;


    if(left_valid != -1){

         x1= left_coeff[0];
         nx1=(int)((x1-X_MIN + GRID*0.5)/GRID);
         nx1= max(nx1, 0);
         nx1= min(nx1, X_NUM-1);

         z1=0;
         nz1=(int)((z1-Z_MIN + GRID*0.5)/GRID);
         nz1= max(nz1, 0);
         nz1= min(nz1, Z_NUM-1);
         nz1 = Z_NUM-1-nz1;

        int cnt = 1;
        for(float z=0;z<=10; z=z+1)
        {
             x2 = left_coeff[1]*z + left_coeff[0];
             nx2=(int)((x2-X_MIN + GRID*0.5)/GRID);

             if(nx2<0 || nx2>X_NUM-1) break;


             z2=z;
             nz2=(int)((z2-Z_MIN + GRID*0.5)/GRID);
             nz2= max(nz2, 0);
             nz2= min(nz2, Z_NUM-1);
             nz2 = Z_NUM-1-nz2;

             line(TOPView, Point(nx1, nz1), Point(nx2, nz2), Scalar(255,0,0), 1);
             //printf("cnt = %d", cnt);
             cnt++;
             //printf("Left :(nx1,nz1)=(%d, %d), (nx2,nz2)=(%d,%d)",nx1,nz1,nx2,nz2);
             nx1=nx2;
             nz1=nz2;

        }

    }


    if(right_valid != -1){

         x1= right_coeff[0];
         nx1=(int)((x1-X_MIN + GRID*0.5)/GRID);
         nx1= max(nx1, 0);
         nx1= min(nx1, X_NUM-1);

         z1=0;
         nz1=(int)((z1-Z_MIN + GRID*0.5)/GRID);
         nz1 = Z_NUM-1-nz1;

        for(float z=0;z<=10; z=z+1)
        {
             x2 = right_coeff[1]*z + right_coeff[0];
             nx2=(int)((x2-X_MIN + GRID*0.5)/GRID);

             if(nx2<0 || nx2>X_NUM-1) break;

             z2=z;
             nz2=(int)((z2-Z_MIN + GRID*0.5)/GRID);
             nz2 = Z_NUM-1-nz2;

             line(TOPView, Point(nx1, nz1), Point(nx2, nz2), Scalar(0,0,255), 1);
            //printf("Right :(nx1,nz1)=(%d,%d), (nx2,nz2)=(%d,%d)",nx1,nz1,nx2,nz2);
             nx1=nx2;
             nz1=nz2;

        }

    }

}

void displayGPP(Mat TOPView, float* gpp,float X_MIN, float Z_MIN, int X_NUM, int Z_NUM, float GRID)
{
    float x, z;
    int nx, nz;

    x = gpp[0];
    z = gpp[1];
    nx = (int)((x-X_MIN + GRID*0.5)/GRID);
    nz = (int)((z-Z_MIN + GRID*0.5)/GRID);
    nz = Z_NUM-1-nz;
    circle(TOPView, Point(nx, nz), 3, Scalar(0,255,0), 1);

}
void displayGPP2(Mat TOPView, float* gpp, float* tpl, float*tpr, float X_MIN, float Z_MIN, int X_NUM, int Z_NUM, float GRID)
{
    float x, z;
    int nx, nz, nx1, nx2, nz1, nz2;

    x = gpp[0];
    z = gpp[1];
    nx = (int)((x-X_MIN + GRID*0.5)/GRID);
    nz = (int)((z-Z_MIN + GRID*0.5)/GRID);
    nz = Z_NUM-1-nz;
    circle(TOPView, Point(nx, nz), 3, Scalar(0,255,0), 1);

    x = tpl[0];
    z = Z_MIN ;
    nx1 = (int)((x-X_MIN + GRID*0.5)/GRID);
    nz1 = (int)((z-Z_MIN + GRID*0.5)/GRID);
    nz1= Z_NUM-1-nz1;
    circle(TOPView, Point(nx1, nz1), 3, Scalar(255,255,255), 1);

    x = tpl[1];
    z = gpp[1];
    nx2 = (int)((x-X_MIN + GRID*0.5)/GRID);
    nz2 = (int)((z-Z_MIN + GRID*0.5)/GRID);
    nz2 = Z_NUM-1-nz2;
    circle(TOPView, Point(nx2, nz2), 3, Scalar(255,255,255), 1);

    //Add line
    line(TOPView, Point(nx1, nz1), Point(nx2, nz2), Scalar(255,255,255), 1);

    x = tpr[0];
    z = Z_MIN;
    nx1 = (int)((x-X_MIN + GRID*0.5)/GRID);
    nz1 = (int)((z-Z_MIN + GRID*0.5)/GRID);
    nz1 = Z_NUM-1-nz1;
    circle(TOPView, Point(nx1, nz1), 3, Scalar(255,255,255), 1);

    x = tpr[1];
    z = gpp[1];
    nx2 = (int)((x-X_MIN + GRID*0.5)/GRID);
    nz2 = (int)((z-Z_MIN + GRID*0.5)/GRID);
    nz2 = Z_NUM-1-nz2;
    circle(TOPView, Point(nx2, nz2), 3, Scalar(255,255,255), 1);

    //Add line
     line(TOPView, Point(nx1, nz1), Point(nx2, nz2), Scalar(255,255,255), 1);
}


