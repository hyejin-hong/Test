#ifndef CSTUBAUTO_UGVSHUTDOWNREQUEST_H
#define CSTUBAUTO_UGVSHUTDOWNREQUEST_H

#include <CFW.h>
#include <Core/DevLib/Include/IO/CLogWriter/CLogWriter.h>

// ICD Data
#include "../../../Data/Common/Auto_UGVShutdownRequest.h"

namespace AUTONOMOUS
{
namespace Interface
{
namespace Common
{

class CStubAuto_UGVShutdownRequest
{
public :
    CStubAuto_UGVShutdownRequest();
    virtual ~CStubAuto_UGVShutdownRequest();

    inline void WriteAuto_UGVShutdownRequest(AUTONOMOUS::Data::Common::StAuto_UGVShutdownRequestComm& data)
    {
        data.message_type   = MSG_TYPE_COMMON;
        data.message_ID     = MSG_CODE_COMMON_AUTO_UGVSHUTDOWNREQUEST;
        data.QoS            = MSG_QOS_COMMON_AUTO_UGVSHUTDOWNREQUEST;
        data.SN             = m_snStubAuto_UGVShutdownRequest++;

        AUTONOMOUS::COMMLIB::CFW::GetInstance().Send(data);

        if( m_logStubAuto_UGVShutdownRequest.IsRun() )
        {
            m_vBuffStubAuto_UGVShutdownRequest.clear();
            data.getFrameData(m_vBuffStubAuto_UGVShutdownRequest);
            m_logStubAuto_UGVShutdownRequest.WriteData(m_vBuffStubAuto_UGVShutdownRequest.data(), m_vBuffStubAuto_UGVShutdownRequest.size());
        }
    }

    // Log
    bool CreateLogStubAuto_UGVShutdownRequest(char* logName);
    void CloseLogStubAuto_UGVShutdownRequest();

private:
    std::vector<uint8_t>   m_vBuffStubAuto_UGVShutdownRequest;
    uint8_t                m_snStubAuto_UGVShutdownRequest;
protected:
    DevLib::IO::CLogWriter m_logStubAuto_UGVShutdownRequest;
};


}
}
}

#endif /* CSTUBAUTO_UGVSHUTDOWNREQUEST_H */
