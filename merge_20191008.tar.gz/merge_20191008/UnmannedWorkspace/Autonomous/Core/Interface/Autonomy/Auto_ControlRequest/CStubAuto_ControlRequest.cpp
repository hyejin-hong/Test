#include "CStubAuto_ControlRequest.h"

namespace AUTONOMOUS
{
namespace Interface
{
namespace Autonomy
{

CStubAuto_ControlRequest::CStubAuto_ControlRequest()
{
    m_snStubAuto_ControlRequest = 0;
}

CStubAuto_ControlRequest::~CStubAuto_ControlRequest()
{ 

}

bool CStubAuto_ControlRequest::CreateLogStubAuto_ControlRequest(char *logName)
{
    char fname[1024] = "";
    sprintf(fname, "./%s.Auto_ControlRequest", logName);

    return m_logStubAuto_ControlRequest.Create(fname);
}

void CStubAuto_ControlRequest::CloseLogStubAuto_ControlRequest()
{
    m_logStubAuto_ControlRequest.Destroy();
}


}
}
}
