/*
 * CFMCWObject.cpp
 *
 *  Created on: 2019. 4. 4.
 *      Author: fme
 */
#include "CFMCWObject.h"


namespace UNMANNED
{
namespace Device
{
namespace FMCW
{

CFMCWObject::CFMCWObject(CObserverFMCWObject* pObserver)
 : m_pObserverFMCWObject(pObserver), m_serialFd(0)
{
}

CFMCWObject::~CFMCWObject()
{
}

bool CFMCWObject::Create(char* bindIP, int port)
{
	bool bRet = false;

	int serialNumber = PortOpen(bindIP, port);
	if(serialNumber != -1)
	{
		ServiceStart();
	}
	return bRet;

}

void CFMCWObject::Run()
{
	char line[25];
	char temp;
	int res, i;
	bool first = true;
	bool dataRecvStart = false;

	while(true){
		read(m_serialFd, &temp, sizeof(temp));

		if(first)
		{
			if(temp == 't')
			{
				first = false;
                m_readData.push_back(temp);
			}
		}
		else
		{
			if(int(temp) == 13)
			{
				char hexCanId[10] = "0x";

				if(m_readData.size() != 25)
				{
					m_readData.clear();
					continue;
				}

				memcpy(line, m_readData.data(), 25);

				m_readData.clear();
				if(line[0] != 't')
				{
					exit(0);
					m_readData.clear();
					continue;
				}


				char canId[3];
				memcpy(canId, &line[1],3);

				strcat(hexCanId, canId);

				unsigned int id = strtol(hexCanId, NULL, 16);



				int dataByteSize = line[4] - '0';
				if(dataByteSize != 8)
				{
					m_readData.clear();
					continue;
				}

				if(dataRecvStart)
				{
					if( 0x500 <= id && id <= 0x53F)
					{

                        UNMANNED::Data::Sensor::StFMCWRadar fmcwdata;

						fmcwdata.can_id = id;

						for(int i=0;i<dataByteSize; i++)
						{
							memset(hexCanId, 0x00, sizeof(hexCanId));

							memcpy(hexCanId, "0x", 2);

							char data[2];

							memcpy(data, &line[5+(i*2)], 2);

							strcat(hexCanId, data);

							int radarData = strtol(hexCanId, NULL, 16);

							unsigned char convertedRadarData= radarData;
							fmcwdata.dataByte[dataByteSize-(i+1)] = convertedRadarData;

						}
						if( m_pObserverFMCWObject )
						{
							m_pObserverFMCWObject->OnFMCWPack(&fmcwdata);
						}
					}
					else
					{
						m_readData.clear();
						continue;
					}
				}
				else
				{
					if( id == 0x500 )
					{
						dataRecvStart = true;

                        UNMANNED::Data::Sensor::StFMCWRadar fmcwdata;

						fmcwdata.can_id = id;

						for(int i=0;i<dataByteSize; i++)
						{
							memset(hexCanId, 0x00, sizeof(hexCanId));

							memcpy(hexCanId, "0x", 2);

							char data[2];

							memcpy(data, &line[5+(i*2)], 2);

							strcat(hexCanId, data);

							int radarData = strtol(hexCanId, NULL, 16);

							unsigned char convertedRadarData= radarData;
							fmcwdata.dataByte[dataByteSize-(i+1)] = convertedRadarData;

						}
						if( m_pObserverFMCWObject )
						{
							m_pObserverFMCWObject->OnFMCWPack(&fmcwdata);
						}
					}
					else
					{
						m_readData.clear();
						continue;
					}
				}

				m_readData.clear();
			}
			else if(int(temp) == 63)
			{
				continue;
			}
			else
			{
                m_readData.push_back(temp);
			}
		}
	}

}

int CFMCWObject::PortOpen(const char* dev_name, speed_t baud_rate)
{
	   struct termios ttycfg;

	    /* Open a dummy port with non-blocking I/O */
	    if ((m_serialFd = open(dev_name,  O_RDWR|O_NOCTTY , 0666)) == -1)
	    {
	        printf("Open '%s' failed, errno=%d\n", dev_name, errno);
	        return m_serialFd;
	    }
	    else
	    {
	    	printf("Serial Open Success : %d \n", m_serialFd);
	    }


	    // Get Current setting
	    if (tcgetattr(m_serialFd, &ttycfg) < 0)
	    {
	        printf("Get port attr '%s' failed, errno=%d\n", dev_name, errno);
	        close(m_serialFd);
	        return m_serialFd;
	    }

	    // copy
	    //memcpy(&m_newtset, &m_oldtset, sizeof( m_oldtset ));

	    /*
	     * Initialize the port configuration parameters
	     */
	    ttycfg.c_iflag = 0;             /* clear input modes (raw) */
	    ttycfg.c_oflag = 0;             /* clear output modes (raw) */
	    ttycfg.c_lflag = 0;             /* clear line disciplines (raw) */
	    ttycfg.c_cc[VMIN] = 0;
	    ttycfg.c_cc[VTIME] = 1;
	    ttycfg.c_cflag = 0;             /* clear out port control bits */
	    ttycfg.c_cflag = CLOCAL|CREAD;	/* direct connect (no modem) */


	    /* receiver is enabled */
	    /* Clear out the size, stop and parity enable bits */
	    ttycfg.c_cflag &= ~(CSIZE|CSTOPB|PARENB);

	    /* baud rate configurable thru */
	    /* Set those baud rates for input and output */
	    cfsetispeed(&ttycfg, (speed_t) baud_rate);
	    cfsetospeed(&ttycfg, (speed_t) baud_rate);

	    /* Set the parity bit */
	    ttycfg.c_cflag &= ~PARENB;          /* parity disable */

	    /* Set the character size */
	    ttycfg.c_cflag |= CS8;

	    /* Set the stop bits */
	    ttycfg.c_cflag &= ~CSTOPB;          /* 1 stop bit */

	    tcflush(m_serialFd, TCIFLUSH);

	    /* Program the port with our configuration */
	    if (::tcsetattr(m_serialFd, TCSAFLUSH, &ttycfg) < 0) {
	        printf("tcsetattr on '%s' failed, errno=%d\n", dev_name, errno);
	        close(m_serialFd);
	        return false;
	    }



	    return m_serialFd;
}


}
}
}

