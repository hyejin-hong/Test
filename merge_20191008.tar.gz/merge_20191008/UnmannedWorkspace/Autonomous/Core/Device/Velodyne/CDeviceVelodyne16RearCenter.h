#ifndef CDEVICEVELODYNE16REARCENTER_H
#define CDEVICEVELODYNE16REARCENTER_H

#include "CVelodyneObject.h"

namespace AUTONOMOUS
{
namespace Device
{
namespace Velodyne
{

class CDeviceVelodyne16RearCenter : public AUTONOMOUS::Device::Velodyne::CObserverVelodyneObject
{
public:
	CDeviceVelodyne16RearCenter()
	: m_devVelodyne16RearCenter(this)
	{
	}

	virtual ~CDeviceVelodyne16RearCenter()
	{
	}

	virtual void OnVelodynePackRearCenter(AUTONOMOUS::Device::Velodyne::StVelodynePacket* pVelodynePack) = 0;
	virtual void OnVelodyneStatusRearCenter(AUTONOMOUS::Device::Velodyne::StVelodyneStatus* pVelodyneStatus) = 0;
    virtual void OnEMountRearCenter(AUTONOMOUS::Device::Velodyne::StEMount* pEMount) = 0;

	AUTONOMOUS::Device::Velodyne::CVelodyneObject* GetDeviceVelodyne16RearCenter() { return &m_devVelodyne16RearCenter; }

private :
	AUTONOMOUS::Device::Velodyne::CVelodyneObject 	m_devVelodyne16RearCenter;

	virtual void OnVelodynePack(AUTONOMOUS::Device::Velodyne::StVelodynePacket* pVelodynePack)
	{
		OnVelodynePackRearCenter(pVelodynePack);
	}

	virtual void OnVelodyneStatus(AUTONOMOUS::Device::Velodyne::StVelodyneStatus* pVelodyneStatus)
	{
		OnVelodyneStatusRearCenter(pVelodyneStatus);
	}

    virtual void OnEMount(AUTONOMOUS::Device::Velodyne::StEMount* pEMount)
    {
        OnEMountRearCenter(pEMount);
    }
};

}
}
}

#endif /* CDEVICEVELODYNE16REARCENTER_H */
