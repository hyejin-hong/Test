#include "../../../Include/Core/CThread/CThread.h"

#include <pthread.h>

namespace DevLib
{

static void* ThreadCaller(void *pParam)
{
	CThread* pThis = (CThread*)pParam;

	pThis->Run();

	return 0;
}

CThread::CThread()
: m_bRun(false), m_Thread(0)
{
}

CThread::~CThread()
{
	ServiceStop();
}

bool CThread::ServiceStart(THREAD_CALLBACK pCallback, void* pParam)
{
	bool bRet = false;

	if(IsRun() == false)
	{
		m_param.pCallBack	= pCallback;
		m_param.pParam 	= pParam;

		if(pthread_create(&m_Thread, NULL, ThreadCaller,this) == 0)
		{
			m_bRun = true;
			bRet = true;
		}
	}

	return bRet;
}

void CThread::ServiceStop()
{
	m_bRun = false;
}

bool CThread::IsRun()
{
	return m_bRun;
}

void CThread::WaitForEndThread()
{
	void* pRet = 0;
	pthread_join(m_Thread, (void **)&pRet);
}

void CThread::Run()
{
	if( m_param.pCallBack ) m_param.pCallBack(m_param.pParam);
}

}
