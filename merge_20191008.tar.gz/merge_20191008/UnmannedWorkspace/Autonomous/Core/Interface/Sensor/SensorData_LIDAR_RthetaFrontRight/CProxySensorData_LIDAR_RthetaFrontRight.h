#ifndef CPROXYESENSORDATA_LIDAR_RTHETAFRONTRIGHT_H
#define CPROXYESENSORDATA_LIDAR_RTHETAFRONTRIGHT_H

#include <Core/DevLib/Include/IO/CLogWriter/CLogWriter.h>

// ICD Data
#include "../../../Data/Sensor/SensorData_LIDAR_Rtheta.h"

namespace AUTONOMOUS
{
namespace Interface
{
namespace Sensor
{

class CProxySensorData_LIDAR_RthetaFrontRight
{
public :
    CProxySensorData_LIDAR_RthetaFrontRight();
    virtual ~CProxySensorData_LIDAR_RthetaFrontRight();

    virtual void OnSensorData_LIDAR_RthetaFrontRight(AUTONOMOUS::Data::Sensor::StSensorData_LIDAR_RthetaComm& data) = 0;

    // Log
    bool CreateLogProxySensorData_LIDAR_RthetaFrontRight(char* logName);
    void CloseLogProxySensorData_LIDAR_RthetaFrontRight();

private:
    std::vector<uint8_t>   m_vBuffProxySensorData_LIDAR_RthetaFrontRight;
protected:
    DevLib::IO::CLogWriter m_logProxySensorData_LIDAR_RthetaFrontRight;

    void _OnSensorData_LIDAR_RthetaFrontRight(AUTONOMOUS::Data::Sensor::StSensorData_LIDAR_RthetaComm& data);
};


}
}
}

#endif /* CPROXYESENSORDATA_LIDAR_RTHETAFRONTRIGHT_H */
