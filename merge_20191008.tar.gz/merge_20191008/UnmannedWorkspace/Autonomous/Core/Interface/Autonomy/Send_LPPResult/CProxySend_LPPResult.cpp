#include "CProxySend_LPPResult.h"

namespace AUTONOMOUS
{
namespace Interface
{
namespace Autonomy
{

CProxySend_LPPResult::CProxySend_LPPResult()
{
    AUTONOMOUS::COMMLIB::CFW::GetInstance().RegisterSub(MSG_CODE_AUTONOMY_SEND_LPPRESULT, &CProxySend_LPPResult::_OnSend_LPPResult, this);
}

CProxySend_LPPResult::~CProxySend_LPPResult()
{

}

bool CProxySend_LPPResult::CreateLogProxySend_LPPResult(char *logName)
{
    char fname[1024] = "";
    sprintf(fname, "./%s.Send_LPPResult", logName);

    return m_logProxySend_LPPResult.Create(fname);
}

void CProxySend_LPPResult::CloseLogProxySend_LPPResult()
{
    m_logProxySend_LPPResult.Destroy();
}

void CProxySend_LPPResult::_OnSend_LPPResult(AUTONOMOUS::Data::Autonomy::StSend_LPPResultComm& data)
{
    OnSend_LPPResult(data);
    if( m_logProxySend_LPPResult.IsRun() )
    {
        m_vBuffProxySend_LPPResult.clear();
        data.getFrameData(m_vBuffProxySend_LPPResult);
        m_logProxySend_LPPResult.WriteData(m_vBuffProxySend_LPPResult.data(), m_vBuffProxySend_LPPResult.size());
    }
}

}
}
}
