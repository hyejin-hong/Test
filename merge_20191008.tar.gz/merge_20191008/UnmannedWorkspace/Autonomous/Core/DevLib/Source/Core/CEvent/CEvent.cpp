#include "../../../Include/Core/CEvent/CEvent.h"

namespace DevLib
{

#include <semaphore.h>			// sem_wait, sem_post
#include <time.h>			// clock_gettime
#include <fcntl.h>			// O_CREAT, O_EXCL
#include <errno.h>			// EEXIST
#include <pthread.h>			// pthread_mutex_t, pthread_cond_t
#include <stdlib.h>			// NULL	

typedef struct {
    pthread_mutex_t mutex;
    pthread_cond_t cond;
} PEVENT;

typedef struct {
    sem_t *sem;
} SEVENT;


CEvent::CEvent()
    : m_bCreated(false), m_cntMax(0), m_cntCurrent(0), m_eventName(NULL)
{
    m_pEvent = new PEVENT;
    m_sEvent = new SEVENT;
}

CEvent::~CEvent()
{
    if( IsCreated() ) Destroy();

    delete (PEVENT *)m_pEvent;
    delete (SEVENT *)m_sEvent;
}

bool CEvent::Create(char* name)
{
    bool bRet = false;

    m_eventName = name;

    if(m_eventName == NULL)
    {
        PEVENT* pEvent = (PEVENT*)m_pEvent;

        if(pthread_mutex_init(&pEvent->mutex, 0) == 0)
        {
            if(pthread_cond_init(&pEvent->cond, 0) == 0)
            {
                bRet = true;
                m_bCreated = true;
            }
        }
    }
    else
    {
        SEVENT* sEvent = (SEVENT*)m_sEvent;

        if((sEvent->sem = sem_open(name, O_CREAT | O_EXCL, 0666, 1)) == SEM_FAILED)
        {
            if (errno == EEXIST)
            {
                sEvent->sem = sem_open(name, 0, 0666, 0);

                bRet = true;

                m_bCreated = true;
            }
        }
        else
        {
            bRet = true;

            m_bCreated = true;
        }

        m_cntMax = 1;

        sem_getvalue(sEvent->sem, &m_cntCurrent);
    }
    return bRet;
}

void CEvent::Destroy()
{    
    if(m_eventName == NULL)
    {
        PEVENT* pEvent = (PEVENT*)m_pEvent;

        pthread_mutex_destroy(&pEvent->mutex);

        pthread_cond_destroy(&pEvent->cond);
    }
    else
    {
        SEVENT* sEvent = (SEVENT*)m_sEvent;

        sem_close(sEvent->sem);

        sem_unlink(m_eventName);
    }

    m_bCreated = false;
}

bool CEvent::IsCreated()
{
    return m_bCreated;
}

void CEvent::ResetEvent()
{
    // First, Coding Auto Setting
}

void CEvent::SetEvent()
{
    if(IsCreated())
    {
        if(m_eventName == NULL)
        {
            PEVENT* pEvent = (PEVENT*)m_pEvent;

            pthread_mutex_lock(&pEvent->mutex);

            pthread_cond_signal(&pEvent->cond);

            pthread_mutex_unlock(&pEvent->mutex);
        }
        else
        {
            SEVENT* sEvent = (SEVENT*)m_sEvent;

            if(m_cntCurrent < m_cntMax)
            {
                sem_post(sEvent->sem);
            }

            sem_getvalue(sEvent->sem, &m_cntCurrent);
        }
    }

}

bool CEvent::WaitForEvent(int msTime)
{
    bool bRet = false;

    if(IsCreated())
    {
        timespec _wait;

        clock_gettime(CLOCK_REALTIME, &_wait);

        _wait.tv_sec += (long)(msTime * 0.001);
        _wait.tv_nsec += (msTime%1000) * 1000000;

        if(m_eventName == NULL)
        {
            PEVENT* pEvent = (PEVENT*)m_pEvent;

            pthread_mutex_lock(&pEvent->mutex);

            if( pthread_cond_timedwait(&pEvent->cond, &pEvent->mutex, &_wait) == 0 )
            {
                bRet = true;
            }

            pthread_mutex_unlock(&pEvent->mutex);
        }
        else
        {
            SEVENT* sEvent = (SEVENT*)m_sEvent;

            if(sem_timedwait(sEvent->sem, &_wait) == 0)
            {
                bRet = true;
            }

            sem_getvalue(sEvent->sem, &m_cntCurrent);
        }
    }


    return bRet;
}

}
