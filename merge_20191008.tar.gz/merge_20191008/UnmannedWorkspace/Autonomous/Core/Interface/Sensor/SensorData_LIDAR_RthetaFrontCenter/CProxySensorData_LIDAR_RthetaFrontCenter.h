#ifndef CPROXYESENSORDATA_LIDAR_RTHETAFRONTCENTER_H
#define CPROXYESENSORDATA_LIDAR_RTHETAFRONTCENTER_H

#include <Core/DevLib/Include/IO/CLogWriter/CLogWriter.h>

// ICD Data
#include "../../../Data/Sensor/SensorData_LIDAR_Rtheta.h"

namespace AUTONOMOUS
{
namespace Interface
{
namespace Sensor
{

class CProxySensorData_LIDAR_RthetaFrontCenter
{
public :
    CProxySensorData_LIDAR_RthetaFrontCenter();
    virtual ~CProxySensorData_LIDAR_RthetaFrontCenter();

    virtual void OnSensorData_LIDAR_RthetaFrontCenter(AUTONOMOUS::Data::Sensor::StSensorData_LIDAR_RthetaComm& data) = 0;

    // Log
    bool CreateLogProxySensorData_LIDAR_RthetaFrontCenter(char* logName);
    void CloseLogProxySensorData_LIDAR_RthetaFrontCenter();

private:
    std::vector<uint8_t>   m_vBuffProxySensorData_LIDAR_RthetaFrontCenter;
protected:
    DevLib::IO::CLogWriter m_logProxySensorData_LIDAR_RthetaFrontCenter;

    void _OnSensorData_LIDAR_RthetaFrontCenter(AUTONOMOUS::Data::Sensor::StSensorData_LIDAR_RthetaComm& data);
};


}
}
}

#endif /* CPROXYESENSORDATA_LIDAR_RTHETAFRONTCENTER_H */
