#ifndef CSEMAPHORE_H
#define CSEMAPHORE_H


namespace DevLib
{



#include <limits>

class CSemaphore
{
public:
	CSemaphore();
	virtual ~CSemaphore();

	bool Create(int max, char *name);
	void Destroy();

	int GetMaxKeyCount();
	int GetRemainKeyCount();

	bool IsCreated();

	void ReturnSemaphore();
	bool WaitForSemaphore(int secTime);

private:
	int m_cntCurrentKey;	
	
	int m_cntMaxKey;

	char *m_semName;
	bool m_bCreated;
	void* m_hSem;

};
}

#endif	/*	CSEMAPHORE_H		*/
