#include "CProxyAuto_ComponentStatus.h"

namespace AUTONOMOUS
{
namespace Interface
{
namespace Common
{

CProxyAuto_ComponentStatus::CProxyAuto_ComponentStatus()
{
    AUTONOMOUS::COMMLIB::CFW::GetInstance().RegisterSub(MSG_CODE_COMMON_AUTO_COMPONENTSTATUS, &CProxyAuto_ComponentStatus::_OnAuto_ComponentStatus, this);
}

CProxyAuto_ComponentStatus::~CProxyAuto_ComponentStatus()
{

}

bool CProxyAuto_ComponentStatus::CreateLogProxyAuto_ComponentStatus(char *logName)
{
    char fname[1024] = "";
    sprintf(fname, "./%s.Auto_ComponentStatus", logName);

    return m_logProxyAuto_ComponentStatus.Create(fname);
}

void CProxyAuto_ComponentStatus::CloseLogProxyAuto_ComponentStatus()
{
    m_logProxyAuto_ComponentStatus.Destroy();
}

void CProxyAuto_ComponentStatus::_OnAuto_ComponentStatus(AUTONOMOUS::Data::Common::StAuto_ComponentStatusComm& data)
{
    OnAuto_ComponentStatus(data);
    if( m_logProxyAuto_ComponentStatus.IsRun() )
    {
        m_vBuffProxyAuto_ComponentStatus.clear();
        data.getFrameData(m_vBuffProxyAuto_ComponentStatus);
        m_logProxyAuto_ComponentStatus.WriteData(m_vBuffProxyAuto_ComponentStatus.data(), m_vBuffProxyAuto_ComponentStatus.size());
    }
}

}
}
}
