#ifndef CSTUBSENSORDATA_LIDAR_RTHETAREARCENTER_H
#define CSTUBSENSORDATA_LIDAR_RTHETAREARCENTER_H

#include <CFW.h>
#include <Core/DevLib/Include/IO/CLogWriter/CLogWriter.h>

// ICD Data
#include "../../../Data/Sensor/SensorData_LIDAR_Rtheta.h"

namespace AUTONOMOUS
{
namespace Interface
{
namespace Sensor
{

class CStubSensorData_LIDAR_RthetaRearCenter
{
public :
    CStubSensorData_LIDAR_RthetaRearCenter();
    virtual ~CStubSensorData_LIDAR_RthetaRearCenter();

    inline void WriteSensorData_LIDAR_RthetaRearCenter(AUTONOMOUS::Data::Sensor::StSensorData_LIDAR_RthetaComm& data)
    {
        data.message_type   = MSG_TYPE_SENSOR;
        data.message_ID     = MSG_CODE_SENSOR_SENSORDATA_LIDAR_RTHETAREARCENTER;
        data.QoS            = MSG_QOS_SENSOR_SENSORDATA_LIDAR_RTHETAREARCENTER;
        data.SN             = m_snStubSensorData_LIDAR_RthetaRearCenter++;

        AUTONOMOUS::COMMLIB::CFW::GetInstance().Send(data);

        if( m_logStubSensorData_LIDAR_RthetaRearCenter.IsRun() )
        {
            m_vBuffStubSensorData_LIDAR_RthetaRearCenter.clear();
            data.getFrameData(m_vBuffStubSensorData_LIDAR_RthetaRearCenter);
            m_logStubSensorData_LIDAR_RthetaRearCenter.WriteData(m_vBuffStubSensorData_LIDAR_RthetaRearCenter.data(), m_vBuffStubSensorData_LIDAR_RthetaRearCenter.size());
        }
    }

    // Log
    bool CreateLogStubSensorData_LIDAR_RthetaRearCenter(char* logName);
    void CloseLogStubSensorData_LIDAR_RthetaRearCenter();

private:
    std::vector<uint8_t>   m_vBuffStubSensorData_LIDAR_RthetaRearCenter;
    uint8_t                m_snStubSensorData_LIDAR_RthetaRearCenter;
protected:
    DevLib::IO::CLogWriter m_logStubSensorData_LIDAR_RthetaRearCenter;
};


}
}
}

#endif /* CSTUBSENSORDATA_LIDAR_RTHETAREARCENTER_H */
