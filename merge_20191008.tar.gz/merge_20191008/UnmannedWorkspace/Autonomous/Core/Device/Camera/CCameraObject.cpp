/*
 * CCameraObject.cpp
 *
 *  Created on: 2019. 4. 8.
 *      Author: fme
 */

#include "CCameraObject.h"

#include <stdlib.h>
#include <stdio.h>

namespace AUTONOMOUS
{
namespace Device
{
namespace Camera
{


CCameraObject::CCameraObject(CObserverCameraObject* pObserver)
 : m_pObserverCameraObject(pObserver), client(0), check(true)
{
//	m_bufferImage.resize(480 * 360 * 3);
}

CCameraObject::~CCameraObject()
{
}

bool CCameraObject::Create(int port, char* ip)
{
	bool bRet = false;
	if( DevLib::IO::CSocketReceiver::Create(DevLib::IO::CSocket::SOCK_TCP) )
	{
		SetOptionReuse(true);
		SetOptionNagle(true);
		if( DevLib::IO::CSocket::Connect(port, ip))
		{

			printf("Camera Sender Create Socket \n");
			bRet = true;
			Listen(5);

			ServiceStart();
		}
		else
		{
			printf("Connect Error \n");
		}
	}

	return bRet;
}


void CCameraObject::OnReceive()
{

	unsigned int nRecv = 0;
	int nCount = 0;

	while (nRecv < sizeof(m_bufferImage))
	{
		nCount = Recv(&m_bufferImage[nRecv], sizeof(m_bufferImage) - nRecv);

		if (nCount == 0)
		{
			break;
		}

		nRecv += nCount;


	}
	if( m_pObserverCameraObject )
	{
		if( nRecv == sizeof(m_bufferImage))
		{
			m_pObserverCameraObject->OnCameraPack(m_bufferImage);
		}
	}
	if (nRecv == 0)
	{
		client = 0;
	}

}




}
}
}

