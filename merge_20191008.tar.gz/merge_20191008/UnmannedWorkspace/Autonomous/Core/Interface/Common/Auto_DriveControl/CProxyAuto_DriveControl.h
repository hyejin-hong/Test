#ifndef CPROXYEAUTO_DRIVECONTROL_H
#define CPROXYEAUTO_DRIVECONTROL_H

#include <Core/DevLib/Include/IO/CLogWriter/CLogWriter.h>

// ICD Data
#include "../../../Data/Common/Auto_DriveControl.h"

namespace AUTONOMOUS
{
namespace Interface
{
namespace Common
{

class CProxyAuto_DriveControl
{
public :
    CProxyAuto_DriveControl();
    virtual ~CProxyAuto_DriveControl();

    virtual void OnAuto_DriveControl(AUTONOMOUS::Data::Common::StAuto_DriveControlComm& data) = 0;

    // Log
    bool CreateLogProxyAuto_DriveControl(char* logName);
    void CloseLogProxyAuto_DriveControl();

private:
    std::vector<uint8_t>   m_vBuffProxyAuto_DriveControl;
protected:
    DevLib::IO::CLogWriter m_logProxyAuto_DriveControl;

    void _OnAuto_DriveControl(AUTONOMOUS::Data::Common::StAuto_DriveControlComm& data);
};


}
}
}

#endif /* CPROXYEAUTO_DRIVECONTROL_H */
