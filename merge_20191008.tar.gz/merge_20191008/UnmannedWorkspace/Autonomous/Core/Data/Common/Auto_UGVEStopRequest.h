#ifndef AUTO_ESTOPREQUEST_H
#define AUTO_ESTOPREQUEST_H

#include <CFW.h>
#include "../Common/Common.h"

namespace AUTONOMOUS
{
namespace Data
{
namespace Common
{

typedef struct _StESTopInfo
{
    union
    {
        struct
        {
            uint8_t OCS : 1;            // 통제 차량
            uint8_t RCU : 1;            // 휴대형 통제기
            uint8_t WiredSwitch : 1;    // 유선 비상 정지 스위치
            uint8_t WirelessSwitch: 1;  // 무선 비상 정지 스위치

            uint8_t Device : 1;         // 탑승병(차량 플랫폼)
            uint8_t stop : 1;           // 장애물 정지
            uint8_t Break : 1;          // 통신 단절
            uint8_t failure : 1;        // 장비 고장
        } SourceDetail;
        uint8_t Source;
    };
} StEStopInfo;

typedef struct _StAuto_UGVEStopRequest
{
    flt64_t     SyncTime;   // 동기화 시간

    // 비상정지 제어
    // 1 : 비상정지 해제
    // 2 : 비상정지 진입
    uint8_t     Command;    // 비상정지 제어

} StAuto_UGVEStopRequest;


typedef struct _StAuto_UGVEStopRequestComm : public AUTONOMOUS::COMMLIB::Header, public StAuto_UGVEStopRequest
{
    virtual void setFrameData(uint8_t* buff)
    {
        buff = deserializeData(buff, SyncTime);
        buff = deserializeData(buff, Command);
    }

    virtual void getFrameData(std::vector<uint8_t>& buff)
    {
        serializeData(buff, SyncTime);
        serializeData(buff, Command);
    }

} StAuto_UGVEStopRequestComm;

}
}
}

#endif // AUTO_ESTOPREQUEST_H
