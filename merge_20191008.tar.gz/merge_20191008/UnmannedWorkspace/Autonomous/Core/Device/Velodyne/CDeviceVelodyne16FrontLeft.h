#ifndef CDEVICEVELODYNE16FRONTLEFT_H
#define CDEVICEVELODYNE16FRONTLEFT_H

#include "CVelodyneObject.h"

namespace AUTONOMOUS
{
namespace Device
{
namespace Velodyne
{

class CDeviceVelodyne16FrontLeft : public AUTONOMOUS::Device::Velodyne::CObserverVelodyneObject
{
public:
	CDeviceVelodyne16FrontLeft()
	: m_devVelodyne16FrontLeft(this)
	{
	}

	virtual ~CDeviceVelodyne16FrontLeft()
	{
	}

	virtual void OnVelodynePackFrontLeft(AUTONOMOUS::Device::Velodyne::StVelodynePacket* pVelodynePack) = 0;
	virtual void OnVelodyneStatusFrontLeft(AUTONOMOUS::Device::Velodyne::StVelodyneStatus* pVelodyneStatus) = 0;
    virtual void OnEMountFrontLeft(AUTONOMOUS::Device::Velodyne::StEMount* pEMount) = 0;

	AUTONOMOUS::Device::Velodyne::CVelodyneObject* GetDeviceVelodyne16FrontLeft() { return &m_devVelodyne16FrontLeft; }

private :
	AUTONOMOUS::Device::Velodyne::CVelodyneObject 	m_devVelodyne16FrontLeft;

	virtual void OnVelodynePack(AUTONOMOUS::Device::Velodyne::StVelodynePacket* pVelodynePack)
	{
		OnVelodynePackFrontLeft(pVelodynePack);
	}

	virtual void OnVelodyneStatus(AUTONOMOUS::Device::Velodyne::StVelodyneStatus* pVelodyneStatus)
	{
		OnVelodyneStatusFrontLeft(pVelodyneStatus);
	}

    virtual void OnEMount(AUTONOMOUS::Device::Velodyne::StEMount* pEMount)
    {
        OnEMountFrontLeft(pEMount);
    }
};

}
}
}

#endif /* CDEVICEVELODYNE16FRONTLEFT_H */
