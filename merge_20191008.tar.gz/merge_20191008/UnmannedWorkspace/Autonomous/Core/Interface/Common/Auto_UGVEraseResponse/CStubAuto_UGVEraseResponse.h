#ifndef CSTUBAUTO_UGVERASERESPONSE_H
#define CSTUBAUTO_UGVERASERESPONSE_H

#include <CFW.h>
#include <Core/DevLib/Include/IO/CLogWriter/CLogWriter.h>

// ICD Data
#include "../../../Data/Common/Auto_UGVEraseResponse.h"

namespace AUTONOMOUS
{
namespace Interface
{
namespace Common
{

class CStubAuto_UGVEraseResponse
{
public :
    CStubAuto_UGVEraseResponse();
    virtual ~CStubAuto_UGVEraseResponse();

    inline void WriteAuto_UGVEraseResponse(AUTONOMOUS::Data::Common::StAuto_UGVEraseResponseComm& data)
    {
        data.message_type   = MSG_TYPE_COMMON;
        data.message_ID     = MSG_CODE_COMMON_AUTO_UGVERASERESPONSE;
        data.QoS            = MSG_QOS_COMMON_AUTO_UGVERASERESPONSE;
        data.SN             = m_snStubAuto_UGVEraseResponse++;

        AUTONOMOUS::COMMLIB::CFW::GetInstance().Send(data);

        if( m_logStubAuto_UGVEraseResponse.IsRun() )
        {
            m_vBuffStubAuto_UGVEraseResponse.clear();
            data.getFrameData(m_vBuffStubAuto_UGVEraseResponse);
            m_logStubAuto_UGVEraseResponse.WriteData(m_vBuffStubAuto_UGVEraseResponse.data(), m_vBuffStubAuto_UGVEraseResponse.size());
        }
    }

    // Log
    bool CreateLogStubAuto_UGVEraseResponse(char* logName);
    void CloseLogStubAuto_UGVEraseResponse();

private:
    std::vector<uint8_t>   m_vBuffStubAuto_UGVEraseResponse;
    uint8_t                m_snStubAuto_UGVEraseResponse;
protected:
    DevLib::IO::CLogWriter m_logStubAuto_UGVEraseResponse;
};


}
}
}

#endif /* CSTUBAUTO_UGVERASERESPONSE_H */
