#pragma once

#include <math.h>
#include <float.h>

namespace DevLib { namespace Utility
{
        static const double PI =   3.14159265358979323846;
        static const double R2D =  180.0 / PI;
        static const double D2R =  PI / 180.0;

        inline bool IsEqual(double x, double y) { return fabs(x - y) <= (DBL_EPSILON * fabs(x)); }
        inline bool IsEqual(float x, float y) { return fabs(x - y) <= (FLT_EPSILON * fabs(x)); }

        inline double RadianToDegree(double rad){ return rad * R2D; }
        inline float RadianToDegree(float rad){ return rad * (float)R2D; }

        inline double DegreeToRadian(double deg) { return deg * D2R; }
        inline float DegreeToRadian(float  deg) { return deg * (float)D2R; }
} }
