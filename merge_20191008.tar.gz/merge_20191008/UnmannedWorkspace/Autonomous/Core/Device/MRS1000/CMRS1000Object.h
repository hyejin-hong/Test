/*
 * CSickObject.h
 *
 *  Created on: 2019. 4. 23.
 *      Author: fm
 */

#ifndef CMRS1000OBJECT_H_
#define CMRS1000OBJECT_H_

#include "../../DevLib/Include/IO/CSocketClient/CSocketClient.h"
#include "CommonMRS1000.h"

namespace AUTONOMOUS
{
namespace Device
{
namespace MRS1000
{

class CObserverMRS1000
{
public :
    virtual ~CObserverMRS1000() { }

    virtual void OnMRS1000Pack(AUTONOMOUS::Device::MRS1000::StMRS1000Packet* pMRS1000Pack) = 0;
};

class CMRS1000
        : public DevLib::IO::CSocketClient
        , public DevLib::CTimer
{
public:
    CMRS1000(CObserverMRS1000* pObserver = 0);
    virtual ~CMRS1000();

    void Create(char* connectIP, int port);

//	void SetObserver(CObserverLMS151* pObserver){m_pObserver = pObserver;}

    void StartStreaming();
    /*
            @brief 스캔 주기, 각 해상도 설정
            @fn	SENSOR::LMS151::CLMS151::SetConfig( unsigned int scanFreq, unsigned int angleRes )
            @param	unsigned int scanFreq 스캔 주기. 25Hz=2500, 50Hz=5000
            @param	unsigned int angleRes 각 해상도. 25Hz인 경우:0.25'=2500, 0.5'=5000   50Hz인 경우:0.5'=5000
            @return	bool

            @date	2015/04/08
            @author	YuHY( artisty123@naver.com )
        */
    bool SetConfig(unsigned int scanFreq, unsigned int angleRes);

//    bool QueryStatus(int &status, bool &bOperatingTemperature);

//    bool WaitForUpdateLMS151(unsigned long waitTime = ULONG_MAX) { return m_eUpdateLMS151.WaitForEvent(waitTime); }

    // 271 = 1      deg
    // 541 = 0.5    deg
    // 1081 = 0.25  deg
    // 2161 = 0.125 deg
//    virtual void OnScanData(float resolution, unsigned short* data, int length) { if( m_pObserverMRS1000Object ) m_pObserverMRS1000Object->OnMRS1000Pack(resolution, data, length); }
//    inline bool IsConnected(){ return m_bConnected; }

private:
    virtual void OnConnected(char* ip, int port);
    virtual void OnDisconnected(char* ip, int port);
    virtual void OnDataServer(char* ip, int port);

    int                 RecvUltil(void* dst, int length, char findChar, int sock);
    int 				StringToInt(char* strSrc, int radix);

    char*               m_connetIP;
    int                 m_port;

    char				m_bufRecv[g_maxLength + 1];
    unsigned int		m_recvLength;

    int					m_sensorStatus;
    bool				m_bOperatingTemperature;

    CObserverMRS1000*	m_pObserverMRS1000Object;	// 옵저버 객체
};

}
}
}

#endif /* CMRS1000OBJECT_H */
