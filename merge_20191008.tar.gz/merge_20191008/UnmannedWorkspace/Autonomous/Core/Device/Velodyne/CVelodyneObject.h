#ifndef CVELODYNEOBJECT_H
#define CVELODYNEOBJECT_H

#include "../../DevLib/Include/IO/CSocketReceiver/CSocketReceiver.h"
#include "../../DevLib/Include/IO/CSerial/CSerial.h"
#include "../../DevLib/Include/Core/CTimer/CTimer.h"

#include "CommonVelodyne.h"

namespace AUTONOMOUS
{
namespace Device
{
namespace Velodyne
{

typedef struct
{
    unsigned short	RPM;
    char*			lock;
} __attribute__((packed)) StVelodyneInfo;

typedef struct
{
    unsigned short  tempTop;
    unsigned short	tempBottom;
} __attribute__((packed)) StVelodyneTemp;

class CObserverVelodyneObject
{
public:
    virtual ~CObserverVelodyneObject() { }

    virtual void OnVelodynePack(AUTONOMOUS::Device::Velodyne::StVelodynePacket* pVelodynePack) = 0;
    virtual void OnVelodyneStatus(AUTONOMOUS::Device::Velodyne::StVelodyneStatus* pVelodyneStatus) = 0;
    virtual void OnEMount(AUTONOMOUS::Device::Velodyne::StEMount* pEMount) = 0;
};

class CVelodyneObject
        : public DevLib::IO::CSocketReceiver
//        , public DevLib::IO::CSerial
        , public DevLib::CTimer
{
public:
    CVelodyneObject(CObserverVelodyneObject* pObserver = 0);
    virtual ~CVelodyneObject();

    bool Create(char* bindIP, char* connectIP, int port);
    //bool CreateSerial(char* dev_name, speed_t baud_rate);

private:
    virtual void										OnReceive();				// 3D LIDAR 원시 정보 수신
    virtual void										OnTimer(void* p);			// 3D LIDAR 상태 정보 타이머

    AUTONOMOUS::Device::Velodyne::StVelodyneInfo          GetInfo();					// 3D LIDAR 상태 정보 수신
    AUTONOMOUS::Device::Velodyne::StVelodyneTemp          GetTemp();					// 3D LIDAR 온도 정보(변환 전) 수신
    //float 												ConvertTemp(char* temp);	// 3D LIDAR 온도 정보 변환

    DevLib::IO::CSocket                                 m_socketStatus;				// 3D LIDAR 상태 정보 연결 소켓
    char*												m_connectIP;				// 3D LIDAR 상태 정보 재연결 아이피

    CObserverVelodyneObject*							m_pObserverVelodyneObject;	// 옵저버 객체

    AUTONOMOUS::Device::Velodyne::StVelodyneInfo          m_vInfo;					// 3D LIDAR 상태 정보 수신 구조체
    AUTONOMOUS::Device::Velodyne::StVelodyneTemp          m_vTemp;					// 3D LIDAR 온도 정보 수신 구조체

    void OnThread();

    static void _OnThread(void* p){ ((CVelodyneObject*)p)->OnThread(); }

    DevLib::CThread                                     m_thread;
};

}
}
}

#endif /* CVELODYNEOBJECT_H */
