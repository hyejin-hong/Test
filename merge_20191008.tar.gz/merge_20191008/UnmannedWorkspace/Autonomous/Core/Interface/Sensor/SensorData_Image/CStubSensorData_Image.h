#ifndef CSTUBSENSORDATA_IMAGE_H
#define CSTUBSENSORDATA_IMAGE_H

#include <CFW.h>
#include <Core/DevLib/Include/IO/CLogWriter/CLogWriter.h>

// ICD Data
#include "../../../Data/Sensor/SensorData_Image.h"

namespace AUTONOMOUS
{
namespace Interface
{
namespace Sensor
{

class CStubSensorData_Image
{
public :
    CStubSensorData_Image();
    virtual ~CStubSensorData_Image();

    inline void WriteSensorData_Image(AUTONOMOUS::Data::Sensor::StSensorData_ImageComm& data)
    {
        data.message_type   = MSG_TYPE_SENSOR;
        data.message_ID     = MSG_CODE_SENSOR_SENSORDATA_IMAGE;
        data.QoS            = MSG_QOS_SENSOR_SENSORDATA_IMAGE;
        data.SN             = m_snStubSensorData_Image++;

        AUTONOMOUS::COMMLIB::CFW::GetInstance().Send(data);

        if( m_logStubSensorData_Image.IsRun() )
        {
            m_vBuffStubSensorData_Image.clear();
            data.getFrameData(m_vBuffStubSensorData_Image);
            m_logStubSensorData_Image.WriteData(m_vBuffStubSensorData_Image.data(), m_vBuffStubSensorData_Image.size());
        }
    }

    // Log
    bool CreateLogStubSensorData_Image(char* logName);
    void CloseLogStubSensorData_Image();

private:
    std::vector<uint8_t>   m_vBuffStubSensorData_Image;
    uint8_t                m_snStubSensorData_Image;
protected:
    DevLib::IO::CLogWriter m_logStubSensorData_Image;
};


}
}
}

#endif /* CSTUBSENSORDATA_IMAGE_H */
