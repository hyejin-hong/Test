#ifndef AUTO_COLLISIONALARM_H
#define AUTO_COLLISIONALARM_H

#include <CFW.h>
#include "../Common/Common.h"

namespace AUTONOMOUS
{
namespace Data
{
namespace Autonomy
{

typedef struct _StAuto_CollisionAlarm
{
    flt64_t     SyncTime;   // 동기화 시간
    int8_t      Distance;   // 가장 근접한 장애물까지의 거리 ( 분해능 0.1 m ) 9.5m -> 95

} StAuto_CollisionAlarm;

typedef struct _StAuto_CollisionAlarmComm : public AUTONOMOUS::COMMLIB::Header, public StAuto_CollisionAlarm
{
    virtual void setFrameData(uint8_t* buff)
    {
        buff = deserializeData(buff, SyncTime);
        buff = deserializeData(buff, Distance);
    }

    virtual void getFrameData(std::vector<uint8_t>& buff)
    {
        serializeData(buff, SyncTime);
        serializeData(buff, Distance);
    }

} StAuto_CollisionAlarmComm;

}
}
}

#endif // AUTO_COLLISIONALARM_H
