#include "CProxyAuto_DriveControlAutonomy.h"

namespace AUTONOMOUS
{
namespace Interface
{
namespace Autonomy
{

CProxyAuto_DriveControlAutonomy::CProxyAuto_DriveControlAutonomy()
{
    AUTONOMOUS::COMMLIB::CFW::GetInstance().RegisterSub(MSG_CODE_AUTONOMY_AUTO_DRIVECONTROLAUTONOMY, &CProxyAuto_DriveControlAutonomy::_OnAuto_DriveControlAutonomy, this);
}

CProxyAuto_DriveControlAutonomy::~CProxyAuto_DriveControlAutonomy()
{

}

bool CProxyAuto_DriveControlAutonomy::CreateLogProxyAuto_DriveControlAutonomy(char *logName)
{
    char fname[1024] = "";
    sprintf(fname, "./%s.Auto_DriveControlAutonomy", logName);

    return m_logProxyAuto_DriveControlAutonomy.Create(fname);
}

void CProxyAuto_DriveControlAutonomy::CloseLogProxyAuto_DriveControlAutonomy()
{
    m_logProxyAuto_DriveControlAutonomy.Destroy();
}

void CProxyAuto_DriveControlAutonomy::_OnAuto_DriveControlAutonomy(AUTONOMOUS::Data::Autonomy::StAuto_DriveControlComm& data)
{
    OnAuto_DriveControlAutonomy(data);
    if( m_logProxyAuto_DriveControlAutonomy.IsRun() )
    {
        m_vBuffProxyAuto_DriveControlAutonomy.clear();
        data.getFrameData(m_vBuffProxyAuto_DriveControlAutonomy);
        m_logProxyAuto_DriveControlAutonomy.WriteData(m_vBuffProxyAuto_DriveControlAutonomy.data(), m_vBuffProxyAuto_DriveControlAutonomy.size());
    }
}

}
}
}
