#include "CStubMapData_ProbabilityTraversability.h"

namespace AUTONOMOUS
{
namespace Interface
{
namespace Terrain
{

CStubMapData_ProbabilityTraversability::CStubMapData_ProbabilityTraversability()
{
    m_snStubMapData_ProbabilityTraversability = 0;
}

CStubMapData_ProbabilityTraversability::~CStubMapData_ProbabilityTraversability()
{ 

}

bool CStubMapData_ProbabilityTraversability::CreateLogStubMapData_ProbabilityTraversability(char *logName)
{
    char fname[1024] = "";
    sprintf(fname, "./%s.MapData_ProbabilityTraversability", logName);

    return m_logStubMapData_ProbabilityTraversability.Create(fname);
}

void CStubMapData_ProbabilityTraversability::CloseLogStubMapData_ProbabilityTraversability()
{
    m_logStubMapData_ProbabilityTraversability.Destroy();
}


}
}
}
