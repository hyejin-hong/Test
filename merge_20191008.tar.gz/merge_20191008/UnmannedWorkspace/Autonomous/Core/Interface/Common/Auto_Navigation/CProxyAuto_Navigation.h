#ifndef CPROXYEAUTO_NAVIGATION_H
#define CPROXYEAUTO_NAVIGATION_H

#include <Core/DevLib/Include/IO/CLogWriter/CLogWriter.h>

// ICD Data
#include "../../../Data/Common/Auto_Navigation.h"

namespace AUTONOMOUS
{
namespace Interface
{
namespace Common
{

class CProxyAuto_Navigation
{
public :
    CProxyAuto_Navigation();
    virtual ~CProxyAuto_Navigation();

    virtual void OnAuto_Navigation(AUTONOMOUS::Data::Common::StAuto_NavigationComm& data) = 0;

    // Log
    bool CreateLogProxyAuto_Navigation(char* logName);
    void CloseLogProxyAuto_Navigation();

private:
    std::vector<uint8_t>   m_vBuffProxyAuto_Navigation;
protected:
    DevLib::IO::CLogWriter m_logProxyAuto_Navigation;

    void _OnAuto_Navigation(AUTONOMOUS::Data::Common::StAuto_NavigationComm& data);
};


}
}
}

#endif /* CPROXYEAUTO_NAVIGATION_H */
