#include "CViewImage.h"

inline int Get4DivVal(int nVal)
{
    int UBit = (nVal&2) >> 1;
    int LBit = (nVal&1);
    int result = ((UBit^LBit)<<1) | LBit;

    return result; // ==>  ( nVal + result ) % 4 ==0;
}

CViewImage::CViewImage(QWidget *parent, const char *title)
    : QWidget (parent)
{
    connect(this, SIGNAL(ShowWindow()), this, SLOT(show()));
    connect(this, SIGNAL(Redraw()), this, SLOT(DrawImage()));
    if( parent == nullptr )
    {
        setToolTip(QString(title));
        setWindowTitle(QString(title));
    }
}

void CViewImage::ShowImage(QImage &img)
{
    m_img = img;

    // Signal
    Redraw();
}

void CViewImage::ShowImage(unsigned char *pImage, int width, int height, int nChannel)
{
    int nAdd = Get4DivVal(width);

    switch (nChannel) {
    case 1 :
        if( nAdd )
        {
            m_img = QImage(width+nAdd, height, QImage::Format_Grayscale8);
            m_img.fill(QColor(0,0,0));
            for( int y = 0; y < height; y++ )
            {
                memcpy(m_img.scanLine(y), &pImage[y*width*nChannel], width*nChannel);
            }
        }
        else m_img = QImage(pImage, width, height, QImage::Format_Grayscale8);
        break;
    case 3 :
        if( nAdd )
        {
            m_img = QImage(width+nAdd, height, QImage::Format_RGB888);
            m_img.fill(QColor(0,0,0));
            for( int y = 0; y < height; y++ )
            {
                memcpy(m_img.scanLine(y), &pImage[y*width*nChannel], width*nChannel);
            }
        }
        else m_img = QImage(pImage, width, height, QImage::Format_RGB888).rgbSwapped();
        break;
    default:
        break;
    }

    // Signal
    Redraw();
}

void CViewImage::DrawImage()
{
    resize(m_img.width(), m_img.height());

    if( isVisible() ) repaint();
    else show();
}

void CViewImage::paintEvent(QPaintEvent */*event*/)
{
    QPainter painter(this);
    painter.drawImage(0,0, m_img);
}
