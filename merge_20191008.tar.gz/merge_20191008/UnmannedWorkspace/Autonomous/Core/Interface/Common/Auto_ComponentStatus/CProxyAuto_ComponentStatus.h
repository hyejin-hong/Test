#ifndef CPROXYEAUTO_COMPONENTSTATUS_H
#define CPROXYEAUTO_COMPONENTSTATUS_H

#include <Core/DevLib/Include/IO/CLogWriter/CLogWriter.h>

// ICD Data
#include "../../../Data/Common/Auto_ComponentStatus.h"

namespace AUTONOMOUS
{
namespace Interface
{
namespace Common
{

class CProxyAuto_ComponentStatus
{
public :
    CProxyAuto_ComponentStatus();
    virtual ~CProxyAuto_ComponentStatus();

    virtual void OnAuto_ComponentStatus(AUTONOMOUS::Data::Common::StAuto_ComponentStatusComm& data) = 0;

    // Log
    bool CreateLogProxyAuto_ComponentStatus(char* logName);
    void CloseLogProxyAuto_ComponentStatus();

private:
    std::vector<uint8_t>   m_vBuffProxyAuto_ComponentStatus;
protected:
    DevLib::IO::CLogWriter m_logProxyAuto_ComponentStatus;

    void _OnAuto_ComponentStatus(AUTONOMOUS::Data::Common::StAuto_ComponentStatusComm& data);
};


}
}
}

#endif /* CPROXYEAUTO_COMPONENTSTATUS_H */
