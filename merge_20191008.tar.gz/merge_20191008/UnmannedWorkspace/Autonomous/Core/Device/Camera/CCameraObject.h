/*
 * CCameraObject.h
 *
 *  Created on: 2019. 4. 8.
 *      Author: fme
 */

#ifndef CCAMERAOBJECT_H
#define CCAMERAOBJECT_H

#include "../../DevLib/Include/Core/CTimer/CTimer.h"
#include "../../DevLib/Include/IO/CSocketReceiver/CSocketReceiver.h"
#include "../../Data/Common/Common.h"

#include <vector>

namespace AUTONOMOUS
{
namespace Device
{
namespace Camera
{

class CObserverCameraObject
{
public :
	virtual ~CObserverCameraObject() { }

    virtual void OnCameraPack(uint8_t* pCameraPack) = 0;
};

class CCameraObject
		: public DevLib::IO::CSocketReceiver
{
public:
	CCameraObject(CObserverCameraObject* pObserver = 0);
	virtual ~CCameraObject();

	bool Create(int port, char* ip);


private:

	virtual void OnReceive();

	CObserverCameraObject* m_pObserverCameraObject;

	// Image Buffer
//	std::vector<AUTONOMOUS::uint8_t>	m_bufferImage;
	uint8_t 						m_bufferImage[480*360*3];
	int 							client;
	bool							check;

};

}
}
}





#endif /*CCAMERAOBJECT_H */
