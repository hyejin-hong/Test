#ifndef CPROXYEMAPDATA_PROBABILITYTRAVERSABILITY_H
#define CPROXYEMAPDATA_PROBABILITYTRAVERSABILITY_H

#include <Core/DevLib/Include/IO/CLogWriter/CLogWriter.h>

// ICD Data
#include "../../../Data/Terrain/MapData_Probability.h"

namespace AUTONOMOUS
{
namespace Interface
{
namespace Terrain
{

class CProxyMapData_ProbabilityTraversability
{
public :
    CProxyMapData_ProbabilityTraversability();
    virtual ~CProxyMapData_ProbabilityTraversability();

    virtual void OnMapData_ProbabilityTraversability(AUTONOMOUS::Data::Terrain::StMapData_ProbabilityComm& data) = 0;

    // Log
    bool CreateLogProxyMapData_ProbabilityTraversability(char* logName);
    void CloseLogProxyMapData_ProbabilityTraversability();

private:
    std::vector<uint8_t>   m_vBuffProxyMapData_ProbabilityTraversability;
protected:
    DevLib::IO::CLogWriter m_logProxyMapData_ProbabilityTraversability;

    void _OnMapData_ProbabilityTraversability(AUTONOMOUS::Data::Terrain::StMapData_ProbabilityComm& data);
};


}
}
}

#endif /* CPROXYEMAPDATA_PROBABILITYTRAVERSABILITY_H */
