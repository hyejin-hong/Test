#include "CStubAuto_UGVEraseResponse.h"

namespace AUTONOMOUS
{
namespace Interface
{
namespace Common
{

CStubAuto_UGVEraseResponse::CStubAuto_UGVEraseResponse()
{
    m_snStubAuto_UGVEraseResponse = 0;
}

CStubAuto_UGVEraseResponse::~CStubAuto_UGVEraseResponse()
{ 

}

bool CStubAuto_UGVEraseResponse::CreateLogStubAuto_UGVEraseResponse(char *logName)
{
    char fname[1024] = "";
    sprintf(fname, "./%s.Auto_UGVEraseResponse", logName);

    return m_logStubAuto_UGVEraseResponse.Create(fname);
}

void CStubAuto_UGVEraseResponse::CloseLogStubAuto_UGVEraseResponse()
{
    m_logStubAuto_UGVEraseResponse.Destroy();
}


}
}
}
