#include "CProxySensorData_LIDAR_RthetaFrontLeft.h"

namespace AUTONOMOUS
{
namespace Interface
{
namespace Sensor
{

CProxySensorData_LIDAR_RthetaFrontLeft::CProxySensorData_LIDAR_RthetaFrontLeft()
{
    AUTONOMOUS::COMMLIB::CFW::GetInstance().RegisterSub(MSG_CODE_SENSOR_SENSORDATA_LIDAR_RTHETAFRONTLEFT, &CProxySensorData_LIDAR_RthetaFrontLeft::_OnSensorData_LIDAR_RthetaFrontLeft, this);
}

CProxySensorData_LIDAR_RthetaFrontLeft::~CProxySensorData_LIDAR_RthetaFrontLeft()
{

}

bool CProxySensorData_LIDAR_RthetaFrontLeft::CreateLogProxySensorData_LIDAR_RthetaFrontLeft(char *logName)
{
    char fname[1024] = "";
    sprintf(fname, "./%s.SensorData_LIDAR_RthetaFrontLeft", logName);

    return m_logProxySensorData_LIDAR_RthetaFrontLeft.Create(fname);
}

void CProxySensorData_LIDAR_RthetaFrontLeft::CloseLogProxySensorData_LIDAR_RthetaFrontLeft()
{
    m_logProxySensorData_LIDAR_RthetaFrontLeft.Destroy();
}

void CProxySensorData_LIDAR_RthetaFrontLeft::_OnSensorData_LIDAR_RthetaFrontLeft(AUTONOMOUS::Data::Sensor::StSensorData_LIDAR_RthetaComm& data)
{
    OnSensorData_LIDAR_RthetaFrontLeft(data);
    if( m_logProxySensorData_LIDAR_RthetaFrontLeft.IsRun() )
    {
        m_vBuffProxySensorData_LIDAR_RthetaFrontLeft.clear();
        data.getFrameData(m_vBuffProxySensorData_LIDAR_RthetaFrontLeft);
        m_logProxySensorData_LIDAR_RthetaFrontLeft.WriteData(m_vBuffProxySensorData_LIDAR_RthetaFrontLeft.data(), m_vBuffProxySensorData_LIDAR_RthetaFrontLeft.size());
    }
}

}
}
}
