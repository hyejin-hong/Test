#include "CStubAuto_Log_Control.h"

namespace AUTONOMOUS
{
namespace Interface
{
namespace Analysis
{

CStubAuto_Log_Control::CStubAuto_Log_Control()
{
    m_snStubAuto_Log_Control = 0;
}

CStubAuto_Log_Control::~CStubAuto_Log_Control()
{ 

}

bool CStubAuto_Log_Control::CreateLogStubAuto_Log_Control(char *logName)
{
    char fname[1024] = "";
    sprintf(fname, "./%s.Auto_Log_Control", logName);

    return m_logStubAuto_Log_Control.Create(fname);
}

void CStubAuto_Log_Control::CloseLogStubAuto_Log_Control()
{
    m_logStubAuto_Log_Control.Destroy();
}


}
}
}
