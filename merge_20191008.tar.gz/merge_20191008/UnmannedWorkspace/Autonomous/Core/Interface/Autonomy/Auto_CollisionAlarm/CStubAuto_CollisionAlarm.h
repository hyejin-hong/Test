#ifndef CSTUBAUTO_COLLISIONALARM_H
#define CSTUBAUTO_COLLISIONALARM_H

#include <CFW.h>
#include <Core/DevLib/Include/IO/CLogWriter/CLogWriter.h>

// ICD Data
#include "../../../Data/Autonomy/Auto_CollisionAlarm.h"

namespace AUTONOMOUS
{
namespace Interface
{
namespace Autonomy
{

class CStubAuto_CollisionAlarm
{
public :
    CStubAuto_CollisionAlarm();
    virtual ~CStubAuto_CollisionAlarm();

    inline void WriteAuto_CollisionAlarm(AUTONOMOUS::Data::Autonomy::StAuto_CollisionAlarmComm& data)
    {
        data.message_type   = MSG_TYPE_AUTONOMY;
        data.message_ID     = MSG_CODE_AUTONOMY_AUTO_COLLISIONALARM;
        data.QoS            = MSG_QOS_AUTONOMY_AUTO_COLLISIONALARM;
        data.SN             = m_snStubAuto_CollisionAlarm++;

        AUTONOMOUS::COMMLIB::CFW::GetInstance().Send(data);

        if( m_logStubAuto_CollisionAlarm.IsRun() )
        {
            m_vBuffStubAuto_CollisionAlarm.clear();
            data.getFrameData(m_vBuffStubAuto_CollisionAlarm);
            m_logStubAuto_CollisionAlarm.WriteData(m_vBuffStubAuto_CollisionAlarm.data(), m_vBuffStubAuto_CollisionAlarm.size());
        }
    }

    // Log
    bool CreateLogStubAuto_CollisionAlarm(char* logName);
    void CloseLogStubAuto_CollisionAlarm();

private:
    std::vector<uint8_t>   m_vBuffStubAuto_CollisionAlarm;
    uint8_t                m_snStubAuto_CollisionAlarm;
protected:
    DevLib::IO::CLogWriter m_logStubAuto_CollisionAlarm;
};


}
}
}

#endif /* CSTUBAUTO_COLLISIONALARM_H */
