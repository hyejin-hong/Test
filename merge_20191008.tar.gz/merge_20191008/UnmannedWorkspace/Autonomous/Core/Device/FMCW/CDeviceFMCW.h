/*
 * CDeviceFMCW.h
 *
 *  Created on: 2019. 4. 4.
 *      Author: fme
 */

#ifndef CDEVICEFMCW_H
#define CDEVICEFMCW_H

#include "CFMCWObject.h"

namespace UNMANNED
{
namespace Device
{
namespace FMCW
{

class CDeviceFMCW : public UNMANNED::Device::FMCW::CObserverFMCWObject
{
public:
	CDeviceFMCW()
	: m_devFMCW(this)
	{

	}

	virtual ~CDeviceFMCW()
	{

	}

    virtual void OnFMCWPackRecv(UNMANNED::Data::Sensor::StFMCWRadar* pFMCWPack) = 0;

	UNMANNED::Device::FMCW::CFMCWObject* GetDeviceFMCW() { return &m_devFMCW; }


private :
	UNMANNED::Device::FMCW::CFMCWObject 	m_devFMCW;

    virtual void OnFMCWPack(UNMANNED::Data::Sensor::StFMCWRadar* pFMCWPack)
	{
		OnFMCWPackRecv(pFMCWPack);
	}

};

}
}
}



#endif /* CDEVICEFMCW_H */
