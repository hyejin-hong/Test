/*
 * CThread.h
 *
 *  Created on: 2019. 3. 12.
 *      Author: fm
 */

#ifndef CTHREAD_H
#define CTHREAD_H

namespace DevLib
{

typedef void (*THREAD_CALLBACK)(void* p);

class CThread
{
public:
	CThread();
	virtual ~CThread();

	bool ServiceStart(THREAD_CALLBACK pCallback = 0, void* pParam = 0);
	void ServiceStop();

	bool IsRun();
	void WaitForEndThread();

	virtual void Run();

private:
	bool					m_bRun;
	unsigned long int		m_Thread;

	struct
    {
        THREAD_CALLBACK pCallBack;
        void* pParam;
    } m_param;
};
}
#endif /* CTHREAD_H */
