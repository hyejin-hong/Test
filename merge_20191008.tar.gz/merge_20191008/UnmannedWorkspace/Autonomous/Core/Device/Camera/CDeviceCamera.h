/*
 * CDeviceCamera.h
 *
 *  Created on: 2019. 4. 8.
 *      Author: fme
 */

#ifndef CDEVICECamera_H
#define CDEVICECamera_H

#include "CCameraObject.h"

namespace AUTONOMOUS
{
namespace Device
{
namespace Camera
{

class CDeviceCamera : public AUTONOMOUS::Device::Camera::CObserverCameraObject
{
public:
	CDeviceCamera()
	: m_devCamera(this)
	{

	}

	virtual ~CDeviceCamera()
	{

	}

	virtual void OnCameraPackRecv(uint8_t* pCameraPack) = 0;

	AUTONOMOUS::Device::Camera::CCameraObject* GetDeviceCamera() { return &m_devCamera; }


private :
	AUTONOMOUS::Device::Camera::CCameraObject 	m_devCamera;

	virtual void OnCameraPack(uint8_t* pCameraPack)
	{
		OnCameraPackRecv(pCameraPack);
	}

};

}
}
}


#endif /* CDEVICECamera_H */

