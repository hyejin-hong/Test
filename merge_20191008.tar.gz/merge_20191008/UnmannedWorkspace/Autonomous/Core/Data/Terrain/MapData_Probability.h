#ifndef MAPDATA_PROBABILITY_H
#define MAPDATA_PROBABILITY_H

#include <CFW.h>
#include "../Common/Common.h"
#include "../Common/Auto_Navigation.h"

namespace AUTONOMOUS
{
namespace Data
{
namespace Terrain
{

typedef struct _StMapData_Probability
{
    flt64_t                                         SyncTime;                   // 동기화 시간
    AUTONOMOUS::Data::Common::StNavigationDetail    Navigation;                 // 항법

    // 맵 크기
    struct
    {
        uint16_t row;
        uint16_t col;
    } MapSize;

    // 확률지도의 UTM 정보
    struct
    {
        flt64_t North;
        flt64_t East;
        flt64_t Elevation;
    } Ref_Map_Position;

    // 확률지도상 차량 위치
    struct
    {
        uint16_t row;
        uint16_t col;
    } Robot_Index;

    uint8_t                                         MapProbability[400*400];    // 확률지도 확률 값(0-255)

} StMapData_Probability;

typedef struct _StMapData_ProbabilityComm : public AUTONOMOUS::COMMLIB::Header, public StMapData_Probability
{
    virtual void setFrameData(uint8_t* buff)
    {
        buff = deserializeData(buff, SyncTime);

        buff = deserializeData(buff, Navigation.TimeStamp);
                std::for_each(Navigation.Zone, Navigation.Zone + 2, [&](int8_t& d)
        {
            buff = deserializeData(buff, d);
        });
        buff = deserializeData(buff, Navigation.East);
        buff = deserializeData(buff, Navigation.North);
        buff = deserializeData(buff, Navigation.Elevation);
        buff = deserializeData(buff, Navigation.Roll);
        buff = deserializeData(buff, Navigation.Pitch);
        buff = deserializeData(buff, Navigation.Heading);
        buff = deserializeData(buff, Navigation.VelocityLinearX);
        buff = deserializeData(buff, Navigation.VelocityLinearY);
        buff = deserializeData(buff, Navigation.VelocityLinearZ);
        buff = deserializeData(buff, Navigation.VelocityAngluarX);
        buff = deserializeData(buff, Navigation.VelocityAngluarY);
        buff = deserializeData(buff, Navigation.VelocityAngluarZ);

        buff = deserializeData(buff, MapSize.row);
        buff = deserializeData(buff, MapSize.col);
        buff = deserializeData(buff, Ref_Map_Position.North);
        buff = deserializeData(buff, Ref_Map_Position.East);
        buff = deserializeData(buff, Ref_Map_Position.Elevation);
        buff = deserializeData(buff, Robot_Index.row);
        buff = deserializeData(buff, Robot_Index.col);

        std::for_each(MapProbability, MapProbability + MapSize.col * MapSize.row, [&](uint8_t& d)
        {
            buff = deserializeData(buff, d);
        });
    }

    virtual void getFrameData(std::vector<uint8_t>& buff)
    {
        serializeData(buff, SyncTime);

        serializeData(buff, Navigation.TimeStamp);
        std::for_each(Navigation.Zone, Navigation.Zone + 2, [&](int8_t d)
        {
            serializeData(buff, d);
        });
        serializeData(buff, Navigation.East);
        serializeData(buff, Navigation.North);
        serializeData(buff, Navigation.Elevation);
        serializeData(buff, Navigation.Roll);
        serializeData(buff, Navigation.Pitch);
        serializeData(buff, Navigation.Heading);
        serializeData(buff, Navigation.VelocityLinearX);
        serializeData(buff, Navigation.VelocityLinearY);
        serializeData(buff, Navigation.VelocityLinearZ);
        serializeData(buff, Navigation.VelocityAngluarX);
        serializeData(buff, Navigation.VelocityAngluarY);
        serializeData(buff, Navigation.VelocityAngluarZ);

        serializeData(buff, MapSize.row);
        serializeData(buff, MapSize.col);
        serializeData(buff, Ref_Map_Position.North);
        serializeData(buff, Ref_Map_Position.East);
        serializeData(buff, Ref_Map_Position.Elevation);
        serializeData(buff, Robot_Index.row);
        serializeData(buff, Robot_Index.col);

        std::for_each(MapProbability, MapProbability + MapSize.col * MapSize.row, [&](uint8_t d)
        {
            serializeData(buff, d);
        });
    }

} StMapData_ProbabilityComm;

}
}
}

#endif // MAPDATA_PROBABILITY_H
