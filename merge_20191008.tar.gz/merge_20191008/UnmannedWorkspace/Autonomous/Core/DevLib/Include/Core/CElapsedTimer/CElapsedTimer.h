#ifndef CELAPSEDTIMER_H
#define CELAPSEDTIMER_H

#include <time.h>

namespace DevLib
{

class CElapsedTimer
{
public:
    CElapsedTimer();

    void Reset();

    unsigned int GetElapsedTime();
    unsigned int GetElapsedTimeContinue();

    void PrintElapsedTime(char* str = "ElapsedTime");
    void PrintElapsedTimeContinue(char* str = "ElapsedTime");

private:
    timespec m_time;
};

}

#endif // CELAPSEDTIMER_H
