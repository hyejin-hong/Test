#include "CStubMapData_PerceptionResult.h"

namespace AUTONOMOUS
{
namespace Interface
{
namespace Terrain
{

CStubMapData_PerceptionResult::CStubMapData_PerceptionResult()
{
    m_snStubMapData_PerceptionResult = 0;
}

CStubMapData_PerceptionResult::~CStubMapData_PerceptionResult()
{ 

}

bool CStubMapData_PerceptionResult::CreateLogStubMapData_PerceptionResult(char *logName)
{
    char fname[1024] = "";
    sprintf(fname, "./%s.MapData_PerceptionResult", logName);

    return m_logStubMapData_PerceptionResult.Create(fname);
}

void CStubMapData_PerceptionResult::CloseLogStubMapData_PerceptionResult()
{
    m_logStubMapData_PerceptionResult.Destroy();
}


}
}
}
