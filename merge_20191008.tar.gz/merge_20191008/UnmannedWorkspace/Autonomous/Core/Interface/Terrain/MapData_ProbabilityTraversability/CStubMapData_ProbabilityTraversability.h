#ifndef CSTUBMAPDATA_PROBABILITYTRAVERSABILITY_H
#define CSTUBMAPDATA_PROBABILITYTRAVERSABILITY_H

#include <CFW.h>
#include <Core/DevLib/Include/IO/CLogWriter/CLogWriter.h>

// ICD Data
#include "../../../Data/Terrain/MapData_Probability.h"

namespace AUTONOMOUS
{
namespace Interface
{
namespace Terrain
{

class CStubMapData_ProbabilityTraversability
{
public :
    CStubMapData_ProbabilityTraversability();
    virtual ~CStubMapData_ProbabilityTraversability();

    inline void WriteMapData_ProbabilityTraversability(AUTONOMOUS::Data::Terrain::StMapData_ProbabilityComm& data)
    {
        data.message_type   = MSG_TYPE_TERRAIN;
        data.message_ID     = MSG_CODE_TERRAIN_MAPDATA_PROBABILITYTRAVERSABILITY;
        data.QoS            = MSG_QOS_TERRAIN_MAPDATA_PROBABILITYTRAVERSABILITY;
        data.SN             = m_snStubMapData_ProbabilityTraversability++;

        AUTONOMOUS::COMMLIB::CFW::GetInstance().Send(data);

        if( m_logStubMapData_ProbabilityTraversability.IsRun() )
        {
            m_vBuffStubMapData_ProbabilityTraversability.clear();
            data.getFrameData(m_vBuffStubMapData_ProbabilityTraversability);
            m_logStubMapData_ProbabilityTraversability.WriteData(m_vBuffStubMapData_ProbabilityTraversability.data(), m_vBuffStubMapData_ProbabilityTraversability.size());
        }
    }

    // Log
    bool CreateLogStubMapData_ProbabilityTraversability(char* logName);
    void CloseLogStubMapData_ProbabilityTraversability();

private:
    std::vector<uint8_t>   m_vBuffStubMapData_ProbabilityTraversability;
    uint8_t                m_snStubMapData_ProbabilityTraversability;
protected:
    DevLib::IO::CLogWriter m_logStubMapData_ProbabilityTraversability;
};


}
}
}

#endif /* CSTUBMAPDATA_PROBABILITYTRAVERSABILITY_H */
