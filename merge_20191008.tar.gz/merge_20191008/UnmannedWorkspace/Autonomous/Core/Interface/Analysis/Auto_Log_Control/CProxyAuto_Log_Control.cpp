#include "CProxyAuto_Log_Control.h"

namespace AUTONOMOUS
{
namespace Interface
{
namespace Analysis
{

CProxyAuto_Log_Control::CProxyAuto_Log_Control()
{
    AUTONOMOUS::COMMLIB::CFW::GetInstance().RegisterSub(MSG_CODE_ANALYSIS_AUTO_LOG_CONTROL, &CProxyAuto_Log_Control::_OnAuto_Log_Control, this);
}

CProxyAuto_Log_Control::~CProxyAuto_Log_Control()
{

}

bool CProxyAuto_Log_Control::CreateLogProxyAuto_Log_Control(char *logName)
{
    char fname[1024] = "";
    sprintf(fname, "./%s.Auto_Log_Control", logName);

    return m_logProxyAuto_Log_Control.Create(fname);
}

void CProxyAuto_Log_Control::CloseLogProxyAuto_Log_Control()
{
    m_logProxyAuto_Log_Control.Destroy();
}

void CProxyAuto_Log_Control::_OnAuto_Log_Control(AUTONOMOUS::Data::Analysis::StAuto_Log_ControlComm& data)
{
    OnAuto_Log_Control(data);
    if( m_logProxyAuto_Log_Control.IsRun() )
    {
        m_vBuffProxyAuto_Log_Control.clear();
        data.getFrameData(m_vBuffProxyAuto_Log_Control);
        m_logProxyAuto_Log_Control.WriteData(m_vBuffProxyAuto_Log_Control.data(), m_vBuffProxyAuto_Log_Control.size());
    }
}

}
}
}
