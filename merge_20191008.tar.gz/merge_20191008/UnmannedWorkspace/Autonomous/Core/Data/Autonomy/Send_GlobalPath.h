#ifndef SEND_GLOBALPATH_H
#define SEND_GLOBALPATH_H

#include <CFW.h>
#include "../Common/Common.h"

namespace AUTONOMOUS
{
namespace Data
{
namespace Autonomy
{

typedef struct _StSend_GlobalPath
{
    flt64_t     SyncTime;           // 동기화 시간

    // 운용자 전역경로 Type
    // 1 : GlobalPath
    // 2 : IntersectionPath
    // 3 : RoadLinePath
    // 4 : FlowwingPath
    uint8_t     GlobalPathType;

    StGPP       GPPData;            // LPP가 추종할 GPP

} StSend_GlobalPath;

typedef struct _StSend_GlobalPathComm : public AUTONOMOUS::COMMLIB::Header, public StSend_GlobalPath
{
    virtual void setFrameData(uint8_t* buff)
    {
        buff = deserializeData(buff, SyncTime);
        buff = deserializeData(buff, GlobalPathType);

        buff = deserializeData(buff, GPPData.Zone[0]);
        buff = deserializeData(buff, GPPData.Zone[1]);
        buff = deserializeData(buff, GPPData.North);
        buff = deserializeData(buff, GPPData.East);
        buff = deserializeData(buff, GPPData.CommandVelocity);
    }

    virtual void getFrameData(std::vector<uint8_t>& buff)
    {
        serializeData(buff, SyncTime);
        serializeData(buff, GlobalPathType);

        serializeData(buff, GPPData.Zone[0]);
        serializeData(buff, GPPData.Zone[1]);
        serializeData(buff, GPPData.North);
        serializeData(buff, GPPData.East);
        serializeData(buff, GPPData.CommandVelocity);
    }
} StSend_GlobalPathComm;

}
}
}

#endif // SEND_GLOBALPATH_H
