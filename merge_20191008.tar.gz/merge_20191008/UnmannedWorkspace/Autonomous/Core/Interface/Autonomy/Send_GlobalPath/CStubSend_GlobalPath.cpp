#include "CStubSend_GlobalPath.h"

namespace AUTONOMOUS
{
namespace Interface
{
namespace Autonomy
{

CStubSend_GlobalPath::CStubSend_GlobalPath()
{
    m_snStubSend_GlobalPath = 0;
}

CStubSend_GlobalPath::~CStubSend_GlobalPath()
{ 

}

bool CStubSend_GlobalPath::CreateLogStubSend_GlobalPath(char *logName)
{
    char fname[1024] = "";
    sprintf(fname, "./%s.Send_GlobalPath", logName);

    return m_logStubSend_GlobalPath.Create(fname);
}

void CStubSend_GlobalPath::CloseLogStubSend_GlobalPath()
{
    m_logStubSend_GlobalPath.Destroy();
}


}
}
}
