#include "CProxyMapData_ProbabilityTraversability.h"

namespace AUTONOMOUS
{
namespace Interface
{
namespace Terrain
{

CProxyMapData_ProbabilityTraversability::CProxyMapData_ProbabilityTraversability()
{
    AUTONOMOUS::COMMLIB::CFW::GetInstance().RegisterSub(MSG_CODE_TERRAIN_MAPDATA_PROBABILITYTRAVERSABILITY, &CProxyMapData_ProbabilityTraversability::_OnMapData_ProbabilityTraversability, this);
}

CProxyMapData_ProbabilityTraversability::~CProxyMapData_ProbabilityTraversability()
{

}

bool CProxyMapData_ProbabilityTraversability::CreateLogProxyMapData_ProbabilityTraversability(char *logName)
{
    char fname[1024] = "";
    sprintf(fname, "./%s.MapData_ProbabilityTraversability", logName);

    return m_logProxyMapData_ProbabilityTraversability.Create(fname);
}

void CProxyMapData_ProbabilityTraversability::CloseLogProxyMapData_ProbabilityTraversability()
{
    m_logProxyMapData_ProbabilityTraversability.Destroy();
}

void CProxyMapData_ProbabilityTraversability::_OnMapData_ProbabilityTraversability(AUTONOMOUS::Data::Terrain::StMapData_ProbabilityComm& data)
{
    OnMapData_ProbabilityTraversability(data);
    if( m_logProxyMapData_ProbabilityTraversability.IsRun() )
    {
        m_vBuffProxyMapData_ProbabilityTraversability.clear();
        data.getFrameData(m_vBuffProxyMapData_ProbabilityTraversability);
        m_logProxyMapData_ProbabilityTraversability.WriteData(m_vBuffProxyMapData_ProbabilityTraversability.data(), m_vBuffProxyMapData_ProbabilityTraversability.size());
    }
}

}
}
}
