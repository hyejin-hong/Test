#include "CStubSensorData_LIDAR_RthetaFrontRight.h"

namespace AUTONOMOUS
{
namespace Interface
{
namespace Sensor
{

CStubSensorData_LIDAR_RthetaFrontRight::CStubSensorData_LIDAR_RthetaFrontRight()
{
    m_snStubSensorData_LIDAR_RthetaFrontRight = 0;
}

CStubSensorData_LIDAR_RthetaFrontRight::~CStubSensorData_LIDAR_RthetaFrontRight()
{ 

}

bool CStubSensorData_LIDAR_RthetaFrontRight::CreateLogStubSensorData_LIDAR_RthetaFrontRight(char *logName)
{
    char fname[1024] = "";
    sprintf(fname, "./%s.SensorData_LIDAR_RthetaFrontRight", logName);

    return m_logStubSensorData_LIDAR_RthetaFrontRight.Create(fname);
}

void CStubSensorData_LIDAR_RthetaFrontRight::CloseLogStubSensorData_LIDAR_RthetaFrontRight()
{
    m_logStubSensorData_LIDAR_RthetaFrontRight.Destroy();
}


}
}
}
