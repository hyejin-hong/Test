#ifndef CSTUBAUTO_CONTROLREQUEST_H
#define CSTUBAUTO_CONTROLREQUEST_H

#include <CFW.h>
#include <Core/DevLib/Include/IO/CLogWriter/CLogWriter.h>

// ICD Data
#include "../../../Data/Autonomy/Auto_ControlRequest.h"

namespace AUTONOMOUS
{
namespace Interface
{
namespace Autonomy
{

class CStubAuto_ControlRequest
{
public :
    CStubAuto_ControlRequest();
    virtual ~CStubAuto_ControlRequest();

    inline void WriteAuto_ControlRequest(AUTONOMOUS::Data::Autonomy::StAuto_ControlRequestComm& data)
    {
        data.message_type   = MSG_TYPE_AUTONOMY;
        data.message_ID     = MSG_CODE_AUTONOMY_AUTO_CONTROLREQUEST;
        data.QoS            = MSG_QOS_AUTONOMY_AUTO_CONTROLREQUEST;
        data.SN             = m_snStubAuto_ControlRequest++;

        AUTONOMOUS::COMMLIB::CFW::GetInstance().Send(data);

        if( m_logStubAuto_ControlRequest.IsRun() )
        {
            m_vBuffStubAuto_ControlRequest.clear();
            data.getFrameData(m_vBuffStubAuto_ControlRequest);
            m_logStubAuto_ControlRequest.WriteData(m_vBuffStubAuto_ControlRequest.data(), m_vBuffStubAuto_ControlRequest.size());
        }
    }

    // Log
    bool CreateLogStubAuto_ControlRequest(char* logName);
    void CloseLogStubAuto_ControlRequest();

private:
    std::vector<uint8_t>   m_vBuffStubAuto_ControlRequest;
    uint8_t                m_snStubAuto_ControlRequest;
protected:
    DevLib::IO::CLogWriter m_logStubAuto_ControlRequest;
};


}
}
}

#endif /* CSTUBAUTO_CONTROLREQUEST_H */
