#ifndef CFILE_H
#define CFILE_H

#include <stdio.h>

namespace DevLib
{
namespace IO
{

class CFile
{
public:
	CFile();
	virtual ~CFile();

	bool Create(const char* fname,const char* mode);	//file creat
	void Destroy();							//file close

	bool IsCreated();

	int Write(void* pData, int size);		//file write
	int Read(void* pData, int size);		//file read

	int GetSize();							//file size

    int SeekBegin();						//file located set
	int SeekEnd();							//file located end
    int SeekCur();
	int SeekPos(int nPos);					//file located cur

private:
	FILE* 		m_fp;
};

}
}

#endif
