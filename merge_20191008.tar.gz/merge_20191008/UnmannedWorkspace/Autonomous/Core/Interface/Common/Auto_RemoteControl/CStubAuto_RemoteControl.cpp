#include "CStubAuto_RemoteControl.h"

namespace AUTONOMOUS
{
namespace Interface
{
namespace Common
{

CStubAuto_RemoteControl::CStubAuto_RemoteControl()
{
    m_snStubAuto_RemoteControl = 0;
}

CStubAuto_RemoteControl::~CStubAuto_RemoteControl()
{ 

}

bool CStubAuto_RemoteControl::CreateLogStubAuto_RemoteControl(char *logName)
{
    char fname[1024] = "";
    sprintf(fname, "./%s.Auto_RemoteControl", logName);

    return m_logStubAuto_RemoteControl.Create(fname);
}

void CStubAuto_RemoteControl::CloseLogStubAuto_RemoteControl()
{
    m_logStubAuto_RemoteControl.Destroy();
}


}
}
}
