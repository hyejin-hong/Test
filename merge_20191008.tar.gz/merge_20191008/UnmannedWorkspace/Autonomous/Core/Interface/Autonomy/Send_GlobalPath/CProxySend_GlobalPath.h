#ifndef CPROXYESEND_GLOBALPATH_H
#define CPROXYESEND_GLOBALPATH_H

#include <Core/DevLib/Include/IO/CLogWriter/CLogWriter.h>

// ICD Data
#include "../../../Data/Autonomy/Send_GlobalPath.h"

namespace AUTONOMOUS
{
namespace Interface
{
namespace Autonomy
{

class CProxySend_GlobalPath
{
public :
    CProxySend_GlobalPath();
    virtual ~CProxySend_GlobalPath();

    virtual void OnSend_GlobalPath(AUTONOMOUS::Data::Autonomy::StSend_GlobalPathComm& data) = 0;

    // Log
    bool CreateLogProxySend_GlobalPath(char* logName);
    void CloseLogProxySend_GlobalPath();

private:
    std::vector<uint8_t>   m_vBuffProxySend_GlobalPath;
protected:
    DevLib::IO::CLogWriter m_logProxySend_GlobalPath;

    void _OnSend_GlobalPath(AUTONOMOUS::Data::Autonomy::StSend_GlobalPathComm& data);
};


}
}
}

#endif /* CPROXYESEND_GLOBALPATH_H */
