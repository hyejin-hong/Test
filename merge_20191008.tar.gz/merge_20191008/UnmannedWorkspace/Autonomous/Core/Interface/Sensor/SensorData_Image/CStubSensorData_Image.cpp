#include "CStubSensorData_Image.h"

namespace AUTONOMOUS
{
namespace Interface
{
namespace Sensor
{

CStubSensorData_Image::CStubSensorData_Image()
{
    m_snStubSensorData_Image = 0;
}

CStubSensorData_Image::~CStubSensorData_Image()
{ 

}

bool CStubSensorData_Image::CreateLogStubSensorData_Image(char *logName)
{
    char fname[1024] = "";
    sprintf(fname, "./%s.SensorData_Image", logName);

    return m_logStubSensorData_Image.Create(fname);
}

void CStubSensorData_Image::CloseLogStubSensorData_Image()
{
    m_logStubSensorData_Image.Destroy();
}


}
}
}
