#include "CStubMapData_ProbabilityFused.h"

namespace AUTONOMOUS
{
namespace Interface
{
namespace Terrain
{

CStubMapData_ProbabilityFused::CStubMapData_ProbabilityFused()
{
    m_snStubMapData_ProbabilityFused = 0;
}

CStubMapData_ProbabilityFused::~CStubMapData_ProbabilityFused()
{ 

}

bool CStubMapData_ProbabilityFused::CreateLogStubMapData_ProbabilityFused(char *logName)
{
    char fname[1024] = "";
    sprintf(fname, "./%s.MapData_ProbabilityFused", logName);

    return m_logStubMapData_ProbabilityFused.Create(fname);
}

void CStubMapData_ProbabilityFused::CloseLogStubMapData_ProbabilityFused()
{
    m_logStubMapData_ProbabilityFused.Destroy();
}


}
}
}
