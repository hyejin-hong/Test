#ifndef CSTUBAUTO_REMOTECONTROL_H
#define CSTUBAUTO_REMOTECONTROL_H

#include <CFW.h>
#include <Core/DevLib/Include/IO/CLogWriter/CLogWriter.h>

// ICD Data
#include "../../../Data/Common/Auto_RemoteControl.h"

namespace AUTONOMOUS
{
namespace Interface
{
namespace Common
{

class CStubAuto_RemoteControl
{
public :
    CStubAuto_RemoteControl();
    virtual ~CStubAuto_RemoteControl();

    inline void WriteAuto_RemoteControl(AUTONOMOUS::Data::Common::StAuto_RemoteControlComm& data)
    {
        data.message_type   = MSG_TYPE_COMMON;
        data.message_ID     = MSG_CODE_COMMON_AUTO_REMOTECONTROL;
        data.QoS            = MSG_QOS_COMMON_AUTO_REMOTECONTROL;
        data.SN             = m_snStubAuto_RemoteControl++;

        AUTONOMOUS::COMMLIB::CFW::GetInstance().Send(data);

        if( m_logStubAuto_RemoteControl.IsRun() )
        {
            m_vBuffStubAuto_RemoteControl.clear();
            data.getFrameData(m_vBuffStubAuto_RemoteControl);
            m_logStubAuto_RemoteControl.WriteData(m_vBuffStubAuto_RemoteControl.data(), m_vBuffStubAuto_RemoteControl.size());
        }
    }

    // Log
    bool CreateLogStubAuto_RemoteControl(char* logName);
    void CloseLogStubAuto_RemoteControl();

private:
    std::vector<uint8_t>   m_vBuffStubAuto_RemoteControl;
    uint8_t                m_snStubAuto_RemoteControl;
protected:
    DevLib::IO::CLogWriter m_logStubAuto_RemoteControl;
};


}
}
}

#endif /* CSTUBAUTO_REMOTECONTROL_H */
