#ifndef DATA_UNCOMPRESSIMAGE_H
#define DATA_UNCOMPRESSIMAGE_H

#include <CFW.h>
#include "../Common/Common.h"

namespace AUTONOMOUS
{
namespace Data
{
namespace Sensor
{

typedef struct _StData_UncompressImage
{
    flt64_t     SyncTime;   // 동기화 시간

} StData_UncompressImage;

typedef struct _StData_UncompressImageComm : public AUTONOMOUS::COMMLIB::Header, public StData_UncompressImage
{
    virtual void setFrameData(uint8_t* buff)
    {
        buff = deserializeData(buff, SyncTime);
    }

    virtual void getFrameData(std::vector<uint8_t>& buff)
    {
        serializeData(buff, SyncTime);
    }

} StData_UncompressImageComm;

}
}
}

#endif // DATA_UNCOMPRESSIMAGE_H
