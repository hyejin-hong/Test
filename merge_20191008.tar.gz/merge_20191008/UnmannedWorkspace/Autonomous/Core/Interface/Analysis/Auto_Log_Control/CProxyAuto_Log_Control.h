#ifndef CPROXYEAUTO_LOG_CONTROL_H
#define CPROXYEAUTO_LOG_CONTROL_H

#include <Core/DevLib/Include/IO/CLogWriter/CLogWriter.h>

// ICD Data
#include "../../../Data/Analysis/Auto_Log_Control.h"

namespace AUTONOMOUS
{
namespace Interface
{
namespace Analysis
{

class CProxyAuto_Log_Control
{
public :
    CProxyAuto_Log_Control();
    virtual ~CProxyAuto_Log_Control();

    virtual void OnAuto_Log_Control(AUTONOMOUS::Data::Analysis::StAuto_Log_ControlComm& data) = 0;

    // Log
    bool CreateLogProxyAuto_Log_Control(char* logName);
    void CloseLogProxyAuto_Log_Control();

private:
    std::vector<uint8_t>   m_vBuffProxyAuto_Log_Control;
protected:
    DevLib::IO::CLogWriter m_logProxyAuto_Log_Control;

    void _OnAuto_Log_Control(AUTONOMOUS::Data::Analysis::StAuto_Log_ControlComm& data);
};


}
}
}

#endif /* CPROXYEAUTO_LOG_CONTROL_H */
