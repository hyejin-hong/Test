#ifndef AUTO_UGVINTERFACESELECTION_H
#define AUTO_UGVINTERFACESELECTION_H

#include <CFW.h>
#include "../Common/Common.h"

namespace AUTONOMOUS
{
namespace Data
{
namespace Common
{


typedef struct _StInterfaceSelectionStatus
{
    flt64_t             SyncTime;               // 동기화 시간

    union
    {
        struct
        {
            // Status
            // 1 : Interface 1 ( 목표 속도, 목표 조향각 )
            // 2 : Interface 2 ( 경로계획 결과 )
            uint8_t Selection : 2;
            uint8_t Reserved;
        };
        uint8_t Value;
    }               SelectionInterface;

} StInterfaceSelectionStatus;

typedef struct _StAuto_UGVInterfaceSelectionComm : public AUTONOMOUS::COMMLIB::Header, public StInterfaceSelectionStatus
{
    virtual void setFrameData(uint8_t* buff)
    {
        buff = deserializeData(buff, SyncTime);
        buff = deserializeData(buff, SelectionInterface.Value);
    }

    virtual void getFrameData(std::vector<uint8_t>& buff)
    {
        serializeData(buff, SyncTime);
        serializeData(buff, SelectionInterface.Value);
    }

} StAuto_UGVInterfaceSelectionComm;

}
}
}

#endif // AUTO_UGVINTERFACESELECTION_H
