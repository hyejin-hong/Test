#include "CStubAuto_UGVInterfaceSelection.h"

namespace AUTONOMOUS
{
namespace Interface
{
namespace Common
{

CStubAuto_UGVInterfaceSelection::CStubAuto_UGVInterfaceSelection()
{
    m_snStubAuto_UGVInterfaceSelection = 0;
}

CStubAuto_UGVInterfaceSelection::~CStubAuto_UGVInterfaceSelection()
{ 

}

bool CStubAuto_UGVInterfaceSelection::CreateLogStubAuto_UGVInterfaceSelection(char *logName)
{
    char fname[1024] = "";
    sprintf(fname, "./%s.Auto_UGVInterfaceSelection", logName);

    return m_logStubAuto_UGVInterfaceSelection.Create(fname);
}

void CStubAuto_UGVInterfaceSelection::CloseLogStubAuto_UGVInterfaceSelection()
{
    m_logStubAuto_UGVInterfaceSelection.Destroy();
}


}
}
}
