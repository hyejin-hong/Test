#ifndef __COMMONVELODYNE_H_
#define __COMMONVELODYNE_H_

#include "../../Data/Common/Common.h"

#include <vector>
#include <queue>

namespace AUTONOMOUS
{
namespace Device
{
namespace Velodyne
{

/************************************************************************/
/* Const Definition                                            */
/************************************************************************/
const static int g_defaultPort		= 2368;
const static int g_sizeMaxLayer		= 64;
const static int g_laserPerFiring	= 32;
const static int g_firingPerPacket	= 12;
const static float g_velodyne16RPM  = 600.f;

enum
{
    LAYER_UPPER = 56831,
	LAYER_LOWER	= 61183
};

enum HDLBlock
{
    BLOCK_0_TO_31   = 0xeeff,
	BLOCK_32_TO_63	= 0xddff
};

const static float Velodyne32LayerToAngle[32] =
{
	( 0.0f ),
};

const static float Velodyne16LayerToAngle[16] =
{
		(-15.0f), ( 1.0f ), (-13.0f), (3.0f ),
		(-11.0f), ( 5.0f ), (-9.0f ), ( 7.0f ),
		(-7.0f ), ( 9.0f ), (-5.0f ), ( 11.0f),
		(-3.0f ), ( 13.0f), (-1.0f ), ( 15.0f)
};

/************************************************************************/
/* Protocol Definition                                                  */
/************************************************************************/

// XYZ Struct
typedef struct
{
	int Size() { return g_laserPerFiring * g_firingPerPacket; }
	struct
	{
        short x;
        short y;
        short z;
        unsigned char intensity;
        unsigned char layer;
	} __attribute__((packed)) xyz[g_laserPerFiring * g_firingPerPacket];
} __attribute__((packed)) StPackXYZ;

typedef struct
{
	int Width() { return g_firingPerPacket; }
	int Height() { return g_laserPerFiring; }
	float verticalAngle[g_laserPerFiring];

	struct
	{
        unsigned short range;
        unsigned short azimuth;
	} __attribute__((packed)) range[g_laserPerFiring * g_firingPerPacket];

    unsigned char intensity[g_laserPerFiring * g_firingPerPacket];
} __attribute__((packed)) StPackRangeTheta;


// Sensor Data Struct
typedef struct
{
	unsigned short	distance;
    unsigned char	intensity;
} __attribute__((packed)) StDataPoint;

typedef struct
{
	unsigned short	blockID;
	unsigned short	Azimuth;
	StDataPoint		layer[g_laserPerFiring];
} __attribute__((packed)) _DATA_BLOCK;

typedef struct
{
	_DATA_BLOCK	block[g_firingPerPacket];
	unsigned int	timeStamp;
    short           blank;
} __attribute__((packed)) StVelodynePacket;

// Sensor Status Struct
typedef struct
{
	unsigned short	RPM;
    char*			lock;
    unsigned short 	tempTop;
    unsigned short	tempBottom;
} __attribute__((packed)) StVelodyneStatus;

typedef std::vector<StVelodynePacket>  vStVelodynePacket;
typedef std::queue<StVelodynePacket>   qStVelodynePacket;


//////////////////////////////////////////////////////////////////////////
typedef struct
{
    // XML Parse Data
	float	rotate_correction;
	float	vertical_correction;
	int		dist_correction;
	int		dist_correction_x;
	int		dist_correction_y;
	float	vertical_offset_correction;
	float	horize_offset_correction;
	int		focal_distance;
	float	focal_slope;

    // Calculation Data
    double sin_vertical_angle;
	double cos_vertical_angle;
	double sin_rotation_correction;
	double cos_rotation_correction;
} __attribute__((packed)) StPackCorrect;

typedef struct _StCorrctionParams
{
    _StCorrctionParams(char* fname = 0) { if(fname) ReadCorrectionFile(fname); }
    bool ReadCorrectionFile(const char* fileName);
    StPackCorrect	correction[g_sizeMaxLayer];
    float			distLBS;
} __attribute__((packed)) StCorrectionParams;

/************************************************************************/
/* E-Mount Definition                                                  */
/************************************************************************/
//const char*  g_head = "FM";

//const char g_idBitStatus        = 0xA0;
//const char g_idVelodyneTemper   = 0xB0;
//const char g_idPowerControl     = 0xC0;
//const char g_idAckPowerControl  = 0xC1;
//const char g_idPhaseLock        = 0xD0;
//const char g_idAckPhaseLock     = 0xD1;
//const char g_idEMountStatus     = 0xE0;
//const char g_idAckEMountStatus  = 0xE1;

typedef struct
{

} __attribute__((packed)) StEMount;

}
}
}

#endif /* __COMMONVELODYNE_H_ */
