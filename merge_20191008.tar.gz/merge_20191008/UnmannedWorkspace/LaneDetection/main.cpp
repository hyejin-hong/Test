#include <iostream>

#include <unistd.h>
#include <clanedetector.h>

using namespace std;

int main()
{
    AUTONOMOUS::COMMLIB::CFW::GetInstance().Initialize();

    CLaneDetector lane;


    AUTONOMOUS::COMMLIB::CFW::GetInstance().StartCFW();

    while( true )
    {
        usleep(1000000);
    }

    return 0;
}
