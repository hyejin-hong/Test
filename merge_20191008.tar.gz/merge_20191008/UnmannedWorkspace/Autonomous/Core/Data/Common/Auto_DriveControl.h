#ifndef AUTO_DRIVECONTROL_H
#define AUTO_DRIVECONTROL_H

#include <CFW.h>
#include "../Common/Common.h"

namespace AUTONOMOUS
{
namespace Data
{
namespace Common
{

typedef struct _StInterfaceSelectionStatus
{
    union
    {
        struct
        {
            // Status
            // 1 : Interface 1 ( 목표 속도, 목표 조향각 )
            // 2 : Interface 2 ( 경로계획 결과 )
            uint8_t Selection : 2;
            uint8_t Reserved;
        };
        uint8_t Value;
    };

} StInterfaceSelectionStatus;

typedef struct _StAuto_DriveControl
{
    flt64_t                     SyncTime;       // 동기화 시간
    StInterfaceSelectionStatus  Interface;  // 인터페이스 상태 반영
    int8_t                      SteeringWheel;  // Wheel 조향 : -100 ~ 100 %
    int8_t                      Accelator;      // 가속 페달 : 0 ~ 100 %
    AUTONOMOUS::StGear          Gear;

    // 속도계획 결과 기준 속도 ( KPH )
    // Range : 0 ~ 50000
    // scale : 0.001
    uint16_t                    ReferenceSpeed;

    // X축 경로생성계수
    // Interface 1 : 사용
    // Interface 2 : 미사용
    // Scale : 0.01
    int16_t                    PathGenerationCofficient_X_1;
    int16_t                    PathGenerationCofficient_X_2;
    int16_t                    PathGenerationCofficient_X_3;
    int16_t                    PathGenerationCofficient_X_4;
    int16_t                    PathGenerationCofficient_X_5;

    // Y축 경로생성계수
    // Interface 1 : 미사용
    // Interface 2 : 사용
    // Scale : 0.01
    int16_t                    PathGenerationCofficient_Y_1;
    int16_t                    PathGenerationCofficient_Y_2;
    int16_t                    PathGenerationCofficient_Y_3;
    int16_t                    PathGenerationCofficient_Y_4;
    int16_t                    PathGenerationCofficient_Y_5;


} StAuto_DriveControl;

typedef struct _StAuto_DriveControlComm : public AUTONOMOUS::COMMLIB::Header, public StAuto_DriveControl
{
    virtual void setFrameData(uint8_t* buff)
    {
        buff = deserializeData(buff, SyncTime);
        buff = deserializeData(buff, Interface.Value);
        buff = deserializeData(buff, SteeringWheel);
        buff = deserializeData(buff, Accelator);
        buff = deserializeData(buff, Gear.Gear);
        buff = deserializeData(buff, ReferenceSpeed);
        buff = deserializeData(buff, PathGenerationCofficient_X_1);
        buff = deserializeData(buff, PathGenerationCofficient_X_2);
        buff = deserializeData(buff, PathGenerationCofficient_X_3);
        buff = deserializeData(buff, PathGenerationCofficient_X_4);
        buff = deserializeData(buff, PathGenerationCofficient_X_5);
        buff = deserializeData(buff, PathGenerationCofficient_Y_1);
        buff = deserializeData(buff, PathGenerationCofficient_Y_2);
        buff = deserializeData(buff, PathGenerationCofficient_Y_3);
        buff = deserializeData(buff, PathGenerationCofficient_Y_4);
        buff = deserializeData(buff, PathGenerationCofficient_Y_5);
    }

    virtual void getFrameData(std::vector<uint8_t>& buff)
    {
        serializeData(buff, SyncTime);
        serializeData(buff, Interface.Value);
        serializeData(buff, SteeringWheel);
        serializeData(buff, Accelator);
        serializeData(buff, Gear.Gear);
        serializeData(buff, ReferenceSpeed);
        serializeData(buff, PathGenerationCofficient_X_1);
        serializeData(buff, PathGenerationCofficient_X_2);
        serializeData(buff, PathGenerationCofficient_X_3);
        serializeData(buff, PathGenerationCofficient_X_4);
        serializeData(buff, PathGenerationCofficient_X_5);
        serializeData(buff, PathGenerationCofficient_Y_1);
        serializeData(buff, PathGenerationCofficient_Y_2);
        serializeData(buff, PathGenerationCofficient_Y_3);
        serializeData(buff, PathGenerationCofficient_Y_4);
        serializeData(buff, PathGenerationCofficient_Y_5);
    }

} StAuto_DriveControlComm;


}
}
}

#endif // AUTO_DRIVECONTROL_H
