#include "CProxyMapData_ProbabilityFused.h"

namespace AUTONOMOUS
{
namespace Interface
{
namespace Terrain
{

CProxyMapData_ProbabilityFused::CProxyMapData_ProbabilityFused()
{
    AUTONOMOUS::COMMLIB::CFW::GetInstance().RegisterSub(MSG_CODE_TERRAIN_MAPDATA_PROBABILITYFUSED, &CProxyMapData_ProbabilityFused::_OnMapData_ProbabilityFused, this);
}

CProxyMapData_ProbabilityFused::~CProxyMapData_ProbabilityFused()
{

}

bool CProxyMapData_ProbabilityFused::CreateLogProxyMapData_ProbabilityFused(char *logName)
{
    char fname[1024] = "";
    sprintf(fname, "./%s.MapData_ProbabilityFused", logName);

    return m_logProxyMapData_ProbabilityFused.Create(fname);
}

void CProxyMapData_ProbabilityFused::CloseLogProxyMapData_ProbabilityFused()
{
    m_logProxyMapData_ProbabilityFused.Destroy();
}

void CProxyMapData_ProbabilityFused::_OnMapData_ProbabilityFused(AUTONOMOUS::Data::Terrain::StMapData_ProbabilityComm& data)
{
    OnMapData_ProbabilityFused(data);
    if( m_logProxyMapData_ProbabilityFused.IsRun() )
    {
        m_vBuffProxyMapData_ProbabilityFused.clear();
        data.getFrameData(m_vBuffProxyMapData_ProbabilityFused);
        m_logProxyMapData_ProbabilityFused.WriteData(m_vBuffProxyMapData_ProbabilityFused.data(), m_vBuffProxyMapData_ProbabilityFused.size());
    }
}

}
}
}
