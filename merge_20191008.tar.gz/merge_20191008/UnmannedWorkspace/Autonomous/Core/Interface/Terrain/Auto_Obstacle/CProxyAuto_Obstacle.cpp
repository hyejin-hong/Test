#include "CProxyAuto_Obstacle.h"

namespace AUTONOMOUS
{
namespace Interface
{
namespace Terrain
{

CProxyAuto_Obstacle::CProxyAuto_Obstacle()
{
    AUTONOMOUS::COMMLIB::CFW::GetInstance().RegisterSub(MSG_CODE_TERRAIN_AUTO_OBSTACLE, &CProxyAuto_Obstacle::_OnAuto_Obstacle, this);
}

CProxyAuto_Obstacle::~CProxyAuto_Obstacle()
{

}

bool CProxyAuto_Obstacle::CreateLogProxyAuto_Obstacle(char *logName)
{
    char fname[1024] = "";
    sprintf(fname, "./%s.Auto_Obstacle", logName);

    return m_logProxyAuto_Obstacle.Create(fname);
}

void CProxyAuto_Obstacle::CloseLogProxyAuto_Obstacle()
{
    m_logProxyAuto_Obstacle.Destroy();
}

void CProxyAuto_Obstacle::_OnAuto_Obstacle(AUTONOMOUS::Data::Terrain::StAuto_ObstacleComm& data)
{
    OnAuto_Obstacle(data);
    if( m_logProxyAuto_Obstacle.IsRun() )
    {
        m_vBuffProxyAuto_Obstacle.clear();
        data.getFrameData(m_vBuffProxyAuto_Obstacle);
        m_logProxyAuto_Obstacle.WriteData(m_vBuffProxyAuto_Obstacle.data(), m_vBuffProxyAuto_Obstacle.size());
    }
}

}
}
}
