#ifndef AUTO_LOGCONTROL_H
#define AUTO_LOGCONTROL_H

#include <CFW.h>
#include "../Common/Common.h"
#include <iostream>

namespace AUTONOMOUS
{
namespace Data
{
namespace Analysis
{

const char c_cmd_stop   = 0;    // 로깅 종료
const char c_cmd_start  = 1;    // 로깅 시작

typedef struct _StAuto_Log_Control
{
    flt64_t SyncTime;           // 동기화 시간
    struct
    {
        uint8_t   AutoManager : 1;
        uint8_t   NavigationRepeator : 1;
        uint8_t   LocalPathPlan : 1;
        uint8_t   PathTracker : 1;
        uint8_t   AntiCollision : 1;
        uint8_t   Reserved : 3;
    } LoggingComponentA;        // 로깅 대상 컴포넌트 (공통/판단)
    struct
    {
        uint8_t   Interface3DLidar : 1;
        uint8_t   Interface2DLidar : 1;
        uint8_t   InterfaceFMCW : 1;
        uint8_t   InterfaceCCD : 1;
        uint8_t   Reserved : 4;
    } LoggingComponentB;        // 로깅 대상 컴포넌트 (센서처리)
    struct
    {
        uint8_t   TraversabilityMapA : 1;
        uint8_t   TraversabilityMapB : 1;
        uint8_t   TraversabilityMapFused : 1;
        uint8_t   ObjectDetector : 1;
        uint8_t   PerceptionResult : 1;
        uint8_t   LaneDetector : 1;
        uint8_t   Reserved : 2;
    } LoggingComponentC;        // 로깅 대상 컴포넌트 (인식)
    int8_t  LoggingTime[128];   // 개별 로깅파일의 기준이름
    int8_t  LoggingCommand;     // 로깅제어 명령 (시작/종료)

} StAuto_Log_Control;

typedef struct _StAuto_Log_ControlComm : public AUTONOMOUS::COMMLIB::Header, public StAuto_Log_Control
{
    // 데이터 사이즈
    inline uint32_t GetSize(){ return (sizeof(AUTONOMOUS::COMMLIB::Header) + sizeof(_StAuto_Log_Control)); }

    virtual void setFrameData(uint8_t* buff)
    {
        buff = deserializeData(buff, SyncTime);
        buff = deserializeData(buff, LoggingComponentA);
        buff = deserializeData(buff, LoggingComponentB);
        buff = deserializeData(buff, LoggingComponentC);
        std::for_each(LoggingTime, LoggingTime + 128, [&](int8_t& d)
        {
            buff = deserializeData(buff, d);
        });
        buff = deserializeData(buff, LoggingCommand);
    }

    virtual void getFrameData(std::vector<uint8_t>& buff)
    {
        serializeData(buff, SyncTime);
        serializeData(buff, LoggingComponentA);
        serializeData(buff, LoggingComponentB);
        serializeData(buff, LoggingComponentC);
        std::for_each(LoggingTime, LoggingTime + 128, [&](int8_t d)
        {
            serializeData(buff, d);
        });
        serializeData(buff, LoggingCommand);
    }

} StAuto_Log_ControlComm;

}
}
}


#endif // AUTO_LOGCONTROL_H
