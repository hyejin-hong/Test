#ifndef CSTUBSENSORDATA_LIDAR_RTHETAFRONTLEFT_H
#define CSTUBSENSORDATA_LIDAR_RTHETAFRONTLEFT_H

#include <CFW.h>
#include <Core/DevLib/Include/IO/CLogWriter/CLogWriter.h>

// ICD Data
#include "../../../Data/Sensor/SensorData_LIDAR_Rtheta.h"

namespace AUTONOMOUS
{
namespace Interface
{
namespace Sensor
{

class CStubSensorData_LIDAR_RthetaFrontLeft
{
public :
    CStubSensorData_LIDAR_RthetaFrontLeft();
    virtual ~CStubSensorData_LIDAR_RthetaFrontLeft();

    inline void WriteSensorData_LIDAR_RthetaFrontLeft(AUTONOMOUS::Data::Sensor::StSensorData_LIDAR_RthetaComm& data)
    {
        data.message_type   = MSG_TYPE_SENSOR;
        data.message_ID     = MSG_CODE_SENSOR_SENSORDATA_LIDAR_RTHETAFRONTLEFT;
        data.QoS            = MSG_QOS_SENSOR_SENSORDATA_LIDAR_RTHETAFRONTLEFT;
        data.SN             = m_snStubSensorData_LIDAR_RthetaFrontLeft++;

        AUTONOMOUS::COMMLIB::CFW::GetInstance().Send(data);

        if( m_logStubSensorData_LIDAR_RthetaFrontLeft.IsRun() )
        {
            m_vBuffStubSensorData_LIDAR_RthetaFrontLeft.clear();
            data.getFrameData(m_vBuffStubSensorData_LIDAR_RthetaFrontLeft);
            m_logStubSensorData_LIDAR_RthetaFrontLeft.WriteData(m_vBuffStubSensorData_LIDAR_RthetaFrontLeft.data(), m_vBuffStubSensorData_LIDAR_RthetaFrontLeft.size());
        }
    }

    // Log
    bool CreateLogStubSensorData_LIDAR_RthetaFrontLeft(char* logName);
    void CloseLogStubSensorData_LIDAR_RthetaFrontLeft();

private:
    std::vector<uint8_t>   m_vBuffStubSensorData_LIDAR_RthetaFrontLeft;
    uint8_t                m_snStubSensorData_LIDAR_RthetaFrontLeft;
protected:
    DevLib::IO::CLogWriter m_logStubSensorData_LIDAR_RthetaFrontLeft;
};


}
}
}

#endif /* CSTUBSENSORDATA_LIDAR_RTHETAFRONTLEFT_H */
