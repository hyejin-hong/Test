#include "CProxyAuto_UGVEraseResponse.h"

namespace AUTONOMOUS
{
namespace Interface
{
namespace Common
{

CProxyAuto_UGVEraseResponse::CProxyAuto_UGVEraseResponse()
{
    AUTONOMOUS::COMMLIB::CFW::GetInstance().RegisterSub(MSG_CODE_COMMON_AUTO_UGVERASERESPONSE, &CProxyAuto_UGVEraseResponse::_OnAuto_UGVEraseResponse, this);
}

CProxyAuto_UGVEraseResponse::~CProxyAuto_UGVEraseResponse()
{

}

bool CProxyAuto_UGVEraseResponse::CreateLogProxyAuto_UGVEraseResponse(char *logName)
{
    char fname[1024] = "";
    sprintf(fname, "./%s.Auto_UGVEraseResponse", logName);

    return m_logProxyAuto_UGVEraseResponse.Create(fname);
}

void CProxyAuto_UGVEraseResponse::CloseLogProxyAuto_UGVEraseResponse()
{
    m_logProxyAuto_UGVEraseResponse.Destroy();
}

void CProxyAuto_UGVEraseResponse::_OnAuto_UGVEraseResponse(AUTONOMOUS::Data::Common::StAuto_UGVEraseResponseComm& data)
{
    OnAuto_UGVEraseResponse(data);
    if( m_logProxyAuto_UGVEraseResponse.IsRun() )
    {
        m_vBuffProxyAuto_UGVEraseResponse.clear();
        data.getFrameData(m_vBuffProxyAuto_UGVEraseResponse);
        m_logProxyAuto_UGVEraseResponse.WriteData(m_vBuffProxyAuto_UGVEraseResponse.data(), m_vBuffProxyAuto_UGVEraseResponse.size());
    }
}

}
}
}
