#ifndef CSTUBAUTO_UGVERASEREQUEST_H
#define CSTUBAUTO_UGVERASEREQUEST_H

#include <CFW.h>
#include <Core/DevLib/Include/IO/CLogWriter/CLogWriter.h>

// ICD Data
#include "../../../Data/Common/Auto_UGVEraseRequest.h"

namespace AUTONOMOUS
{
namespace Interface
{
namespace Common
{

class CStubAuto_UGVEraseRequest
{
public :
    CStubAuto_UGVEraseRequest();
    virtual ~CStubAuto_UGVEraseRequest();

    inline void WriteAuto_UGVEraseRequest(AUTONOMOUS::Data::Common::StAuto_UGVEraseRequestComm& data)
    {
        data.message_type   = MSG_TYPE_COMMON;
        data.message_ID     = MSG_CODE_COMMON_AUTO_UGVERASEREQUEST;
        data.QoS            = MSG_QOS_COMMON_AUTO_UGVERASEREQUEST;
        data.SN             = m_snStubAuto_UGVEraseRequest++;

        AUTONOMOUS::COMMLIB::CFW::GetInstance().Send(data);

        if( m_logStubAuto_UGVEraseRequest.IsRun() )
        {
            m_vBuffStubAuto_UGVEraseRequest.clear();
            data.getFrameData(m_vBuffStubAuto_UGVEraseRequest);
            m_logStubAuto_UGVEraseRequest.WriteData(m_vBuffStubAuto_UGVEraseRequest.data(), m_vBuffStubAuto_UGVEraseRequest.size());
        }
    }

    // Log
    bool CreateLogStubAuto_UGVEraseRequest(char* logName);
    void CloseLogStubAuto_UGVEraseRequest();

private:
    std::vector<uint8_t>   m_vBuffStubAuto_UGVEraseRequest;
    uint8_t                m_snStubAuto_UGVEraseRequest;
protected:
    DevLib::IO::CLogWriter m_logStubAuto_UGVEraseRequest;
};


}
}
}

#endif /* CSTUBAUTO_UGVERASEREQUEST_H */
