#include "../../../Include/Core/CElapsedTimer/CElapsedTimer.h"

#include <stdio.h>

namespace DevLib
{

CElapsedTimer::CElapsedTimer()
{
    Reset();
}

void CElapsedTimer::Reset()
{
    clock_gettime(CLOCK_REALTIME, &m_time);
}

unsigned int CElapsedTimer::GetElapsedTime()
{
    unsigned int elapsed = GetElapsedTimeContinue();

    Reset();

    return elapsed;
}

unsigned int CElapsedTimer::GetElapsedTimeContinue()
{
    timespec cur;
    clock_gettime(CLOCK_REALTIME, &cur);

    return static_cast<unsigned int>((cur.tv_sec - m_time.tv_sec)*1000000 + ((cur.tv_nsec - m_time.tv_nsec) * 0.001 ));
}

void CElapsedTimer::PrintElapsedTime(char *str)
{
    printf("%s : %d us\n", str, GetElapsedTime());
}

void CElapsedTimer::PrintElapsedTimeContinue(char *str)
{
    printf("%s : %d us\n", str, GetElapsedTimeContinue());
}

}
