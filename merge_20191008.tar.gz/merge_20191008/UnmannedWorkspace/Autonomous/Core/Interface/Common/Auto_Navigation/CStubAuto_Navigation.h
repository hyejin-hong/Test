#ifndef CSTUBAUTO_NAVIGATION_H
#define CSTUBAUTO_NAVIGATION_H

#include <CFW.h>
#include <Core/DevLib/Include/IO/CLogWriter/CLogWriter.h>

// ICD Data
#include "../../../Data/Common/Auto_Navigation.h"

namespace AUTONOMOUS
{
namespace Interface
{
namespace Common
{

class CStubAuto_Navigation
{
public :
    CStubAuto_Navigation();
    virtual ~CStubAuto_Navigation();

    inline void WriteAuto_Navigation(AUTONOMOUS::Data::Common::StAuto_NavigationComm& data)
    {
        data.message_type   = MSG_TYPE_COMMON;
        data.message_ID     = MSG_CODE_COMMON_AUTO_NAVIGATION;
        data.QoS            = MSG_QOS_COMMON_AUTO_NAVIGATION;
        data.SN             = m_snStubAuto_Navigation++;

        AUTONOMOUS::COMMLIB::CFW::GetInstance().Send(data);

        if( m_logStubAuto_Navigation.IsRun() )
        {
            m_vBuffStubAuto_Navigation.clear();
            data.getFrameData(m_vBuffStubAuto_Navigation);
            m_logStubAuto_Navigation.WriteData(m_vBuffStubAuto_Navigation.data(), m_vBuffStubAuto_Navigation.size());
        }
    }

    // Log
    bool CreateLogStubAuto_Navigation(char* logName);
    void CloseLogStubAuto_Navigation();

private:
    std::vector<uint8_t>   m_vBuffStubAuto_Navigation;
    uint8_t                m_snStubAuto_Navigation;
protected:
    DevLib::IO::CLogWriter m_logStubAuto_Navigation;
};


}
}
}

#endif /* CSTUBAUTO_NAVIGATION_H */
