#ifndef __CSERIAL_H
#define __CSERIAL_H

#include <termios.h>
#include <fcntl.h>
#include <unistd.h>
#include <stdio.h>

namespace DevLib
{
namespace IO
{

class CSerial
{
public:
    CSerial(int serailFd = -1);
    virtual ~CSerial();

    bool OpenPort(char* dev_name);
    bool SetConfigurePort(speed_t baud_rate);

    void DestroyPort();

    bool IsCreated();

    int Send(void* pData, int size);
    int Recv(void* pData, int size);

private:
    int     m_fdSerial;
    termios m_ttycfg;
};

}
}

#endif // __CSERIAL_H
