#ifndef CSTUBAUTO_UGVESTOPREQUEST_H
#define CSTUBAUTO_UGVESTOPREQUEST_H

#include <CFW.h>
#include <Core/DevLib/Include/IO/CLogWriter/CLogWriter.h>

// ICD Data
#include "../../../Data/Common/Auto_UGVEStopRequest.h"

namespace AUTONOMOUS
{
namespace Interface
{
namespace Common
{

class CStubAuto_UGVEStopRequest
{
public :
    CStubAuto_UGVEStopRequest();
    virtual ~CStubAuto_UGVEStopRequest();

    inline void WriteAuto_UGVEStopRequest(AUTONOMOUS::Data::Common::StAuto_UGVEStopRequestComm& data)
    {
        data.message_type   = MSG_TYPE_COMMON;
        data.message_ID     = MSG_CODE_COMMON_AUTO_UGVESTOPREQUEST;
        data.QoS            = MSG_QOS_COMMON_AUTO_UGVESTOPREQUEST;
        data.SN             = m_snStubAuto_UGVEStopRequest++;

        AUTONOMOUS::COMMLIB::CFW::GetInstance().Send(data);

        if( m_logStubAuto_UGVEStopRequest.IsRun() )
        {
            m_vBuffStubAuto_UGVEStopRequest.clear();
            data.getFrameData(m_vBuffStubAuto_UGVEStopRequest);
            m_logStubAuto_UGVEStopRequest.WriteData(m_vBuffStubAuto_UGVEStopRequest.data(), m_vBuffStubAuto_UGVEStopRequest.size());
        }
    }

    // Log
    bool CreateLogStubAuto_UGVEStopRequest(char* logName);
    void CloseLogStubAuto_UGVEStopRequest();

private:
    std::vector<uint8_t>   m_vBuffStubAuto_UGVEStopRequest;
    uint8_t                m_snStubAuto_UGVEStopRequest;
protected:
    DevLib::IO::CLogWriter m_logStubAuto_UGVEStopRequest;
};


}
}
}

#endif /* CSTUBAUTO_UGVESTOPREQUEST_H */
