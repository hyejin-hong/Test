#ifndef CSTUBAUTO_OBSTACLE_H
#define CSTUBAUTO_OBSTACLE_H

#include <CFW.h>
#include <Core/DevLib/Include/IO/CLogWriter/CLogWriter.h>

// ICD Data
#include "../../../Data/Terrain/Auto_Obstacle.h"

namespace AUTONOMOUS
{
namespace Interface
{
namespace Terrain
{

class CStubAuto_Obstacle
{
public :
    CStubAuto_Obstacle();
    virtual ~CStubAuto_Obstacle();

    inline void WriteAuto_Obstacle(AUTONOMOUS::Data::Terrain::StAuto_ObstacleComm& data)
    {
        data.message_type   = MSG_TYPE_TERRAIN;
        data.message_ID     = MSG_CODE_TERRAIN_AUTO_OBSTACLE;
        data.QoS            = MSG_QOS_TERRAIN_AUTO_OBSTACLE;
        data.SN             = m_snStubAuto_Obstacle++;

        AUTONOMOUS::COMMLIB::CFW::GetInstance().Send(data);

        if( m_logStubAuto_Obstacle.IsRun() )
        {
            m_vBuffStubAuto_Obstacle.clear();
            data.getFrameData(m_vBuffStubAuto_Obstacle);
            m_logStubAuto_Obstacle.WriteData(m_vBuffStubAuto_Obstacle.data(), m_vBuffStubAuto_Obstacle.size());
        }
    }

    // Log
    bool CreateLogStubAuto_Obstacle(char* logName);
    void CloseLogStubAuto_Obstacle();

private:
    std::vector<uint8_t>   m_vBuffStubAuto_Obstacle;
    uint8_t                m_snStubAuto_Obstacle;
protected:
    DevLib::IO::CLogWriter m_logStubAuto_Obstacle;
};


}
}
}

#endif /* CSTUBAUTO_OBSTACLE_H */
