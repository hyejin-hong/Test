#ifndef CSTUBMAPDATA_PROBABILITYFUSED_H
#define CSTUBMAPDATA_PROBABILITYFUSED_H

#include <CFW.h>
#include <Core/DevLib/Include/IO/CLogWriter/CLogWriter.h>

// ICD Data
#include "../../../Data/Terrain/MapData_Probability.h"

namespace AUTONOMOUS
{
namespace Interface
{
namespace Terrain
{

class CStubMapData_ProbabilityFused
{
public :
    CStubMapData_ProbabilityFused();
    virtual ~CStubMapData_ProbabilityFused();

    inline void WriteMapData_ProbabilityFused(AUTONOMOUS::Data::Terrain::StMapData_ProbabilityComm& data)
    {
        data.message_type   = MSG_TYPE_TERRAIN;
        data.message_ID     = MSG_CODE_TERRAIN_MAPDATA_PROBABILITYFUSED;
        data.QoS            = MSG_QOS_TERRAIN_MAPDATA_PROBABILITYFUSED;
        data.SN             = m_snStubMapData_ProbabilityFused++;

        AUTONOMOUS::COMMLIB::CFW::GetInstance().Send(data);

        if( m_logStubMapData_ProbabilityFused.IsRun() )
        {
            m_vBuffStubMapData_ProbabilityFused.clear();
            data.getFrameData(m_vBuffStubMapData_ProbabilityFused);
            m_logStubMapData_ProbabilityFused.WriteData(m_vBuffStubMapData_ProbabilityFused.data(), m_vBuffStubMapData_ProbabilityFused.size());
        }
    }

    // Log
    bool CreateLogStubMapData_ProbabilityFused(char* logName);
    void CloseLogStubMapData_ProbabilityFused();

private:
    std::vector<uint8_t>   m_vBuffStubMapData_ProbabilityFused;
    uint8_t                m_snStubMapData_ProbabilityFused;
protected:
    DevLib::IO::CLogWriter m_logStubMapData_ProbabilityFused;
};


}
}
}

#endif /* CSTUBMAPDATA_PROBABILITYFUSED_H */
