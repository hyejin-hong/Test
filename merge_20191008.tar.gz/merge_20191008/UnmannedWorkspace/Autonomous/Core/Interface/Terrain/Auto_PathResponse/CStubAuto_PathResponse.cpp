#include "CStubAuto_PathResponse.h"

namespace AUTONOMOUS
{
namespace Interface
{
namespace Terrain
{

CStubAuto_PathResponse::CStubAuto_PathResponse()
{
    m_snStubAuto_PathResponse = 0;
}

CStubAuto_PathResponse::~CStubAuto_PathResponse()
{ 

}

bool CStubAuto_PathResponse::CreateLogStubAuto_PathResponse(char *logName)
{
    char fname[1024] = "";
    sprintf(fname, "./%s.Auto_PathResponse", logName);

    return m_logStubAuto_PathResponse.Create(fname);
}

void CStubAuto_PathResponse::CloseLogStubAuto_PathResponse()
{
    m_logStubAuto_PathResponse.Destroy();
}


}
}
}
