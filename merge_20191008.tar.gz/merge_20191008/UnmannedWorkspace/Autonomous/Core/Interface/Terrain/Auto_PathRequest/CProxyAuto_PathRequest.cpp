#include "CProxyAuto_PathRequest.h"

namespace AUTONOMOUS
{
namespace Interface
{
namespace Terrain
{

CProxyAuto_PathRequest::CProxyAuto_PathRequest()
{
    AUTONOMOUS::COMMLIB::CFW::GetInstance().RegisterSub(MSG_CODE_TERRAIN_AUTO_PATHREQUEST, &CProxyAuto_PathRequest::_OnAuto_PathRequest, this);
}

CProxyAuto_PathRequest::~CProxyAuto_PathRequest()
{

}

bool CProxyAuto_PathRequest::CreateLogProxyAuto_PathRequest(char *logName)
{
    char fname[1024] = "";
    sprintf(fname, "./%s.Auto_PathRequest", logName);

    return m_logProxyAuto_PathRequest.Create(fname);
}

void CProxyAuto_PathRequest::CloseLogProxyAuto_PathRequest()
{
    m_logProxyAuto_PathRequest.Destroy();
}

void CProxyAuto_PathRequest::_OnAuto_PathRequest(AUTONOMOUS::Data::Terrain::StAuto_PathRequestComm& data)
{
    OnAuto_PathRequest(data);
    if( m_logProxyAuto_PathRequest.IsRun() )
    {
        m_vBuffProxyAuto_PathRequest.clear();
        data.getFrameData(m_vBuffProxyAuto_PathRequest);
        m_logProxyAuto_PathRequest.WriteData(m_vBuffProxyAuto_PathRequest.data(), m_vBuffProxyAuto_PathRequest.size());
    }
}

}
}
}
