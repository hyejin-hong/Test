#ifndef CPROXYEAUTO_OBSTACLE_H
#define CPROXYEAUTO_OBSTACLE_H

#include <Core/DevLib/Include/IO/CLogWriter/CLogWriter.h>

// ICD Data
#include "../../../Data/Terrain/Auto_Obstacle.h"

namespace AUTONOMOUS
{
namespace Interface
{
namespace Terrain
{

class CProxyAuto_Obstacle
{
public :
    CProxyAuto_Obstacle();
    virtual ~CProxyAuto_Obstacle();

    virtual void OnAuto_Obstacle(AUTONOMOUS::Data::Terrain::StAuto_ObstacleComm& data) = 0;

    // Log
    bool CreateLogProxyAuto_Obstacle(char* logName);
    void CloseLogProxyAuto_Obstacle();

private:
    std::vector<uint8_t>   m_vBuffProxyAuto_Obstacle;
protected:
    DevLib::IO::CLogWriter m_logProxyAuto_Obstacle;

    void _OnAuto_Obstacle(AUTONOMOUS::Data::Terrain::StAuto_ObstacleComm& data);
};


}
}
}

#endif /* CPROXYEAUTO_OBSTACLE_H */
