#ifndef CSTUBAUTO_PATHREQUEST_H
#define CSTUBAUTO_PATHREQUEST_H

#include <CFW.h>
#include <Core/DevLib/Include/IO/CLogWriter/CLogWriter.h>

// ICD Data
#include "../../../Data/Terrain/Auto_PathRequest.h"

namespace AUTONOMOUS
{
namespace Interface
{
namespace Terrain
{

class CStubAuto_PathRequest
{
public :
    CStubAuto_PathRequest();
    virtual ~CStubAuto_PathRequest();

    inline void WriteAuto_PathRequest(AUTONOMOUS::Data::Terrain::StAuto_PathRequestComm& data)
    {
        data.message_type   = MSG_TYPE_TERRAIN;
        data.message_ID     = MSG_CODE_TERRAIN_AUTO_PATHREQUEST;
        data.QoS            = MSG_QOS_TERRAIN_AUTO_PATHREQUEST;
        data.SN             = m_snStubAuto_PathRequest++;

        AUTONOMOUS::COMMLIB::CFW::GetInstance().Send(data);

        if( m_logStubAuto_PathRequest.IsRun() )
        {
            m_vBuffStubAuto_PathRequest.clear();
            data.getFrameData(m_vBuffStubAuto_PathRequest);
            m_logStubAuto_PathRequest.WriteData(m_vBuffStubAuto_PathRequest.data(), m_vBuffStubAuto_PathRequest.size());
        }
    }

    // Log
    bool CreateLogStubAuto_PathRequest(char* logName);
    void CloseLogStubAuto_PathRequest();

private:
    std::vector<uint8_t>   m_vBuffStubAuto_PathRequest;
    uint8_t                m_snStubAuto_PathRequest;
protected:
    DevLib::IO::CLogWriter m_logStubAuto_PathRequest;
};


}
}
}

#endif /* CSTUBAUTO_PATHREQUEST_H */
