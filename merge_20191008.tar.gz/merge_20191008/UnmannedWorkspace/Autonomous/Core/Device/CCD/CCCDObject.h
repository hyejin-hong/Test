/*
 * CCCDObject.h
 *
 *  Created on: 2019. 4. 8.
 *      Author: fme
 */

#ifndef CCCDOBJECT_H
#define CCCDOBJECT_H

#include "../../DevLib/Include/Core/CTimer/CTimer.h"
#include "../../DevLib/Include/IO/CSocketReceiver/CSocketReceiver.h"
#include "../../Data/Common/Common.h"

#include <vector>

namespace AUTONOMOUS
{
namespace Device
{
namespace CCD
{

class CObserverCCDObject
{
public :
	virtual ~CObserverCCDObject() { }

    virtual void OnCCDPack(uint8_t* pCCDPack) = 0;
};

class CCCDObject
		: public DevLib::IO::CSocketReceiver
		  , public DevLib::CTimer
{
public:
	CCCDObject(CObserverCCDObject* pObserver = 0);
	virtual ~CCCDObject();

	bool Create(char* bindIP, int port);
	bool Create();

private:

	virtual void OnReceive();

	CObserverCCDObject* m_pObserverCCDObject;

	// Image Buffer
	std::vector<AUTONOMOUS::uint8_t>	m_bufferImage;

	// Test Code
private :
	virtual void OnTimer(void*);
};

}
}
}





#endif /*CCCDOBJECT_H */
