#ifndef CPROXYEAUTO_DRIVECONTROLAUTONOMY_H
#define CPROXYEAUTO_DRIVECONTROLAUTONOMY_H

#include <Core/DevLib/Include/IO/CLogWriter/CLogWriter.h>

// ICD Data
#include "../../../Data/Autonomy/Auto_DriveControlAutonomy.h"

namespace AUTONOMOUS
{
namespace Interface
{
namespace Autonomy
{

class CProxyAuto_DriveControlAutonomy
{
public :
    CProxyAuto_DriveControlAutonomy();
    virtual ~CProxyAuto_DriveControlAutonomy();

    virtual void OnAuto_DriveControlAutonomy(AUTONOMOUS::Data::Autonomy::StAuto_DriveControlComm& data) = 0;

    // Log
    bool CreateLogProxyAuto_DriveControlAutonomy(char* logName);
    void CloseLogProxyAuto_DriveControlAutonomy();

private:
    std::vector<uint8_t>   m_vBuffProxyAuto_DriveControlAutonomy;
protected:
    DevLib::IO::CLogWriter m_logProxyAuto_DriveControlAutonomy;

    void _OnAuto_DriveControlAutonomy(AUTONOMOUS::Data::Autonomy::StAuto_DriveControlComm& data);
};


}
}
}

#endif /* CPROXYEAUTO_DRIVECONTROLAUTONOMY_H */
