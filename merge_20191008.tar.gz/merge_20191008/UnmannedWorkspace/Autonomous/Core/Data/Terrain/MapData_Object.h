#ifndef MAPDATA_OBJECT_H
#define MAPDATA_OBJECT_H

#include <CFW.h>
#include "../Common/Common.h"
#include "../Common/Auto_Navigation.h"

namespace AUTONOMOUS
{
namespace Data
{
namespace Terrain
{

typedef struct _StXYZ
{
    flt64_t X;
    flt64_t Y;
    flt64_t Z;
    uint16_t nCluster;
} StXYZ;

typedef struct _StMapData_Object
{
    flt64_t                                         SyncTime;       // 동기화 시간
    AUTONOMOUS::Data::Common::StNavigationDetail    Navigation;     // 항법
    uint16_t                                        Num_Obstacle;   // 장애물 개수(N)

    StXYZ                                           Obstacle[1000];  // 장애물로 탐지되는 Point Cloud 각각에 대한 정보

} StMapData_Object;


typedef struct _StMapData_ObjectComm : public AUTONOMOUS::COMMLIB::Header, public StMapData_Object
{
    virtual void setFrameData(uint8_t* buff)
    {
        buff = deserializeData(buff, SyncTime);

        buff = deserializeData(buff, Navigation.TimeStamp);
        std::for_each(Navigation.Zone, Navigation.Zone + 2, [&](int8_t& d)
        {
            buff = deserializeData(buff, d);
        });
        buff = deserializeData(buff, Navigation.East);
        buff = deserializeData(buff, Navigation.North);
        buff = deserializeData(buff, Navigation.Elevation);
        buff = deserializeData(buff, Navigation.Roll);
        buff = deserializeData(buff, Navigation.Pitch);
        buff = deserializeData(buff, Navigation.Heading);
        buff = deserializeData(buff, Navigation.VelocityLinearX);
        buff = deserializeData(buff, Navigation.VelocityLinearY);
        buff = deserializeData(buff, Navigation.VelocityLinearZ);
        buff = deserializeData(buff, Navigation.VelocityAngluarX);
        buff = deserializeData(buff, Navigation.VelocityAngluarY);
        buff = deserializeData(buff, Navigation.VelocityAngluarZ);

        buff = deserializeData(buff, Num_Obstacle);

        std::for_each(Obstacle, Obstacle + Num_Obstacle, [&](StXYZ& d)
        {
            buff = deserializeData(buff, d.X);
            buff = deserializeData(buff, d.Y);
            buff = deserializeData(buff, d.Z);
            buff = deserializeData(buff, d.nCluster);
        });
    }

    virtual void getFrameData(std::vector<uint8_t>& buff)
    {
        serializeData(buff, SyncTime);

        serializeData(buff, Navigation.TimeStamp);
        std::for_each(Navigation.Zone, Navigation.Zone + 2, [&](int8_t d)
        {
            serializeData(buff, d);
        });
        serializeData(buff, Navigation.East);
        serializeData(buff, Navigation.North);
        serializeData(buff, Navigation.Elevation);
        serializeData(buff, Navigation.Roll);
        serializeData(buff, Navigation.Pitch);
        serializeData(buff, Navigation.Heading);
        serializeData(buff, Navigation.VelocityLinearX);
        serializeData(buff, Navigation.VelocityLinearY);
        serializeData(buff, Navigation.VelocityLinearZ);
        serializeData(buff, Navigation.VelocityAngluarX);
        serializeData(buff, Navigation.VelocityAngluarY);
        serializeData(buff, Navigation.VelocityAngluarZ);

        serializeData(buff, Num_Obstacle);

        std::for_each(Obstacle, Obstacle + Num_Obstacle, [&](StXYZ d)
        {
            serializeData(buff, d.X);
            serializeData(buff, d.Y);
            serializeData(buff, d.Z);
            serializeData(buff, d.nCluster);
        });
    }

} StMapData_ObjectComm;
}
}
}

#endif // MAPDATA_OBJECT_H
