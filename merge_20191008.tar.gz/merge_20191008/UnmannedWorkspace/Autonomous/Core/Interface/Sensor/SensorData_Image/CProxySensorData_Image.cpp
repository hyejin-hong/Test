#include "CProxySensorData_Image.h"

namespace AUTONOMOUS
{
namespace Interface
{
namespace Sensor
{

CProxySensorData_Image::CProxySensorData_Image()
{
    AUTONOMOUS::COMMLIB::CFW::GetInstance().RegisterSub(MSG_CODE_SENSOR_SENSORDATA_IMAGE, &CProxySensorData_Image::_OnSensorData_Image, this);
}

CProxySensorData_Image::~CProxySensorData_Image()
{

}

bool CProxySensorData_Image::CreateLogProxySensorData_Image(char *logName)
{
    char fname[1024] = "";
    sprintf(fname, "./%s.SensorData_Image", logName);

    return m_logProxySensorData_Image.Create(fname);
}

void CProxySensorData_Image::CloseLogProxySensorData_Image()
{
    m_logProxySensorData_Image.Destroy();
}

void CProxySensorData_Image::_OnSensorData_Image(AUTONOMOUS::Data::Sensor::StSensorData_ImageComm& data)
{
    OnSensorData_Image(data);
    if( m_logProxySensorData_Image.IsRun() )
    {
        m_vBuffProxySensorData_Image.clear();
        data.getFrameData(m_vBuffProxySensorData_Image);
        m_logProxySensorData_Image.WriteData(m_vBuffProxySensorData_Image.data(), m_vBuffProxySensorData_Image.size());
    }
}

}
}
}
