#ifndef CONFIG_H
#define CONFIG_H

//DevLib::Utility::GetConfigDouble("NAVIGATION_OFFSET", "X", 0.0, DevLib::Utility::GetMakeConfigName());
namespace DevLib
{
namespace Utility
{

char* GetProcessorName();
char* GetMakeConfigName();

int GetConfigInt(const char* GroupName, const char* Idendity, int defValue, const char* configName = "./Config.json");
void GetConfigString(const char* GroupName, const char* Idendity, const char* defValue, char* resultValue, int resultSize, const char* configName = "./Config.json");
double GetConfigDouble(const char* GroupName, const char* Idendity, double defValue, const char* configName = "./Config.json");

void SetConfigInt(const char* GroupName, const char* Idendity, int value, const char* configName = "./Config.json");
void SetConfigString(const char* GroupName, const char* Idendity, const char* value, const char* configName = "./Config.json");
void SetConfigDouble(const char* GroupName, const char* Idendity, double value, const char* configName = "./Config.json");

}
}

#endif // CONFIG_H
