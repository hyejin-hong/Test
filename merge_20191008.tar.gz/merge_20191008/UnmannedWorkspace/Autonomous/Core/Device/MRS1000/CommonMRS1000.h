/*
 * CommonSick.h
 *
 *  Created on: 2019. 4. 19.
 *      Author: fm
 */

#ifndef COMMONMRS1000_H
#define COMMONMRS1000_H

namespace AUTONOMOUS
{
namespace Device
{
namespace MRS1000
{

/************************************************************************/
/* Const Definition                                                     */
/************************************************************************/
const unsigned int g_maxLength      = 7000;
const unsigned int g_defaultPort    = 2112;

// 로그인 정보
enum USER_LEVEL
{
    LEVEL_MAINTENANCE   = 0x02,
    LEVEL_CLIENT        = 0x03,
    LEVEL_SERVICE       = 0x04
};

static const char* g_pwMain     = "B21ACE26";
static const char* g_pwClient	= "F4724744";
static const char* g_pWService	= "81BE23AA";


// 스캔 주기
const unsigned int g_freq = 5000; // 50Hz

// 각 해상도
//const unsigned int g_res0_1667Deg	= 1667;		// 0.1667 deg
const unsigned int g_res0_2500Deg	= 2500;		// 0.2500 deg
//const unsigned int g_res0_3333Deg	= 3333;		// 0.3333 deg
const unsigned int g_res0_5000Deg	= 5000;		// 0.5000 deg
//const unsigned int g_res0_6667Deg	= 6667;		// 0.6667 deg
//const unsigned int g_res0_7500Deg	= 7500;		// 0.7500 deg
//const unsigned int g_res1_0000Deg	= 10000;	// 1.0000 deg

static enum
{
    STATUS_UNDEFINED = 0,
    STATUS_INITALISATION = 1,
    STATUS_CONFIGURATION = 2,
    STATUS_IDLE = 3,
    STATUS_ROTATED = 4,
    STATUS_PREPERATION = 5,
    STATUS_READY = 6,
    STATUS_READY_FOR_MEASUREMENT = 7
} SENSOR_STATUS;

/************************************************************************/
/* Message Definition                                                   */
/************************************************************************/
const char g_stx = 0x02;	// - 시작 비트
const char g_sep = ' ';	// - 구분자
const char g_etx = 0x03;	// - 끝 비트

// Messge Type Definition.
static const char* g_TypeAnsScan		= "sSN";
static const char* g_TypeCmdScan		= "sEN";
static const char* g_TypeMethodName             = "sMN";
static const char* g_TypeAnswer			= "sEA";
static const char* g_TypeReqStatus		= "sRN";
static const char* g_TypeAnsStatus		= "sRA";

// Messge Header Definition.
//static const char* g_AckScanData = "sSN";
static const char* g_CmdRecvDataCont = "LMDscandata";
static const char* g_CmdStart = "LMCstartmeas";
static const char* g_CmdStop = "LMCstopmeas";
static const char* g_CmdLogin = "SetAccessMode";
static const char* g_CmdLogout = "Run";
static const char* g_CmdConfig = "mLMPsetscancfg";
static const char* g_CmdSaveParam = "mEEwriteall";
static const char* g_CmdStatus = "STlms";

// 센서 데이터 구조체
typedef struct
{
    float 				resolution;
    unsigned char       layerIndex;
    unsigned short*     scanData;
    unsigned int 		length;
} __attribute__((packed)) StMRS1000Packet;

}
}
}

#endif /* COMMONMRS1000_H */
