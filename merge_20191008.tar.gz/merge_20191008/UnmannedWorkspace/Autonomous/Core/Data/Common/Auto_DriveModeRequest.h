#ifndef DRIVE_CHANGEMODE_H
#define DRIVE_CHANGEMODE_H

#include <CFW.h>
#include "../Common/Common.h"

namespace AUTONOMOUS
{
namespace Data
{
namespace Common
{

typedef struct _StAuto_DriveModeRequest
{
    flt64_t             SyncTime;       // 동기화 시간
    AUTONOMOUS::StMode  Mode;           // 주행모드 & 시스템모드

} StAuto_DriveModeRequest;


typedef struct _StAuto_DriveModeRequestComm : public AUTONOMOUS::COMMLIB::Header, public StAuto_DriveModeRequest
{
    virtual void setFrameData(uint8_t* buff)
    {
        buff = deserializeData(buff, SyncTime);
        buff = deserializeData(buff, Mode.Mode);
    }

    virtual void getFrameData(std::vector<uint8_t>& buff)
    {
        serializeData(buff, SyncTime);
        serializeData(buff, Mode.Mode);
    }

} StAuto_DriveModeRequestComm;

}
}
}


#endif // DRIVE_CHANGEMODE_H
