#include "CProxySensorData_LIDAR_RthetaFrontCenter.h"

namespace AUTONOMOUS
{
namespace Interface
{
namespace Sensor
{

CProxySensorData_LIDAR_RthetaFrontCenter::CProxySensorData_LIDAR_RthetaFrontCenter()
{
    AUTONOMOUS::COMMLIB::CFW::GetInstance().RegisterSub(MSG_CODE_SENSOR_SENSORDATA_LIDAR_RTHETAFRONTCENTER, &CProxySensorData_LIDAR_RthetaFrontCenter::_OnSensorData_LIDAR_RthetaFrontCenter, this);
}

CProxySensorData_LIDAR_RthetaFrontCenter::~CProxySensorData_LIDAR_RthetaFrontCenter()
{

}

bool CProxySensorData_LIDAR_RthetaFrontCenter::CreateLogProxySensorData_LIDAR_RthetaFrontCenter(char *logName)
{
    char fname[1024] = "";
    sprintf(fname, "./%s.SensorData_LIDAR_RthetaFrontCenter", logName);

    return m_logProxySensorData_LIDAR_RthetaFrontCenter.Create(fname);
}

void CProxySensorData_LIDAR_RthetaFrontCenter::CloseLogProxySensorData_LIDAR_RthetaFrontCenter()
{
    m_logProxySensorData_LIDAR_RthetaFrontCenter.Destroy();
}

void CProxySensorData_LIDAR_RthetaFrontCenter::_OnSensorData_LIDAR_RthetaFrontCenter(AUTONOMOUS::Data::Sensor::StSensorData_LIDAR_RthetaComm& data)
{
    OnSensorData_LIDAR_RthetaFrontCenter(data);
    if( m_logProxySensorData_LIDAR_RthetaFrontCenter.IsRun() )
    {
        m_vBuffProxySensorData_LIDAR_RthetaFrontCenter.clear();
        data.getFrameData(m_vBuffProxySensorData_LIDAR_RthetaFrontCenter);
        m_logProxySensorData_LIDAR_RthetaFrontCenter.WriteData(m_vBuffProxySensorData_LIDAR_RthetaFrontCenter.data(), m_vBuffProxySensorData_LIDAR_RthetaFrontCenter.size());
    }
}

}
}
}
