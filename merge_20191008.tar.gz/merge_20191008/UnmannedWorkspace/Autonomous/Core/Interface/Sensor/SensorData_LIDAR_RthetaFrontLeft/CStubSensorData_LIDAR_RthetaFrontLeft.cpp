#include "CStubSensorData_LIDAR_RthetaFrontLeft.h"

namespace AUTONOMOUS
{
namespace Interface
{
namespace Sensor
{

CStubSensorData_LIDAR_RthetaFrontLeft::CStubSensorData_LIDAR_RthetaFrontLeft()
{
    m_snStubSensorData_LIDAR_RthetaFrontLeft = 0;
}

CStubSensorData_LIDAR_RthetaFrontLeft::~CStubSensorData_LIDAR_RthetaFrontLeft()
{ 

}

bool CStubSensorData_LIDAR_RthetaFrontLeft::CreateLogStubSensorData_LIDAR_RthetaFrontLeft(char *logName)
{
    char fname[1024] = "";
    sprintf(fname, "./%s.SensorData_LIDAR_RthetaFrontLeft", logName);

    return m_logStubSensorData_LIDAR_RthetaFrontLeft.Create(fname);
}

void CStubSensorData_LIDAR_RthetaFrontLeft::CloseLogStubSensorData_LIDAR_RthetaFrontLeft()
{
    m_logStubSensorData_LIDAR_RthetaFrontLeft.Destroy();
}


}
}
}
