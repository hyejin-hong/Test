#include "CProxyAuto_DriveModeRequest.h"

namespace AUTONOMOUS
{
namespace Interface
{
namespace Common
{

CProxyAuto_DriveModeRequest::CProxyAuto_DriveModeRequest()
{
    AUTONOMOUS::COMMLIB::CFW::GetInstance().RegisterSub(MSG_CODE_COMMON_AUTO_DRIVEMODEREQUEST, &CProxyAuto_DriveModeRequest::_OnAuto_DriveModeRequest, this);
}

CProxyAuto_DriveModeRequest::~CProxyAuto_DriveModeRequest()
{

}

bool CProxyAuto_DriveModeRequest::CreateLogProxyAuto_DriveModeRequest(char *logName)
{
    char fname[1024] = "";
    sprintf(fname, "./%s.Auto_DriveModeRequest", logName);

    return m_logProxyAuto_DriveModeRequest.Create(fname);
}

void CProxyAuto_DriveModeRequest::CloseLogProxyAuto_DriveModeRequest()
{
    m_logProxyAuto_DriveModeRequest.Destroy();
}

void CProxyAuto_DriveModeRequest::_OnAuto_DriveModeRequest(AUTONOMOUS::Data::Common::StAuto_DriveModeRequestComm& data)
{
    OnAuto_DriveModeRequest(data);
    if( m_logProxyAuto_DriveModeRequest.IsRun() )
    {
        m_vBuffProxyAuto_DriveModeRequest.clear();
        data.getFrameData(m_vBuffProxyAuto_DriveModeRequest);
        m_logProxyAuto_DriveModeRequest.WriteData(m_vBuffProxyAuto_DriveModeRequest.data(), m_vBuffProxyAuto_DriveModeRequest.size());
    }
}

}
}
}
