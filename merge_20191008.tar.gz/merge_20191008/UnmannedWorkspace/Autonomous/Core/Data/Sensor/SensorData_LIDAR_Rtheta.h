#ifndef SENSORDATA_LIDAR_RTHETA_H
#define SENSORDATA_LIDAR_RTHETA_H

#include <CFW.h>
#include "../Common/Common.h"
#include "../Common/Auto_Navigation.h"
#include "SensorType.h"

namespace AUTONOMOUS
{
namespace Data
{
namespace Sensor
{

const unsigned int buffSize = 65000;

typedef struct
{
    uint8_t		LayerIndex;	// 레이어 정보
    uint16_t    Range;		// 거리정보
    uint16_t    Angle;		// 수평 각도 ( scale : 1 = 0.001 deg ), (센서 우측 : 0deg), (시계 방향 +), (Min : 0, Max : 35999)
    uint8_t		Intensity;	// Intensity Value ( Min : 0, Max : 255 )
} StRTheta;

// Lidar Rtheta
typedef struct _StSensorData_LIDAR_Rtheta
{
    flt64_t                                         SyncTime;               // 동기화 시간
    AUTONOMOUS::Data::Common::StNavigationDetail    Navigation;             // 항법
    uint16_t                                        SensorType;             // 센서 종류
    uint8_t                                         LayerCount;             // 레이어 개수
    uint32_t                                        TotalPointNo;           // 총 포인트 수
    StRTheta                                        LidarData[buffSize];	// 각도별 거리 정보

} StSensorData_LIDAR_Rtheta;


// Lidar Rtheta
typedef struct _StSensorData_LIDAR_RthetaComm : public AUTONOMOUS::COMMLIB::Header, public StSensorData_LIDAR_Rtheta
{
    virtual void setFrameData(uint8_t* buff)
    {
        buff = deserializeData(buff, SyncTime);

        buff = deserializeData(buff, Navigation.TimeStamp);
        std::for_each(Navigation.Zone, Navigation.Zone + 2, [&](int8_t& d)
        {
            buff = deserializeData(buff, d);
        });
        buff = deserializeData(buff, Navigation.East);
        buff = deserializeData(buff, Navigation.North);
        buff = deserializeData(buff, Navigation.Elevation);
        buff = deserializeData(buff, Navigation.Roll);
        buff = deserializeData(buff, Navigation.Pitch);
        buff = deserializeData(buff, Navigation.Heading);
        buff = deserializeData(buff, Navigation.VelocityLinearX);
        buff = deserializeData(buff, Navigation.VelocityLinearY);
        buff = deserializeData(buff, Navigation.VelocityLinearZ);
        buff = deserializeData(buff, Navigation.VelocityAngluarX);
        buff = deserializeData(buff, Navigation.VelocityAngluarY);
        buff = deserializeData(buff, Navigation.VelocityAngluarZ);

        buff = deserializeData(buff, SensorType);
        buff = deserializeData(buff, LayerCount);
        buff = deserializeData(buff, TotalPointNo);

        std::for_each(LidarData, LidarData + TotalPointNo, [&](StRTheta& d)
        {
            buff = deserializeData(buff, d.LayerIndex);
            buff = deserializeData(buff, d.Range);
            buff = deserializeData(buff, d.Angle);
            buff = deserializeData(buff, d.Intensity);
        });
    }

    virtual void getFrameData(std::vector<uint8_t>& buff)
    {
        serializeData(buff, SyncTime);

        serializeData(buff, Navigation.TimeStamp);
        std::for_each(Navigation.Zone, Navigation.Zone + 2, [&](int8_t d)
        {
            serializeData(buff, d);
        });
        serializeData(buff, Navigation.East);
        serializeData(buff, Navigation.North);
        serializeData(buff, Navigation.Elevation);
        serializeData(buff, Navigation.Roll);
        serializeData(buff, Navigation.Pitch);
        serializeData(buff, Navigation.Heading);
        serializeData(buff, Navigation.VelocityLinearX);
        serializeData(buff, Navigation.VelocityLinearY);
        serializeData(buff, Navigation.VelocityLinearZ);
        serializeData(buff, Navigation.VelocityAngluarX);
        serializeData(buff, Navigation.VelocityAngluarY);
        serializeData(buff, Navigation.VelocityAngluarZ);

        serializeData(buff, SensorType);
        serializeData(buff, LayerCount);
        serializeData(buff, TotalPointNo);

        std::for_each(LidarData, LidarData + TotalPointNo, [&](StRTheta d)
        {
            serializeData(buff, d.LayerIndex);
            serializeData(buff, d.Range);
            serializeData(buff, d.Angle);
            serializeData(buff, d.Intensity);
        });
    }

} StSensorData_LIDAR_RthetaComm;

}
}
}

#endif // SENSORDATA_LIDAR_RTHETA_H
