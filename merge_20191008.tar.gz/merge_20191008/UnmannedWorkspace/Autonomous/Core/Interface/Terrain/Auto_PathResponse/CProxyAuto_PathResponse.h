#ifndef CPROXYEAUTO_PATHRESPONSE_H
#define CPROXYEAUTO_PATHRESPONSE_H

#include <Core/DevLib/Include/IO/CLogWriter/CLogWriter.h>

// ICD Data
#include "../../../Data/Terrain/Auto_PathResponse.h"

namespace AUTONOMOUS
{
namespace Interface
{
namespace Terrain
{

class CProxyAuto_PathResponse
{
public :
    CProxyAuto_PathResponse();
    virtual ~CProxyAuto_PathResponse();

    virtual void OnAuto_PathResponse(AUTONOMOUS::Data::Terrain::StAuto_PathResponseComm& data) = 0;

    // Log
    bool CreateLogProxyAuto_PathResponse(char* logName);
    void CloseLogProxyAuto_PathResponse();

private:
    std::vector<uint8_t>   m_vBuffProxyAuto_PathResponse;
protected:
    DevLib::IO::CLogWriter m_logProxyAuto_PathResponse;

    void _OnAuto_PathResponse(AUTONOMOUS::Data::Terrain::StAuto_PathResponseComm& data);
};


}
}
}

#endif /* CPROXYEAUTO_PATHRESPONSE_H */
