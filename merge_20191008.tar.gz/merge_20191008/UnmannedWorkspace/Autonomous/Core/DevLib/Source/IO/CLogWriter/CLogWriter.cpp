#include "../../../Include/IO/CLogWriter/CLogWriter.h"

#include <memory.h>

namespace DevLib
{
namespace IO
{

CLogWriter::CLogWriter()
{
	// TODO Auto-generated constructor stub

}

CLogWriter::~CLogWriter()
{
	// TODO Auto-generated destructor stub
}

bool CLogWriter::Create(char* logName)
{
	bool bRet = false;

	if( DevLib::IO::CFile::Create(logName, "wb") )
	{
		if( DevLib::CEvent::Create(0) )
		{
			if( DevLib::CMutex::Create() )
			{
				ServiceStart();
				bRet = true;
			}
			else
			{
				DevLib::CEvent::Destroy();
			}
		}
		else
		{
			DevLib::IO::CFile::Destroy();
		}
	}

	return bRet;
}

bool CLogWriter::WriteData(void* pData, unsigned int size)
{
	bool bRet = false;

	if( IsRun() )
	{
		std::vector<unsigned char> data;
		data.resize(size);
		memcpy(&data[0], pData, size);

		DevLib::CMutex::Lock();
		m_queueData.push(data);
		DevLib::CMutex::UnLock();

		SetEvent();

		bRet = true;
	}

	return bRet;
}

void CLogWriter::Destroy()
{
	ServiceStop();
	SetEvent();
}

void CLogWriter::Run()
{
	while( IsRun() )
	{
		if( WaitForEvent(100) )
		{
			DevLib::CMutex::Lock();
			unsigned int qSize = m_queueData.size();
			DevLib::CMutex::UnLock();

			while( qSize-- )
			{
				DevLib::CMutex::Lock();
				std::vector<unsigned char> data = m_queueData.front();
				m_queueData.pop();
				DevLib::CMutex::UnLock();

				if( DevLib::IO::CFile::IsCreated() )
				{
                    unsigned int size = data.size();
                    DevLib::IO::CFile::Write(&size, sizeof(unsigned int));
					DevLib::IO::CFile::Write(&data[0], data.size());
				}
			}
		}
	}

	unsigned int qSize = m_queueData.size();

	while( qSize-- )
	{
		std::vector<unsigned char> data = m_queueData.front();
		m_queueData.pop();

		if( DevLib::IO::CFile::IsCreated() )
		{
			DevLib::IO::CFile::Write(&data[0], data.size());
		}
	}

	DevLib::IO::CFile::Destroy();
}

}
}
