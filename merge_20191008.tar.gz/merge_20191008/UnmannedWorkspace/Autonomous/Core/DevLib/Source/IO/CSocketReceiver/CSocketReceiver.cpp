#include "../../../Include/IO/CSocketReceiver/CSocketReceiver.h"

#include <sys/socket.h>
#include <sys/epoll.h>

#include <stdio.h>
namespace DevLib
{
namespace IO
{


CObserverReceiver::~CObserverReceiver()
{

}

void CObserverReceiver::OnReceived(DevLib::IO::CSocket*)
{

}


CSocketReceiver::CSocketReceiver(int sockFD)
    : DevLib::IO::CSocket(sockFD), m_pObserverReceiver(nullptr)
{
    // TODO Auto-generated constructor stub

}

CSocketReceiver::~CSocketReceiver()
{
    // TODO Auto-generated destructor stub
}

void CSocketReceiver::SetObserver(CObserverReceiver *pObserver)
{
    m_pObserverReceiver = pObserver;
}

void CSocketReceiver::OnTimeOut()
{
    //printf("OnTimeOut\n");
}

void CSocketReceiver::OnReceive()
{
//    printf("OnReceive\n");
}

void CSocketReceiver::OnClosed()
{
//    printf("OnClosed\n");
}

void CSocketReceiver::Run()
{
    int fdRecv = epoll_create(1);

    if( fdRecv != -1 )
    {
        struct epoll_event ev;
        struct epoll_event evValue;

        ev.events = EPOLLIN | EPOLLRDHUP;
        ev.data.fd = GetSocket();

        if( epoll_ctl(fdRecv, EPOLL_CTL_ADD, GetSocket(), &ev) != -1 )
        {
            while( IsRun() )
            {
                if( epoll_wait(fdRecv, &evValue, 1, 100) != -1 )	// wait Time 100ms
                {
                    if( evValue.events & EPOLLIN )
                    {
                        if( evValue.events & EPOLLRDHUP )
                        {
                            Destroy();
                            ServiceStop();
                            OnClosed();
                        }
                        else
                        {
                            if( m_pObserverReceiver ) m_pObserverReceiver->OnReceived(this);
                            else OnReceive();
                        }
                    }
                    else if( evValue.events == 0 )
                    {
                        OnTimeOut();
                    }

                    evValue.events = 0;
                }
            }
        }
    }
}


}
}
