#include "CProxyAuto_CollisionAlarm.h"

namespace AUTONOMOUS
{
namespace Interface
{
namespace Autonomy
{

CProxyAuto_CollisionAlarm::CProxyAuto_CollisionAlarm()
{
    AUTONOMOUS::COMMLIB::CFW::GetInstance().RegisterSub(MSG_CODE_AUTONOMY_AUTO_COLLISIONALARM, &CProxyAuto_CollisionAlarm::_OnAuto_CollisionAlarm, this);
}

CProxyAuto_CollisionAlarm::~CProxyAuto_CollisionAlarm()
{

}

bool CProxyAuto_CollisionAlarm::CreateLogProxyAuto_CollisionAlarm(char *logName)
{
    char fname[1024] = "";
    sprintf(fname, "./%s.Auto_CollisionAlarm", logName);

    return m_logProxyAuto_CollisionAlarm.Create(fname);
}

void CProxyAuto_CollisionAlarm::CloseLogProxyAuto_CollisionAlarm()
{
    m_logProxyAuto_CollisionAlarm.Destroy();
}

void CProxyAuto_CollisionAlarm::_OnAuto_CollisionAlarm(AUTONOMOUS::Data::Autonomy::StAuto_CollisionAlarmComm& data)
{
    OnAuto_CollisionAlarm(data);
    if( m_logProxyAuto_CollisionAlarm.IsRun() )
    {
        m_vBuffProxyAuto_CollisionAlarm.clear();
        data.getFrameData(m_vBuffProxyAuto_CollisionAlarm);
        m_logProxyAuto_CollisionAlarm.WriteData(m_vBuffProxyAuto_CollisionAlarm.data(), m_vBuffProxyAuto_CollisionAlarm.size());
    }
}

}
}
}
