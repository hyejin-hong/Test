#include "CStubAuto_DriveModeRequest.h"

namespace AUTONOMOUS
{
namespace Interface
{
namespace Common
{

CStubAuto_DriveModeRequest::CStubAuto_DriveModeRequest()
{
    m_snStubAuto_DriveModeRequest = 0;
}

CStubAuto_DriveModeRequest::~CStubAuto_DriveModeRequest()
{ 

}

bool CStubAuto_DriveModeRequest::CreateLogStubAuto_DriveModeRequest(char *logName)
{
    char fname[1024] = "";
    sprintf(fname, "./%s.Auto_DriveModeRequest", logName);

    return m_logStubAuto_DriveModeRequest.Create(fname);
}

void CStubAuto_DriveModeRequest::CloseLogStubAuto_DriveModeRequest()
{
    m_logStubAuto_DriveModeRequest.Destroy();
}


}
}
}
