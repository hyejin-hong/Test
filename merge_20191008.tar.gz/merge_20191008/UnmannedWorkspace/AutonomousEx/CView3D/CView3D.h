#ifndef CVIEW3D_H
#define CVIEW3D_H

#include <QGLWidget>
#include <QtOpenGL>

#include "Core/DevLib/Include/Core/CMutex/CMutex.h"

typedef struct _Model
{
    _Model()
        : x(0.f), y(0.f), z(0.f), roll(0.f), pitch(0.f), yaw(0.f)
    {    }

    float x, y, z;          // ?? cm? m?
    float roll, pitch, yaw; // angle : degree

    QVector<QVector3D>  points;
    QVector<QVector3D>  colors;
} StModel;

class CView3D : public QGLWidget
{
    Q_OBJECT
public:
    explicit CView3D(const QWidget *parent = nullptr, char* titleName = "3D View");

signals:
    void RotationX(float angle);
    void RotationY(float angle);
    void RotationZ(float angle);

    void AddModel(StModel points);
    void Redraw();

protected:
    virtual void initializeGL();
    virtual void paintGL();
    virtual void resizeGL(int width, int height);

    // Rotate
    float m_xRot;
    float m_yRot;
    float m_zRot;

    virtual void mousePressEvent(QMouseEvent *event);
    virtual void mouseMoveEvent(QMouseEvent *event);
    virtual void wheelEvent(QWheelEvent *event);

    QPoint  lastPos;
    QRect   m_pos;

    QVector<StModel>    m_models;
    QVector<StModel>    m_modelsMem;
    float   m_scale = 0.0005f;

public slots:
    void OnRotationX(float angle);
    void OnRotationY(float angle);
    void OnRotationZ(float angle);
    void OnAddModel(StModel points);
    void OnRedraw();

};

#endif // CVIEW3D_H
