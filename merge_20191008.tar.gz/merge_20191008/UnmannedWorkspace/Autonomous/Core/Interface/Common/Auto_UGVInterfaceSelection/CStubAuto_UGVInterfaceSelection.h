#ifndef CSTUBAUTO_UGVINTERFACESELECTION_H
#define CSTUBAUTO_UGVINTERFACESELECTION_H

#include <CFW.h>
#include <Core/DevLib/Include/IO/CLogWriter/CLogWriter.h>

// ICD Data
#include "../../../Data/Common/Auto_UGVInterfaceSelection.h"

namespace AUTONOMOUS
{
namespace Interface
{
namespace Common
{

class CStubAuto_UGVInterfaceSelection
{
public :
    CStubAuto_UGVInterfaceSelection();
    virtual ~CStubAuto_UGVInterfaceSelection();

    inline void WriteAuto_UGVInterfaceSelection(AUTONOMOUS::Data::Common::StAuto_UGVInterfaceSelectionComm& data)
    {
        data.message_type   = MSG_TYPE_COMMON;
        data.message_ID     = MSG_CODE_COMMON_AUTO_UGVINTERFACESELECTION;
        data.QoS            = MSG_QOS_COMMON_AUTO_UGVINTERFACESELECTION;
        data.SN             = m_snStubAuto_UGVInterfaceSelection++;

        AUTONOMOUS::COMMLIB::CFW::GetInstance().Send(data);

        if( m_logStubAuto_UGVInterfaceSelection.IsRun() )
        {
            m_vBuffStubAuto_UGVInterfaceSelection.clear();
            data.getFrameData(m_vBuffStubAuto_UGVInterfaceSelection);
            m_logStubAuto_UGVInterfaceSelection.WriteData(m_vBuffStubAuto_UGVInterfaceSelection.data(), m_vBuffStubAuto_UGVInterfaceSelection.size());
        }
    }

    // Log
    bool CreateLogStubAuto_UGVInterfaceSelection(char* logName);
    void CloseLogStubAuto_UGVInterfaceSelection();

private:
    std::vector<uint8_t>   m_vBuffStubAuto_UGVInterfaceSelection;
    uint8_t                m_snStubAuto_UGVInterfaceSelection;
protected:
    DevLib::IO::CLogWriter m_logStubAuto_UGVInterfaceSelection;
};


}
}
}

#endif /* CSTUBAUTO_UGVINTERFACESELECTION_H */
