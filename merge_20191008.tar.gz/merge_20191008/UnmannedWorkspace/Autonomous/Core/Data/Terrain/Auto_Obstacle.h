#ifndef AUTO_OBSTACLE_H
#define AUTO_OBSTACLE_H

#include <CFW.h>
#include "../Common/Common.h"

namespace AUTONOMOUS
{
namespace Data
{
namespace Terrain
{

typedef struct _StPosition  // 3Byte 구조체로 변경해야함
{
    uint16_t X;
    uint16_t Y;
} StPosition;

typedef struct _StObstacle
{
    StPosition  Position;
    uint16_t    Distance;
} StObstacle;

typedef struct _StAuto_Obstacle
{
    flt64_t     SyncTime;       // 동기화 시간
    uint8_t     ObstacleNo;     // 표현하는 장애물의 개수

    StObstacle  Obstacle[40];   // 장애물 탐지 결과

} StAuto_Obstacle;

typedef struct _StAuto_ObstacleComm : public AUTONOMOUS::COMMLIB::Header, public StAuto_Obstacle
{
    virtual void setFrameData(uint8_t* buff)
    {
        buff = deserializeData(buff, SyncTime);
        buff = deserializeData(buff, ObstacleNo);

        std::for_each(Obstacle, Obstacle + ObstacleNo, [&](StObstacle& d)
        {
            buff = deserializeData(buff, d.Position.X);
            buff = deserializeData(buff, d.Position.Y);
            buff = deserializeData(buff, d.Distance);
        });
    }

    virtual void getFrameData(std::vector<uint8_t>& buff)
    {
        serializeData(buff, SyncTime);
        serializeData(buff, ObstacleNo);

        std::for_each(Obstacle, Obstacle + ObstacleNo, [&](StObstacle d)
        {
            serializeData(buff, d.Position.X);
            serializeData(buff, d.Position.Y);
            serializeData(buff, d.Distance);
        });
    }

} StAuto_ObstacleComm;

}
}
}


#endif // AUTO_OBSTACLE_H
