#ifndef CSTUBSEND_GLOBALPATH_H
#define CSTUBSEND_GLOBALPATH_H

#include <CFW.h>
#include <Core/DevLib/Include/IO/CLogWriter/CLogWriter.h>

// ICD Data
#include "../../../Data/Autonomy/Send_GlobalPath.h"

namespace AUTONOMOUS
{
namespace Interface
{
namespace Autonomy
{

class CStubSend_GlobalPath
{
public :
    CStubSend_GlobalPath();
    virtual ~CStubSend_GlobalPath();

    inline void WriteSend_GlobalPath(AUTONOMOUS::Data::Autonomy::StSend_GlobalPathComm& data)
    {
        data.message_type   = MSG_TYPE_AUTONOMY;
        data.message_ID     = MSG_CODE_AUTONOMY_SEND_GLOBALPATH;
        data.QoS            = MSG_QOS_AUTONOMY_SEND_GLOBALPATH;
        data.SN             = m_snStubSend_GlobalPath++;

        AUTONOMOUS::COMMLIB::CFW::GetInstance().Send(data);

        if( m_logStubSend_GlobalPath.IsRun() )
        {
            m_vBuffStubSend_GlobalPath.clear();
            data.getFrameData(m_vBuffStubSend_GlobalPath);
            m_logStubSend_GlobalPath.WriteData(m_vBuffStubSend_GlobalPath.data(), m_vBuffStubSend_GlobalPath.size());
        }
    }

    // Log
    bool CreateLogStubSend_GlobalPath(char* logName);
    void CloseLogStubSend_GlobalPath();

private:
    std::vector<uint8_t>   m_vBuffStubSend_GlobalPath;
    uint8_t                m_snStubSend_GlobalPath;
protected:
    DevLib::IO::CLogWriter m_logStubSend_GlobalPath;
};


}
}
}

#endif /* CSTUBSEND_GLOBALPATH_H */
