#ifndef CPROXYEMAPDATA_PERCEPTIONRESULT_H
#define CPROXYEMAPDATA_PERCEPTIONRESULT_H

#include <Core/DevLib/Include/IO/CLogWriter/CLogWriter.h>

// ICD Data
#include "../../../Data/Terrain/MapData_PerceptionResult.h"

namespace AUTONOMOUS
{
namespace Interface
{
namespace Terrain
{

class CProxyMapData_PerceptionResult
{
public :
    CProxyMapData_PerceptionResult();
    virtual ~CProxyMapData_PerceptionResult();

    virtual void OnMapData_PerceptionResult(AUTONOMOUS::Data::Terrain::StMapData_PerceptionResultComm& data) = 0;

    // Log
    bool CreateLogProxyMapData_PerceptionResult(char* logName);
    void CloseLogProxyMapData_PerceptionResult();

private:
    std::vector<uint8_t>   m_vBuffProxyMapData_PerceptionResult;
protected:
    DevLib::IO::CLogWriter m_logProxyMapData_PerceptionResult;

    void _OnMapData_PerceptionResult(AUTONOMOUS::Data::Terrain::StMapData_PerceptionResultComm& data);
};


}
}
}

#endif /* CPROXYEMAPDATA_PERCEPTIONRESULT_H */
