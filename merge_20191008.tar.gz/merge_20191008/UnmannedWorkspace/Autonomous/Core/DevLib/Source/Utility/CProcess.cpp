/*
 * CProcess.cpp
 *
 *  Created on: 2019. 4. 12.
 *      Author: park
 */
#include "../../Include/Utility/CProcess.h"
#include <stdio.h>

namespace DevLib
{
namespace Utility
{

CProcess::CProcess()
{
}

void CProcess::Create()
{
	OnPreCreate();
}

void CProcess::Start()
{
	ServiceStart();
    StartReportTimer(1000);
	//ServiceRun();
}

void CProcess::Shutdown()
{
    ServiceStop();
    m_timerReportStatus.TimerStop();
    WaitForEndThread();

    OnShutdown();
}

void CProcess::Run()
{
    while( IsRun() )
    {
        OnRunning();
    }
}

void CProcess::ServiceRun()
{
    while( IsRun() )
	{
		OnCommand(getchar());
	}
}

}
}

void DevLib::Utility::CProcess::StartReportTimer(int ms)
{
	m_timerReportStatus.TimerStart(ms, _OnTimerReportStatus, this);
}
