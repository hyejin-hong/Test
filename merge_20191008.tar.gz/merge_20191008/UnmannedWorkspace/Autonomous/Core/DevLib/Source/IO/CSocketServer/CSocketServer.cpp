#include "../../../Include/IO/CSocketServer/CSocketServer.h"

#include <stdio.h>
#include <arpa/inet.h>

namespace DevLib
{
namespace IO
{

CObserverServer::CObserverServer()
{

}

CObserverServer::~CObserverServer()
{

}

CSocketServer::CSocketServer(CObserverServer *pObserver)
    : m_pObserverServer(pObserver)
{
    m_lockList.Create();
}

void CSocketServer::Create(int port)
{
    bool bRet = DevLib::IO::CSocketReceiver::Create(SOCK_STREAM);
    bRet = DevLib::IO::CSocketReceiver::Bind(port);
    bRet = DevLib::IO::CSocketReceiver::Listen(5);
    bRet = DevLib::IO::CSocketReceiver::ServiceStart();
    SetOptionReuse(true);
}

int CSocketServer::SendTCP(void *pData, unsigned int size)
{
    int ret = 0;

    m_lockList.Lock();

    std::list<DevLib::IO::CSocketReceiver>::iterator itr = m_listClient.begin();

    while( itr != m_listClient.end() )
    {
        ret = itr->Send(pData, size);
        itr++;
    }

    m_lockList.UnLock();

    return ret;
}

void CSocketServer::OnConnected(char *ip, int port)
{
    printf("Connected %s : %d\n", ip, port);
}

void CSocketServer::OnDisconnected(char *ip, int port)
{
    printf("Disconnected %s : %d\n", ip, port);
}

std::list<CSocketReceiver> CSocketServer::GetClientList()
{
    return m_listClient;
}

int CSocketServer::AddClient(int fdClient)
{
    m_lockList.Lock();

    DevLib::IO::CSocketReceiver receiverSock = DevLib::IO::CSocketReceiver(fdClient);
    m_listClient.push_back(receiverSock);

    std::list<DevLib::IO::CSocketReceiver>::iterator client = m_listClient.end();
    client--;

    client->SetOptionReuse(true);
    client->SetOptionNagle(true);
    client->SetOptionLinger(true);
    client->SetSocketAddrRemote(m_sockAddrRemote);
    client->SetObserver(this);

    client->ServiceStart();

    OnConnected(inet_ntoa(client->GetSocketAddrRemote().sin_addr), htons(client->GetSocketAddrRemote().sin_port));

    m_lockList.UnLock();
    return m_listClient.size();
}

int CSocketServer::RemoveClient()
{
    m_lockList.Lock();

    std::list<DevLib::IO::CSocketReceiver>::iterator itr = m_listClient.begin();

    for( ; itr != m_listClient.end(); itr++)
    {
        if( itr->IsCreated() == false )
        {
            OnDisconnected(inet_ntoa(itr->GetSocketAddrRemote().sin_addr), htons(itr->GetSocketAddrRemote().sin_port));
            m_listClient.erase(itr);
            break;
        }
    }

    m_lockList.UnLock();
    return m_listClient.size();
}

void CSocketServer::OnReceive()
{
    AddClient(Accept());
}

void CSocketServer::OnTimeOut()
{
    RemoveClient();
}

void CSocketServer::OnReceived(DevLib::IO::CSocket* pClient)
{
    if( m_pObserverServer ) m_pObserverServer->OnDataClient(pClient);
}


}
}
