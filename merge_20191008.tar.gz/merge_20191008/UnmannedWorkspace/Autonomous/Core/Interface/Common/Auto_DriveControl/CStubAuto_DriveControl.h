#ifndef CSTUBAUTO_DRIVECONTROL_H
#define CSTUBAUTO_DRIVECONTROL_H

#include <CFW.h>
#include <Core/DevLib/Include/IO/CLogWriter/CLogWriter.h>

// ICD Data
#include "../../../Data/Common/Auto_DriveControl.h"

namespace AUTONOMOUS
{
namespace Interface
{
namespace Common
{

class CStubAuto_DriveControl
{
public :
    CStubAuto_DriveControl();
    virtual ~CStubAuto_DriveControl();

    inline void WriteAuto_DriveControl(AUTONOMOUS::Data::Common::StAuto_DriveControlComm& data)
    {
        data.message_type   = MSG_TYPE_COMMON;
        data.message_ID     = MSG_CODE_COMMON_AUTO_DRIVECONTROL;
        data.QoS            = MSG_QOS_COMMON_AUTO_DRIVECONTROL;
        data.SN             = m_snStubAuto_DriveControl++;

        AUTONOMOUS::COMMLIB::CFW::GetInstance().Send(data);

        if( m_logStubAuto_DriveControl.IsRun() )
        {
            m_vBuffStubAuto_DriveControl.clear();
            data.getFrameData(m_vBuffStubAuto_DriveControl);
            m_logStubAuto_DriveControl.WriteData(m_vBuffStubAuto_DriveControl.data(), m_vBuffStubAuto_DriveControl.size());
        }
    }

    // Log
    bool CreateLogStubAuto_DriveControl(char* logName);
    void CloseLogStubAuto_DriveControl();

private:
    std::vector<uint8_t>   m_vBuffStubAuto_DriveControl;
    uint8_t                m_snStubAuto_DriveControl;
protected:
    DevLib::IO::CLogWriter m_logStubAuto_DriveControl;
};


}
}
}

#endif /* CSTUBAUTO_DRIVECONTROL_H */
