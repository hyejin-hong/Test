#include "CVelodyneObject.h"
#include "../../../Core/Data/Sensor/SensorData_LIDAR_Rtheta.h"

#include <stdio.h>
#include <string.h>
#include <iostream>
#include <stdlib.h>
#include <math.h>

namespace AUTONOMOUS
{
namespace Device
{
namespace Velodyne
{

CVelodyneObject::CVelodyneObject(CObserverVelodyneObject* pObserver)
 : m_pObserverVelodyneObject(pObserver)
{
}

CVelodyneObject::~CVelodyneObject()
{
}

bool CVelodyneObject::Create(char* bindIP, char* connectIP, int port)
{
    bool bRet = false;

    m_connectIP = connectIP;

    if( DevLib::IO::CSocketReceiver::Create(DevLib::IO::CSocket::SOCK_UDP) )
    {
        if( Bind(port, bindIP) )
        {
            m_socketStatus.Create(SOCK_STREAM);

            if(m_socketStatus.Connect(80, connectIP))
            {
                TimerStart(1000);
            }

            ServiceStart();

            bRet = true;
        }
    }

    return bRet;
}

//bool CVelodyneObject::CreateSerial(char* dev_name, speed_t baud_rate)
//{
//    bool bRet = false;

//    if( DevLib::IO::CSerial::OpenPort(dev_name) )
//    {
//        if( DevLib::IO::CSerial::SetConfigurePort(baud_rate) )
//        {
//            //m_thread.ServiceStart(_OnThread, this);

//            bRet = true;
//        }
//    }

//    return bRet;
//}

void CVelodyneObject::OnReceive()
{
    AUTONOMOUS::Device::Velodyne::StVelodynePacket data;

    char ip[32] = "";
    int port;

    if( RecvFrom(&data, sizeof(data), ip, &port, 0) == sizeof(data) )
    {
        if( m_pObserverVelodyneObject )
        {
            m_pObserverVelodyneObject->OnVelodynePack(&data);
        }
    }
}

void CVelodyneObject::OnThread()
{
    AUTONOMOUS::Device::Velodyne::StEMount data;

    while(m_thread.IsRun())
    {
//        if( DevLib::IO::CSerial::Recv(&data, sizeof(data)) == sizeof(data) )
//        {
//            if( m_pObserverVelodyneObject )
//            {
//                m_pObserverVelodyneObject->OnEMount(&data);
//            }
//        }
    }
}

void CVelodyneObject::OnTimer(void* p)
{
    AUTONOMOUS::Device::Velodyne::StVelodyneStatus data;

    m_vInfo = GetInfo();

    data.RPM	= m_vInfo.RPM;
    data.lock	= m_vInfo.lock;

    m_vTemp = GetTemp();

    data.tempBottom	= m_vTemp.tempBottom;
    data.tempTop	= m_vTemp.tempTop;

    if( m_pObserverVelodyneObject )
    {
        m_pObserverVelodyneObject->OnVelodyneStatus(&data);
    }
}

AUTONOMOUS::Device::Velodyne::StVelodyneInfo CVelodyneObject::GetInfo()
{
    char    infoSendData[]		= "GET /cgi/status.json HTTP/1.1\r\nHost: 192.168.1.201\r\nUser-Agent: Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:66.0) Gecko/20100101 Firefox/66.0\r\nAccept: */*\r\nAccept-Language: ko-KR,ko;q=0.8,en-US;q=0.5,en;q=0.3\r\nAccept-Encoding: gzip, deflate\r\nReferer: http://192.168.1.201/\r\nConnection: keep-alive\r\n\r\n";
    char    infoRecvData[1024]	= "";
    char    infoRPMParseData[]	= "\"rpm\":";
    char    infoLockParseData[]	= "\"lock\":\"";

    char    infoRPMData[4];
    char    infoLockData[50];

    AUTONOMOUS::Device::Velodyne::StVelodyneInfo infoData;

    int infoRPMPos;
    int infoLockPos;

    int nSend = m_socketStatus.Send(infoSendData, strlen(infoSendData));
    m_socketStatus.Recv(infoRecvData, sizeof(infoRecvData));

    if( nSend < 0)
    {
        m_socketStatus.Destroy();
        m_socketStatus.Create(SOCK_STREAM);
        m_socketStatus.Connect(80, m_connectIP);
    }

    std::string cStr = infoRecvData;

    infoRPMPos = cStr.find(infoRPMParseData) + strlen(infoRPMParseData);

    sscanf(&cStr[infoRPMPos], "%[^,]", infoRPMData);

    infoData.RPM = atoi(infoRPMData);

    cStr = &cStr[infoRPMPos];

    infoLockPos = cStr.find(infoLockParseData) + strlen(infoLockParseData);

    sscanf(&cStr[infoLockPos], "%[^\"]", infoLockData);

    infoData.lock = infoLockData;

    return infoData;
}

AUTONOMOUS::Device::Velodyne::StVelodyneTemp CVelodyneObject::GetTemp()
{
    char    tempSendData[]		= "GET /cgi/diag.json HTTP/1.1\r\nHost: 192.168.1.201\r\nUser-Agent: Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:66.0) Gecko/20100101 Firefox/66.0\r\nAccept: text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8\r\nAccept-Language: ko-KR,ko;q=0.8,en-US;q=0.5,en;q=0.3\r\nAccept-Encoding: gzip, deflate\r\nConnection: keep-alive\r\nUpgrade-Insecure-Requests: 1\r\n\r\n";
    char    tempRecvData[1024]	= "";
    char    tempParseData[] 		= "\"lm20_temp\":";

    char    tempBottomData[4];
    char    tempTopData[4];

    AUTONOMOUS::Device::Velodyne::StVelodyneTemp tempData;

    int tempBottomPos;
    int tempTopPos;

    int send = m_socketStatus.Send(tempSendData, strlen(tempSendData));

    m_socketStatus.Recv(tempRecvData, sizeof(tempRecvData));

    if( send < 0 )
    {
        m_socketStatus.Destroy();
        m_socketStatus.Create(SOCK_STREAM);
        m_socketStatus.Connect(80, m_connectIP);
    }

    std::string cStr = tempRecvData;

    tempBottomPos = cStr.find(tempParseData) + strlen(tempParseData);

    sscanf(&cStr[tempBottomPos], "%[^,]", tempBottomData);

    tempData.tempBottom = atoi(tempBottomData);

    cStr = &cStr[tempBottomPos];

    tempTopPos = cStr.find(tempParseData) + strlen(tempParseData);

    sscanf(&cStr[tempTopPos], "%[^,]", tempTopData);

    tempData.tempTop = atoi(tempTopData);

    return tempData;
}

//float CVelodyneObject::ConvertTemp(char* data)
//{
//	float temp = atof(data);

//	temp = (5.0 * temp) / 4096;
//	temp = -1481.96 + sqrt(2.1962E6 + ((1.8639 - temp) / 3.88E-6));

//	return temp;
//}

}
}
}
