#ifndef CSOCKETSERVER_H
#define CSOCKETSERVER_H

#include "../../Core/CMutex/CMutex.h"
#include "../CSocketReceiver/CSocketReceiver.h"
#include <list>

namespace DevLib
{
namespace IO
{

class CObserverServer
{
public :
    CObserverServer();
    virtual ~CObserverServer();

    virtual void OnConneted(char* ip, int port) = 0;
    virtual void OnDisconneted(char* ip, int port) = 0;
    virtual void OnDataClient(DevLib::IO::CSocket* pClient) = 0;
};

class CSocketServer
        : public DevLib::IO::CSocketReceiver
        , public DevLib::IO::CObserverReceiver
{
public:
    CSocketServer(CObserverServer* pObserver = nullptr);

    void Create(int port);

    int SendTCP(void* pData, unsigned int size);

    virtual void OnConnected(char* ip, int port);
    virtual void OnDisconnected(char* ip, int port);

    std::list<DevLib::IO::CSocketReceiver> GetClientList();

private:
    int AddClient(int fdClient);
    int RemoveClient();

    virtual void OnReceive();
    virtual void OnTimeOut();

    virtual void OnReceived(DevLib::IO::CSocket* pClient);

    DevLib::CMutex                          m_lockList;
    std::list<DevLib::IO::CSocketReceiver>  m_listClient;

    CObserverServer*    m_pObserverServer;
};

}
}
#endif // CSOCKETSERVER_H
