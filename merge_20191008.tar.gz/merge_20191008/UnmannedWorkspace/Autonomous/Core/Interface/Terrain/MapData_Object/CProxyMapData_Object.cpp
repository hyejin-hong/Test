#include "CProxyMapData_Object.h"

namespace AUTONOMOUS
{
namespace Interface
{
namespace Terrain
{

CProxyMapData_Object::CProxyMapData_Object()
{
    AUTONOMOUS::COMMLIB::CFW::GetInstance().RegisterSub(MSG_CODE_TERRAIN_MAPDATA_OBJECT, &CProxyMapData_Object::_OnMapData_Object, this);
}

CProxyMapData_Object::~CProxyMapData_Object()
{

}

bool CProxyMapData_Object::CreateLogProxyMapData_Object(char *logName)
{
    char fname[1024] = "";
    sprintf(fname, "./%s.MapData_Object", logName);

    return m_logProxyMapData_Object.Create(fname);
}

void CProxyMapData_Object::CloseLogProxyMapData_Object()
{
    m_logProxyMapData_Object.Destroy();
}

void CProxyMapData_Object::_OnMapData_Object(AUTONOMOUS::Data::Terrain::StMapData_ObjectComm& data)
{
    OnMapData_Object(data);
    if( m_logProxyMapData_Object.IsRun() )
    {
        m_vBuffProxyMapData_Object.clear();
        data.getFrameData(m_vBuffProxyMapData_Object);
        m_logProxyMapData_Object.WriteData(m_vBuffProxyMapData_Object.data(), m_vBuffProxyMapData_Object.size());
    }
}

}
}
}
