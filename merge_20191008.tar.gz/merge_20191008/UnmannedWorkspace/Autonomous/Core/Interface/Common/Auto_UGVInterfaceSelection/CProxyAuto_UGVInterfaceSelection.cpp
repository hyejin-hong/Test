#include "CProxyAuto_UGVInterfaceSelection.h"

namespace AUTONOMOUS
{
namespace Interface
{
namespace Common
{

CProxyAuto_UGVInterfaceSelection::CProxyAuto_UGVInterfaceSelection()
{
    AUTONOMOUS::COMMLIB::CFW::GetInstance().RegisterSub(MSG_CODE_COMMON_AUTO_UGVINTERFACESELECTION, &CProxyAuto_UGVInterfaceSelection::_OnAuto_UGVInterfaceSelection, this);
}

CProxyAuto_UGVInterfaceSelection::~CProxyAuto_UGVInterfaceSelection()
{

}

bool CProxyAuto_UGVInterfaceSelection::CreateLogProxyAuto_UGVInterfaceSelection(char *logName)
{
    char fname[1024] = "";
    sprintf(fname, "./%s.Auto_UGVInterfaceSelection", logName);

    return m_logProxyAuto_UGVInterfaceSelection.Create(fname);
}

void CProxyAuto_UGVInterfaceSelection::CloseLogProxyAuto_UGVInterfaceSelection()
{
    m_logProxyAuto_UGVInterfaceSelection.Destroy();
}

void CProxyAuto_UGVInterfaceSelection::_OnAuto_UGVInterfaceSelection(AUTONOMOUS::Data::Common::StAuto_UGVInterfaceSelectionComm& data)
{
    OnAuto_UGVInterfaceSelection(data);
    if( m_logProxyAuto_UGVInterfaceSelection.IsRun() )
    {
        m_vBuffProxyAuto_UGVInterfaceSelection.clear();
        data.getFrameData(m_vBuffProxyAuto_UGVInterfaceSelection);
        m_logProxyAuto_UGVInterfaceSelection.WriteData(m_vBuffProxyAuto_UGVInterfaceSelection.data(), m_vBuffProxyAuto_UGVInterfaceSelection.size());
    }
}

}
}
}
