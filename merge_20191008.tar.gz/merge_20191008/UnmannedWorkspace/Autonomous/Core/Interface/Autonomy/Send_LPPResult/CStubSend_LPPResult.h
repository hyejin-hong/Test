#ifndef CSTUBSEND_LPPRESULT_H
#define CSTUBSEND_LPPRESULT_H

#include <CFW.h>
#include <Core/DevLib/Include/IO/CLogWriter/CLogWriter.h>

// ICD Data
#include "../../../Data/Autonomy/Send_LPPResult.h"

namespace AUTONOMOUS
{
namespace Interface
{
namespace Autonomy
{

class CStubSend_LPPResult
{
public :
    CStubSend_LPPResult();
    virtual ~CStubSend_LPPResult();

    inline void WriteSend_LPPResult(AUTONOMOUS::Data::Autonomy::StSend_LPPResultComm& data)
    {
        data.message_type   = MSG_TYPE_AUTONOMY;
        data.message_ID     = MSG_CODE_AUTONOMY_SEND_LPPRESULT;
        data.QoS            = MSG_QOS_AUTONOMY_SEND_LPPRESULT;
        data.SN             = m_snStubSend_LPPResult++;

        AUTONOMOUS::COMMLIB::CFW::GetInstance().Send(data);

        if( m_logStubSend_LPPResult.IsRun() )
        {
            m_vBuffStubSend_LPPResult.clear();
            data.getFrameData(m_vBuffStubSend_LPPResult);
            m_logStubSend_LPPResult.WriteData(m_vBuffStubSend_LPPResult.data(), m_vBuffStubSend_LPPResult.size());
        }
    }

    // Log
    bool CreateLogStubSend_LPPResult(char* logName);
    void CloseLogStubSend_LPPResult();

private:
    std::vector<uint8_t>   m_vBuffStubSend_LPPResult;
    uint8_t                m_snStubSend_LPPResult;
protected:
    DevLib::IO::CLogWriter m_logStubSend_LPPResult;
};


}
}
}

#endif /* CSTUBSEND_LPPRESULT_H */
