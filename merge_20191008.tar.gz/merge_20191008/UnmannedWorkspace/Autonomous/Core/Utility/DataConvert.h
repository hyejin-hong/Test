#ifndef DATACONVERT_H
#define DATACONVERT_H

#include <vector>
#include <math.h>

#include "../Device/Velodyne/CommonVelodyne.h"
#include "../Device/MRS1000/CommonMRS1000.h"
#include "../Data/Sensor/SensorData_LIDAR_Rtheta.h"

namespace AUTONOMOUS
{
namespace Utility
{

inline double DegreeToRadian(double deg) { return deg*0.01745329252; }
inline double RadianToDegree(double deg) { return deg*57.2957795131; }
inline double GetCosTable(double deg) { return cos(DegreeToRadian(deg)); } // @suppress("Function cannot be resolved")
inline double GetSinTable(double deg) { return sin(DegreeToRadian(deg)); } // @suppress("Function cannot be resolved")


// Velodyne Raw To RTheta
void ConvertVelodyne16ToRTheta(
        AUTONOMOUS::Data::Sensor::StSensorData_LIDAR_Rtheta& dest,
        std::vector<AUTONOMOUS::Device::Velodyne::StVelodynePacket>& src);

void ConvertVelodyne32ToRTheta(
        AUTONOMOUS::Data::Sensor::StSensorData_LIDAR_Rtheta& dest,
        const std::vector<AUTONOMOUS::Device::Velodyne::StVelodynePacket>& src,
        const AUTONOMOUS::Device::Velodyne::StCorrectionParams& correction);

void ConvertMRS1000ToRTheta(
        AUTONOMOUS::Data::Sensor::StSensorData_LIDAR_Rtheta& dest,
        std::vector<AUTONOMOUS::Device::MRS1000::StMRS1000Packet>& src);

//// Velodyne Raw To XYZ
//void ConvertVelodyne16ToXYZ(
//        Nerv::Data::Advenced_Data_Sensor::struct_SensorData_LIDAR_XYZ& dest,
//        const std::vector<StVelodynePacket>& src);
//
//void ConvertVelodyne32ToXYZ(
//        Nerv::Data::Advenced_Data_Sensor::struct_SensorData_LIDAR_XYZ& dest,
//        const std::vector<StVelodynePacket>& src,
//        const StCorrectionParams& correction);

//
//// RTheta To XYZ
//void ConvertVelodyne16RThetaToXYZ(
//        Nerv::Data::Advenced_Data_Sensor::struct_SensorData_LIDAR_RTheta& src,
//        Nerv::Data::Advenced_Data_Sensor::struct_SensorData_LIDAR_XYZ& dest);
//
//void ConvertVelodyne32RThetaToXYZ(
//        Nerv::Data::Advenced_Data_Sensor::struct_SensorData_LIDAR_RTheta& src,
//        Nerv::Data::Advenced_Data_Sensor::struct_SensorData_LIDAR_XYZ& dest,
//        const StCorrectionParams& correction);


//// RTheta To XYZ
//void ConvertRThetaToXYZ(
//        Nerv::Data::Advenced_Data_Sensor::struct_SensorData_LIDAR_RTheta& src,
//        Nerv::Data::Advenced_Data_Sensor::struct_SensorData_LIDAR_XYZ& dest );


}
}

#endif /* DATACONVERT_H */
