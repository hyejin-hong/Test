#ifndef AUTO_DRIVECONTROL_AUTONOMY_H
#define AUTO_DRIVECONTROL_AUTONOMY_H

#include <CFW.h>
#include "../Common/Common.h"

namespace AUTONOMOUS
{
namespace Data
{
namespace Autonomy
{

typedef struct _StAuto_DriveControl
{
    flt64_t             SyncTime;       // 동기화 시간
    int8_t              SteeringWheel;  // Wheel 조향 : -100 ~ 100 %
    int8_t              Accelator;      // 가속 페달 : 0 ~ 100 %
    int8_t              Break;          // 감속 페달 : 0 ~ 100 %
    AUTONOMOUS::StGear  Gear;

} StAuto_DriveControl;


typedef struct _StAuto_DriveControlComm : public AUTONOMOUS::COMMLIB::Header, public StAuto_DriveControl
{
    virtual void setFrameData(uint8_t* buff)
    {
        buff = deserializeData(buff, SyncTime);
        buff = deserializeData(buff, SteeringWheel);
        buff = deserializeData(buff, Accelator);
        buff = deserializeData(buff, Break);
        buff = deserializeData(buff, Gear.Gear);
    }

    virtual void getFrameData(std::vector<uint8_t>& buff)
    {
        serializeData(buff, SyncTime);
        serializeData(buff, SteeringWheel);
        serializeData(buff, Accelator);
        serializeData(buff, Break);
        serializeData(buff, Gear.Gear);
    }

} StAuto_DriveControlComm;


}
}
}

#endif // AUTO_DRIVECONTROL_AUTONOMY_H
