#include "CStubSensorData_LIDAR_Rtheta2DLidar.h"

namespace AUTONOMOUS
{
namespace Interface
{
namespace Sensor
{

CStubSensorData_LIDAR_Rtheta2DLidar::CStubSensorData_LIDAR_Rtheta2DLidar()
{
    m_snStubSensorData_LIDAR_Rtheta2DLidar = 0;
}

CStubSensorData_LIDAR_Rtheta2DLidar::~CStubSensorData_LIDAR_Rtheta2DLidar()
{ 

}

bool CStubSensorData_LIDAR_Rtheta2DLidar::CreateLogStubSensorData_LIDAR_Rtheta2DLidar(char *logName)
{
    char fname[1024] = "";
    sprintf(fname, "./%s.SensorData_LIDAR_Rtheta2DLidar", logName);

    return m_logStubSensorData_LIDAR_Rtheta2DLidar.Create(fname);
}

void CStubSensorData_LIDAR_Rtheta2DLidar::CloseLogStubSensorData_LIDAR_Rtheta2DLidar()
{
    m_logStubSensorData_LIDAR_Rtheta2DLidar.Destroy();
}


}
}
}
