#ifndef CPROXYEAUTO_REMOTECONTROL_H
#define CPROXYEAUTO_REMOTECONTROL_H

#include <Core/DevLib/Include/IO/CLogWriter/CLogWriter.h>

// ICD Data
#include "../../../Data/Common/Auto_RemoteControl.h"

namespace AUTONOMOUS
{
namespace Interface
{
namespace Common
{

class CProxyAuto_RemoteControl
{
public :
    CProxyAuto_RemoteControl();
    virtual ~CProxyAuto_RemoteControl();

    virtual void OnAuto_RemoteControl(AUTONOMOUS::Data::Common::StAuto_RemoteControlComm& data) = 0;

    // Log
    bool CreateLogProxyAuto_RemoteControl(char* logName);
    void CloseLogProxyAuto_RemoteControl();

private:
    std::vector<uint8_t>   m_vBuffProxyAuto_RemoteControl;
protected:
    DevLib::IO::CLogWriter m_logProxyAuto_RemoteControl;

    void _OnAuto_RemoteControl(AUTONOMOUS::Data::Common::StAuto_RemoteControlComm& data);
};


}
}
}

#endif /* CPROXYEAUTO_REMOTECONTROL_H */
