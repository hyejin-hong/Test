#include "../../../Include/Core/CMutex/CMutex.h"
#include <pthread.h>

namespace DevLib
{

typedef struct {
	pthread_mutex_t mutex;
} MUTEX;



CMutex::CMutex()
: m_bCreated(false)
{
	m_hMutex = new MUTEX;
}

CMutex::~CMutex()
{
	Destroy();

	delete (MUTEX*)m_hMutex;
}

bool CMutex::Create()
{
	bool bRet = false;

	MUTEX * pMutex = (MUTEX *)m_hMutex;

	if( pthread_mutex_init(&pMutex->mutex, 0) == 0)
	{
		bRet = true;
		m_bCreated = true;
	}

	return bRet;
}

void CMutex::Destroy()
{
	MUTEX * pMutex = (MUTEX *)m_hMutex;

	pthread_mutex_destroy(&pMutex->mutex);

	m_bCreated = false;
}

bool CMutex::IsCreated()
{
	return m_bCreated;
}

void CMutex::Lock()
{
    if(IsCreated())
    {
        MUTEX * pMutex = (MUTEX *)m_hMutex;

        pthread_mutex_lock(&pMutex->mutex);
    }
}

void CMutex::UnLock()
{
    if(IsCreated())
    {
        MUTEX * pMutex = (MUTEX *)m_hMutex;

        pthread_mutex_unlock(&pMutex->mutex);
    }
}

}
