#include "../../../Include/IO/CSocket/CSocket.h"

#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netinet/tcp.h>
#include <stdio.h>
#include <unistd.h>
#include <memory.h>

namespace DevLib
{
namespace IO
{

CSocket::CSocket(int sockFD)
: m_fdSocket(sockFD)
{

}

CSocket::~CSocket()
{
    //Destroy();
}

bool CSocket::Create(int sockType)
{
	bool bRet = false;

    m_fdSocket = socket(PF_INET, sockType, IPPROTO_IP);	// 생성 성공 시 파일 디스크립터 리턴, 실패 시 -1을 리턴

	if(m_fdSocket != -1)
	{
		bRet = true;
	}

	return bRet;
}

void CSocket::Destroy()
{
	close(m_fdSocket);
	m_fdSocket = -1;
}

bool CSocket::IsCreated()
{
    return ( m_fdSocket == -1 ) ?  false : true;
}

bool CSocket::Bind(int port, char* ip)
{
	bool bRet = false;

	struct sockaddr_in addr;
	memset(&addr, 0, sizeof(addr));

	addr.sin_family 		= AF_INET;
    addr.sin_port           = htons(port);
	addr.sin_addr.s_addr	= ip == 0 ? INADDR_ANY : inet_addr(ip);	// null -> INADDR_ANY

	if(bind(m_fdSocket, (struct sockaddr*)&addr, sizeof(addr)) != -1)
	{
		bRet = true;
	}

	return bRet;
}

bool CSocket::Listen(int nListen)	// 이미 연결된 소켓(connect()가 성공한 경우 또는 accept()가 리턴된 경우)에는 적용 못함
{
	bool bRet = false;

	if(listen(m_fdSocket, nListen) != -1)
	{
		bRet = true;
	}

	return bRet;
}

int CSocket::Accept()
{
	unsigned int m_addrSize;	
    m_addrSize = sizeof(struct sockaddr);

    int fd = accept(m_fdSocket, (struct sockaddr*)&m_sockAddrRemote, (socklen_t*)&m_addrSize);

    return fd;
}

bool CSocket::Connect(int port, char* ip)
{
	bool bRet = false;

	memset(&m_sockAddrRemote, 0, sizeof(m_sockAddrRemote));

	m_sockAddrRemote.sin_family 		= AF_INET;
	m_sockAddrRemote.sin_port 			= htons(port);
	m_sockAddrRemote.sin_addr.s_addr	= inet_addr(ip);

	if(connect(m_fdSocket, (struct sockaddr*)&m_sockAddrRemote, sizeof(m_sockAddrRemote)) != -1)
	{
		bRet = true;
	}

	return bRet;
}

int CSocket::Send(void* pData, int size, int flag)
{
    return send(m_fdSocket, pData, size, flag | MSG_NOSIGNAL);
}

int CSocket::Recv(void* pData, int size, int flag)
{
	return recv(m_fdSocket, pData, size, flag);
}

int CSocket::SendTo(void* pData, int size, char* dstIP, int dstPort, int flag)
{
	struct sockaddr_in addr;
	memset(&addr, 0, sizeof(addr));

	addr.sin_family 		= AF_INET;
	addr.sin_port 		= htons(dstPort);
	addr.sin_addr.s_addr	= inet_addr(dstIP);

	return sendto(m_fdSocket, pData, size, flag, (struct sockaddr*)&addr, sizeof(addr));
}

int CSocket::RecvFrom(void* pData, int size, char* srcIP, int* srcPort, int flag)
{
	struct sockaddr_in addr;
	unsigned int m_addrSize;

	memset(&addr, 0, sizeof(addr));

	m_addrSize = sizeof(addr);

	int nRecv =  recvfrom(m_fdSocket, pData, size, flag, (struct sockaddr*)&addr, &m_addrSize);

	*srcPort = htons(addr.sin_port);
	memcpy(srcIP, inet_ntoa(addr.sin_addr), strlen(inet_ntoa(addr.sin_addr)));

	return nRecv;
}

bool CSocket::JoinMuticastGroup(char* groupAddr, char* interfaceIP)
{
	bool bRet = false;

	struct ip_mreq group;
	group.imr_multiaddr.s_addr = inet_addr(groupAddr);
	group.imr_interface.s_addr = interfaceIP == 0 ? htonl(INADDR_ANY) : inet_addr(interfaceIP);
	if( setsockopt(m_fdSocket, IPPROTO_IP, IP_ADD_MEMBERSHIP, (char*)&group, sizeof(group)) == 0 )
	{
		bRet = true;
	}

	return bRet;
}

bool CSocket::LeaveMulticastGroup(char* groupAddr, char* interfaceIP)
{
	bool bRet = false;

	struct ip_mreq group;
	group.imr_multiaddr.s_addr = inet_addr(groupAddr);
	group.imr_interface.s_addr = interfaceIP == 0 ? htonl(INADDR_ANY) : inet_addr(interfaceIP);
	if( setsockopt(m_fdSocket, IPPROTO_IP, IP_DROP_MEMBERSHIP, (char*)&group, sizeof(group)) == 0 )
	{
		bRet = true;
	}

	return bRet;
}

void CSocket::SetOptionNagle( bool bUse )
{
	// Socket Option : Nagle ( IPPROTO_TCP 레벨 )
	// Nagle 알고리즘은 네트워크 과부하를 줄이기 위해 잦은 데이터 전송을 피하기 위한 방식
	// 데이터를 모와서 한번에 전송 하는 방식
	// 0 : Nagle Use, 1 : Nagle Nouse
	int option = 1;
	if( bUse ) option = 0;
	setsockopt(m_fdSocket, IPPROTO_TCP, TCP_NODELAY, (char*)&option, sizeof(option));
}


void CSocket::SetOptionReuse(bool bReuse)
{
	// Socket Option : Reuse Addr ( SOL_SOCKET 레벨 )
	// 서버가 정상종료가 되지 못한 상태에서 TIME_WAIT 상태로 진입하면 서버 재기동시 bind 에러가 발생한다.
	// SO_REUSEADDR = true , 시 TIME_WAIT 상태에서도 바로 사용가능하다.
	int reuse_addr = bReuse;
    setsockopt(m_fdSocket, SOL_SOCKET, SO_REUSEADDR, (char*)&reuse_addr, sizeof(reuse_addr));
}

void CSocket::SetOptionLinger(bool bLinger)
{
    struct linger solinger = { bLinger?1:0, 0 };
    setsockopt(m_fdSocket, SOL_SOCKET, SO_LINGER, &solinger, sizeof(struct linger));
}

bool CSocket::GetConnected(int connected_fd)
{
	// 상대방의 소켓과 연결상태인 경우 True 리턴

	bool bRet = false;

	socklen_t addr_len = sizeof(struct sockaddr_in);

	if(getpeername(connected_fd, (struct sockaddr *)&m_sockTemp, &addr_len) == 0)
	{
		bRet = true;
	}

	return bRet;
}

}
}
