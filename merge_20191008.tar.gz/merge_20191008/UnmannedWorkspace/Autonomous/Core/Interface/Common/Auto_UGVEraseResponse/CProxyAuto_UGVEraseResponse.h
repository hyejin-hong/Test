#ifndef CPROXYEAUTO_UGVERASERESPONSE_H
#define CPROXYEAUTO_UGVERASERESPONSE_H

#include <Core/DevLib/Include/IO/CLogWriter/CLogWriter.h>

// ICD Data
#include "../../../Data/Common/Auto_UGVEraseResponse.h"

namespace AUTONOMOUS
{
namespace Interface
{
namespace Common
{

class CProxyAuto_UGVEraseResponse
{
public :
    CProxyAuto_UGVEraseResponse();
    virtual ~CProxyAuto_UGVEraseResponse();

    virtual void OnAuto_UGVEraseResponse(AUTONOMOUS::Data::Common::StAuto_UGVEraseResponseComm& data) = 0;

    // Log
    bool CreateLogProxyAuto_UGVEraseResponse(char* logName);
    void CloseLogProxyAuto_UGVEraseResponse();

private:
    std::vector<uint8_t>   m_vBuffProxyAuto_UGVEraseResponse;
protected:
    DevLib::IO::CLogWriter m_logProxyAuto_UGVEraseResponse;

    void _OnAuto_UGVEraseResponse(AUTONOMOUS::Data::Common::StAuto_UGVEraseResponseComm& data);
};


}
}
}

#endif /* CPROXYEAUTO_UGVERASERESPONSE_H */
