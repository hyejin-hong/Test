#include "CStubAuto_UGVShutdownRequest.h"

namespace AUTONOMOUS
{
namespace Interface
{
namespace Common
{

CStubAuto_UGVShutdownRequest::CStubAuto_UGVShutdownRequest()
{
    m_snStubAuto_UGVShutdownRequest = 0;
}

CStubAuto_UGVShutdownRequest::~CStubAuto_UGVShutdownRequest()
{ 

}

bool CStubAuto_UGVShutdownRequest::CreateLogStubAuto_UGVShutdownRequest(char *logName)
{
    char fname[1024] = "";
    sprintf(fname, "./%s.Auto_UGVShutdownRequest", logName);

    return m_logStubAuto_UGVShutdownRequest.Create(fname);
}

void CStubAuto_UGVShutdownRequest::CloseLogStubAuto_UGVShutdownRequest()
{
    m_logStubAuto_UGVShutdownRequest.Destroy();
}


}
}
}
