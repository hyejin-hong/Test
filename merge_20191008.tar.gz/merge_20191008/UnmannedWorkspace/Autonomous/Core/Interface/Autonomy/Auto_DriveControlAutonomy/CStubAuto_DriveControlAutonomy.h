#ifndef CSTUBAUTO_DRIVECONTROLAUTONOMY_H
#define CSTUBAUTO_DRIVECONTROLAUTONOMY_H

#include <CFW.h>
#include <Core/DevLib/Include/IO/CLogWriter/CLogWriter.h>

// ICD Data
#include "../../../Data/Autonomy/Auto_DriveControlAutonomy.h"

namespace AUTONOMOUS
{
namespace Interface
{
namespace Autonomy
{

class CStubAuto_DriveControlAutonomy
{
public :
    CStubAuto_DriveControlAutonomy();
    virtual ~CStubAuto_DriveControlAutonomy();

    inline void WriteAuto_DriveControlAutonomy(AUTONOMOUS::Data::Autonomy::StAuto_DriveControlComm& data)
    {
        data.message_type   = MSG_TYPE_AUTONOMY;
        data.message_ID     = MSG_CODE_AUTONOMY_AUTO_DRIVECONTROLAUTONOMY;
        data.QoS            = MSG_QOS_AUTONOMY_AUTO_DRIVECONTROLAUTONOMY;
        data.SN             = m_snStubAuto_DriveControlAutonomy++;

        AUTONOMOUS::COMMLIB::CFW::GetInstance().Send(data);

        if( m_logStubAuto_DriveControlAutonomy.IsRun() )
        {
            m_vBuffStubAuto_DriveControlAutonomy.clear();
            data.getFrameData(m_vBuffStubAuto_DriveControlAutonomy);
            m_logStubAuto_DriveControlAutonomy.WriteData(m_vBuffStubAuto_DriveControlAutonomy.data(), m_vBuffStubAuto_DriveControlAutonomy.size());
        }
    }

    // Log
    bool CreateLogStubAuto_DriveControlAutonomy(char* logName);
    void CloseLogStubAuto_DriveControlAutonomy();

private:
    std::vector<uint8_t>   m_vBuffStubAuto_DriveControlAutonomy;
    uint8_t                m_snStubAuto_DriveControlAutonomy;
protected:
    DevLib::IO::CLogWriter m_logStubAuto_DriveControlAutonomy;
};


}
}
}

#endif /* CSTUBAUTO_DRIVECONTROLAUTONOMY_H */
