#ifndef DATA_SENSORDATA_SENSORTYPE_H
#define DATA_SENSORDATA_SENSORTYPE_H

namespace AUTONOMOUS
{
namespace Data
{
namespace Sensor
{

/*
 * Sensor Type
 */
typedef enum
{
	SENSOR_2DLIDAR_LD_MRS 	= 101,	//
	SENSOR_2DLIDAR_LMS_151 	= 102,	//
	SENSOR_2DLIDAR_LMS_511 	= 103,	//
	SENSOR_2DLIDAR_TMS		= 104,	//
	SENSOR_2DLIDAR_MRS_1000	= 105,	//

    SENSOR_3DLIDAR_16L		= 201,  //
    SENSOR_3DLIDAR_32L		= 202,  //
    SENSOR_3DLIDAR_64L		= 203,  //

    CAMERA_SINGLE			= 301,	// Camera(Single)
    CAMERA_DUAL             = 302,	// Camera(Dual)
    CAMERA_STEREO			= 303,	// Camera(Stereo)
    CAMERA_TRIPLE			= 304,	// Camera(Triple)

    CAMERA_IR				= 401,	// Camera(IR)

	RADAR_FMCW_ESR 			= 501,	// RADAR(FMCW ESR)
	RADAR_I_200				= 502,	// RADAR(I-200)

    DRIVE_INFO_MAP			= 901,	// 주행정보지도 정보
    VISUAL_EXTENSION_DEVICE = 902	// 가시권확장장치(4layer)
} eSensorType;

}
}
}


#endif // DATA_SENSORDATA_SENSORTYPE_H
