#ifndef CSTUBSENSORDATA_LIDAR_RTHETAFRONTCENTER_H
#define CSTUBSENSORDATA_LIDAR_RTHETAFRONTCENTER_H

#include <CFW.h>
#include <Core/DevLib/Include/IO/CLogWriter/CLogWriter.h>

// ICD Data
#include "../../../Data/Sensor/SensorData_LIDAR_Rtheta.h"

namespace AUTONOMOUS
{
namespace Interface
{
namespace Sensor
{

class CStubSensorData_LIDAR_RthetaFrontCenter
{
public :
    CStubSensorData_LIDAR_RthetaFrontCenter();
    virtual ~CStubSensorData_LIDAR_RthetaFrontCenter();

    inline void WriteSensorData_LIDAR_RthetaFrontCenter(AUTONOMOUS::Data::Sensor::StSensorData_LIDAR_RthetaComm& data)
    {
        data.message_type   = MSG_TYPE_SENSOR;
        data.message_ID     = MSG_CODE_SENSOR_SENSORDATA_LIDAR_RTHETAFRONTCENTER;
        data.QoS            = MSG_QOS_SENSOR_SENSORDATA_LIDAR_RTHETAFRONTCENTER;
        data.SN             = m_snStubSensorData_LIDAR_RthetaFrontCenter++;

        AUTONOMOUS::COMMLIB::CFW::GetInstance().Send(data);

        if( m_logStubSensorData_LIDAR_RthetaFrontCenter.IsRun() )
        {
            m_vBuffStubSensorData_LIDAR_RthetaFrontCenter.clear();
            data.getFrameData(m_vBuffStubSensorData_LIDAR_RthetaFrontCenter);
            m_logStubSensorData_LIDAR_RthetaFrontCenter.WriteData(m_vBuffStubSensorData_LIDAR_RthetaFrontCenter.data(), m_vBuffStubSensorData_LIDAR_RthetaFrontCenter.size());
        }
    }

    // Log
    bool CreateLogStubSensorData_LIDAR_RthetaFrontCenter(char* logName);
    void CloseLogStubSensorData_LIDAR_RthetaFrontCenter();

private:
    std::vector<uint8_t>   m_vBuffStubSensorData_LIDAR_RthetaFrontCenter;
    uint8_t                m_snStubSensorData_LIDAR_RthetaFrontCenter;
protected:
    DevLib::IO::CLogWriter m_logStubSensorData_LIDAR_RthetaFrontCenter;
};


}
}
}

#endif /* CSTUBSENSORDATA_LIDAR_RTHETAFRONTCENTER_H */
