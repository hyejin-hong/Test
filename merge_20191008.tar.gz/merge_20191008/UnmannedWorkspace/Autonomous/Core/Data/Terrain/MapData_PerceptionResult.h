#ifndef MAPDATA_PERCEPTIONRESULT_H
#define MAPDATA_PERCEPTIONRESULT_H

#include <CFW.h>
#include "../Common/Common.h"
#include "../Common/Auto_Navigation.h"

namespace AUTONOMOUS
{
namespace Data
{
namespace Terrain
{

typedef struct _StMapData_PerceptionResult
{
    flt64_t                                         SyncTime;                   // 동기화 시간
    AUTONOMOUS::Data::Common::StNavigationDetail    Navigation;                 // 항법

    // 확률지도의 맵 크기
    struct
    {
        uint16_t row;
        uint16_t col;
    } MapSize;

    // 확률지도상 차량 위치
    struct
    {
        uint16_t row;
        uint16_t col;
    } Robot_Index;

    uint8_t                                         ProbabilityMap[300*300];    // (정적환경인식) 융합 확률 지도 - 확률지도 확률 값(0-255)

} StMapData_PerceptionResult;


typedef struct _StMapData_PerceptionResultComm : public AUTONOMOUS::COMMLIB::Header, public StMapData_PerceptionResult
{
    virtual void setFrameData(uint8_t* buff)
    {
        buff = deserializeData(buff, SyncTime);

        buff = deserializeData(buff, Navigation.TimeStamp);
                std::for_each(Navigation.Zone, Navigation.Zone + 2, [&](int8_t& d)
        {
            buff = deserializeData(buff, d);
        });
        buff = deserializeData(buff, Navigation.East);
        buff = deserializeData(buff, Navigation.North);
        buff = deserializeData(buff, Navigation.Elevation);
        buff = deserializeData(buff, Navigation.Roll);
        buff = deserializeData(buff, Navigation.Pitch);
        buff = deserializeData(buff, Navigation.Heading);
        buff = deserializeData(buff, Navigation.VelocityLinearX);
        buff = deserializeData(buff, Navigation.VelocityLinearY);
        buff = deserializeData(buff, Navigation.VelocityLinearZ);
        buff = deserializeData(buff, Navigation.VelocityAngluarX);
        buff = deserializeData(buff, Navigation.VelocityAngluarY);
        buff = deserializeData(buff, Navigation.VelocityAngluarZ);

        buff = deserializeData(buff, MapSize.row);
        buff = deserializeData(buff, MapSize.col);
        buff = deserializeData(buff, Robot_Index.row);
        buff = deserializeData(buff, Robot_Index.col);

        std::for_each(ProbabilityMap, ProbabilityMap + MapSize.row * MapSize.col, [&](uint8_t& d)
        {
            buff = deserializeData(buff, d);
        });
    }

    virtual void getFrameData(std::vector<uint8_t>& buff)
    {
        serializeData(buff, SyncTime);

        serializeData(buff, Navigation.TimeStamp);
        std::for_each(Navigation.Zone, Navigation.Zone + 2, [&](int8_t d)
        {
            serializeData(buff, d);
        });
        serializeData(buff, Navigation.East);
        serializeData(buff, Navigation.North);
        serializeData(buff, Navigation.Elevation);
        serializeData(buff, Navigation.Roll);
        serializeData(buff, Navigation.Pitch);
        serializeData(buff, Navigation.Heading);
        serializeData(buff, Navigation.VelocityLinearX);
        serializeData(buff, Navigation.VelocityLinearY);
        serializeData(buff, Navigation.VelocityLinearZ);
        serializeData(buff, Navigation.VelocityAngluarX);
        serializeData(buff, Navigation.VelocityAngluarY);
        serializeData(buff, Navigation.VelocityAngluarZ);

        serializeData(buff, MapSize.row);
        serializeData(buff, MapSize.col);
        serializeData(buff, Robot_Index.row);
        serializeData(buff, Robot_Index.col);

        std::for_each(ProbabilityMap, ProbabilityMap + MapSize.row * MapSize.col, [&](uint8_t d)
        {
            serializeData(buff, d);
        });
    }

} StMapData_PerceptionResultComm;

}
}
}

#endif // MAPDATA_PERCEPTIONRESULT_H
