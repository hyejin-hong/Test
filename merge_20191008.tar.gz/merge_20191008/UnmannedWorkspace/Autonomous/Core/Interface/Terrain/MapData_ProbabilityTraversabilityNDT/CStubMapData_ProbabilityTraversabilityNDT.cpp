#include "CStubMapData_ProbabilityTraversabilityNDT.h"

namespace AUTONOMOUS
{
namespace Interface
{
namespace Terrain
{

CStubMapData_ProbabilityTraversabilityNDT::CStubMapData_ProbabilityTraversabilityNDT()
{
    m_snStubMapData_ProbabilityTraversabilityNDT = 0;
}

CStubMapData_ProbabilityTraversabilityNDT::~CStubMapData_ProbabilityTraversabilityNDT()
{ 

}

bool CStubMapData_ProbabilityTraversabilityNDT::CreateLogStubMapData_ProbabilityTraversabilityNDT(char *logName)
{
    char fname[1024] = "";
    sprintf(fname, "./%s.MapData_ProbabilityTraversabilityNDT", logName);

    return m_logStubMapData_ProbabilityTraversabilityNDT.Create(fname);
}

void CStubMapData_ProbabilityTraversabilityNDT::CloseLogStubMapData_ProbabilityTraversabilityNDT()
{
    m_logStubMapData_ProbabilityTraversabilityNDT.Destroy();
}


}
}
}
