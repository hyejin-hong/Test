#ifndef CPROXYEAUTO_CONTROLREQUEST_H
#define CPROXYEAUTO_CONTROLREQUEST_H

#include <Core/DevLib/Include/IO/CLogWriter/CLogWriter.h>

// ICD Data
#include "../../../Data/Autonomy/Auto_ControlRequest.h"

namespace AUTONOMOUS
{
namespace Interface
{
namespace Autonomy
{

class CProxyAuto_ControlRequest
{
public :
    CProxyAuto_ControlRequest();
    virtual ~CProxyAuto_ControlRequest();

    virtual void OnAuto_ControlRequest(AUTONOMOUS::Data::Autonomy::StAuto_ControlRequestComm& data) = 0;

    // Log
    bool CreateLogProxyAuto_ControlRequest(char* logName);
    void CloseLogProxyAuto_ControlRequest();

private:
    std::vector<uint8_t>   m_vBuffProxyAuto_ControlRequest;
protected:
    DevLib::IO::CLogWriter m_logProxyAuto_ControlRequest;

    void _OnAuto_ControlRequest(AUTONOMOUS::Data::Autonomy::StAuto_ControlRequestComm& data);
};


}
}
}

#endif /* CPROXYEAUTO_CONTROLREQUEST_H */
