#include "CStubAuto_CollisionAlarm.h"

namespace AUTONOMOUS
{
namespace Interface
{
namespace Autonomy
{

CStubAuto_CollisionAlarm::CStubAuto_CollisionAlarm()
{
    m_snStubAuto_CollisionAlarm = 0;
}

CStubAuto_CollisionAlarm::~CStubAuto_CollisionAlarm()
{ 

}

bool CStubAuto_CollisionAlarm::CreateLogStubAuto_CollisionAlarm(char *logName)
{
    char fname[1024] = "";
    sprintf(fname, "./%s.Auto_CollisionAlarm", logName);

    return m_logStubAuto_CollisionAlarm.Create(fname);
}

void CStubAuto_CollisionAlarm::CloseLogStubAuto_CollisionAlarm()
{
    m_logStubAuto_CollisionAlarm.Destroy();
}


}
}
}
