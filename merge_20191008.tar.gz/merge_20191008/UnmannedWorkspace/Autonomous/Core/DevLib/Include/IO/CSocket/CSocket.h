#ifndef CSOCKET_H
#define CSOCKET_H

#include <arpa/inet.h>

namespace DevLib
{
namespace IO
{

class CSocket
{
public:
    CSocket(int sockFD = -1);
    virtual ~CSocket();

    bool Create(int sockType);  // TCP, UDP
    void Destroy();

    bool IsCreated();

    bool Bind(int port, char* ip = 0);
    bool Listen(int nListen);
    int Accept();
    bool Connect(int port, char* ip);

    // TCP
    int Send(void* pData, int size, int flag = 0);
    int Recv(void* pData, int size, int flag = 0);

    // UDP
    int SendTo(void* pData, int size, char* dstIP, int dstPort, int flag = 0);
    int RecvFrom(void* pData, int size, char* srcIP, int* srcPort, int flag = 0);

    int GetSocket() { return m_fdSocket; }
    sockaddr_in GetSocketAddr(){ return m_sockAddrMy; }
    sockaddr_in GetSocketAddrRemote(){ return m_sockAddrRemote; }
    void SetSocketAddrRemote(sockaddr_in addr){ m_sockAddrRemote = addr; }
    bool GetConnected(int connected_fd);

    // Option
    bool JoinMuticastGroup(char* groupAddr, char* interfaceIP = 0);
    bool LeaveMulticastGroup(char* groupAddr, char* interfaceIP = 0);
    void SetOptionNagle(bool bUse);
    void SetOptionReuse(bool bReuse);
    void SetOptionLinger(bool bLinger);

    enum
    {
        SOCK_TCP = SOCK_STREAM,
        SOCK_UDP = SOCK_DGRAM
    };

protected:
    int m_fdSocket;	// 소켓 연결 파일 디스크립터
    sockaddr_in m_sockAddrMy;
    sockaddr_in m_sockAddrRemote;
    sockaddr_in m_sockTemp;
};

}
}
#endif
