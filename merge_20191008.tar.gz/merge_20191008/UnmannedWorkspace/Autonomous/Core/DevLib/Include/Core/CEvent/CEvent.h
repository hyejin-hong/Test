#ifndef _CEVENT_H
#define _CEVENT_H

#include <stdlib.h>

namespace DevLib
{

class CEvent
{
public:
	CEvent();
	virtual ~CEvent();

	bool Create(char* name=0);
	void Destroy();

	bool IsCreated();

	void SetEvent();
	void ResetEvent();
	bool WaitForEvent(int msTime);

private:
	bool m_bCreated;

	int m_cntMax;
	int m_cntCurrent;

	void* m_pEvent;
	void* m_sEvent;
	char* m_eventName;
};
}

#endif // _CEVENT_H
