#ifndef CSTUBMAPDATA_PERCEPTIONRESULT_H
#define CSTUBMAPDATA_PERCEPTIONRESULT_H

#include <CFW.h>
#include <Core/DevLib/Include/IO/CLogWriter/CLogWriter.h>

// ICD Data
#include "../../../Data/Terrain/MapData_PerceptionResult.h"

namespace AUTONOMOUS
{
namespace Interface
{
namespace Terrain
{

class CStubMapData_PerceptionResult
{
public :
    CStubMapData_PerceptionResult();
    virtual ~CStubMapData_PerceptionResult();

    inline void WriteMapData_PerceptionResult(AUTONOMOUS::Data::Terrain::StMapData_PerceptionResultComm& data)
    {
        data.message_type   = MSG_TYPE_TERRAIN;
        data.message_ID     = MSG_CODE_TERRAIN_MAPDATA_PERCEPTIONRESULT;
        data.QoS            = MSG_QOS_TERRAIN_MAPDATA_PERCEPTIONRESULT;
        data.SN             = m_snStubMapData_PerceptionResult++;

        AUTONOMOUS::COMMLIB::CFW::GetInstance().Send(data);

        if( m_logStubMapData_PerceptionResult.IsRun() )
        {
            m_vBuffStubMapData_PerceptionResult.clear();
            data.getFrameData(m_vBuffStubMapData_PerceptionResult);
            m_logStubMapData_PerceptionResult.WriteData(m_vBuffStubMapData_PerceptionResult.data(), m_vBuffStubMapData_PerceptionResult.size());
        }
    }

    // Log
    bool CreateLogStubMapData_PerceptionResult(char* logName);
    void CloseLogStubMapData_PerceptionResult();

private:
    std::vector<uint8_t>   m_vBuffStubMapData_PerceptionResult;
    uint8_t                m_snStubMapData_PerceptionResult;
protected:
    DevLib::IO::CLogWriter m_logStubMapData_PerceptionResult;
};


}
}
}

#endif /* CSTUBMAPDATA_PERCEPTIONRESULT_H */
