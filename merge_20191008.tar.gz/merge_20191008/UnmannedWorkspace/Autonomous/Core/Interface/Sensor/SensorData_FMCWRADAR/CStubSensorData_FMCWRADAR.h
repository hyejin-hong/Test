#ifndef CSTUBSENSORDATA_FMCWRADAR_H
#define CSTUBSENSORDATA_FMCWRADAR_H

#include <CFW.h>
#include <Core/DevLib/Include/IO/CLogWriter/CLogWriter.h>

// ICD Data
#include "../../../Data/Sensor/SensorData_FMCWRADAR.h"

namespace AUTONOMOUS
{
namespace Interface
{
namespace Sensor
{

class CStubSensorData_FMCWRADAR
{
public :
    CStubSensorData_FMCWRADAR();
    virtual ~CStubSensorData_FMCWRADAR();

    inline void WriteSensorData_FMCWRADAR(AUTONOMOUS::Data::Sensor::StSensorData_FMCWRADARComm& data)
    {
        data.message_type   = MSG_TYPE_SENSOR;
        data.message_ID     = MSG_CODE_SENSOR_SENSORDATA_FMCWRADAR;
        data.QoS            = MSG_QOS_SENSOR_SENSORDATA_FMCWRADAR;
        data.SN             = m_snStubSensorData_FMCWRADAR++;

        AUTONOMOUS::COMMLIB::CFW::GetInstance().Send(data);

        if( m_logStubSensorData_FMCWRADAR.IsRun() )
        {
            m_vBuffStubSensorData_FMCWRADAR.clear();
            data.getFrameData(m_vBuffStubSensorData_FMCWRADAR);
            m_logStubSensorData_FMCWRADAR.WriteData(m_vBuffStubSensorData_FMCWRADAR.data(), m_vBuffStubSensorData_FMCWRADAR.size());
        }
    }

    // Log
    bool CreateLogStubSensorData_FMCWRADAR(char* logName);
    void CloseLogStubSensorData_FMCWRADAR();

private:
    std::vector<uint8_t>   m_vBuffStubSensorData_FMCWRADAR;
    uint8_t                m_snStubSensorData_FMCWRADAR;
protected:
    DevLib::IO::CLogWriter m_logStubSensorData_FMCWRADAR;
};


}
}
}

#endif /* CSTUBSENSORDATA_FMCWRADAR_H */
