#ifndef CLOGWRITER_H
#define CLOGWRITER_H

#include "../../Core/CThread/CThread.h"
#include "../../Core/CEvent/CEvent.h"
#include "../../Core/CMutex/CMutex.h"
#include "../CFile/CFile.h"

#include <vector>
#include <queue>

namespace DevLib
{
namespace IO
{

class CLogWriter
 : public DevLib::CThread
 , public DevLib::CEvent
 , public DevLib::CMutex
 , public DevLib::IO::CFile
{
public:
	CLogWriter();
	virtual ~CLogWriter();

	bool Create(char* logName);
	void Destroy();

    bool WriteData(void* pData, unsigned int size);

private:
	virtual void Run();
	std::queue< std::vector<unsigned char> > m_queueData;
};

}
}

#endif /* CLOGWRITER_H */
