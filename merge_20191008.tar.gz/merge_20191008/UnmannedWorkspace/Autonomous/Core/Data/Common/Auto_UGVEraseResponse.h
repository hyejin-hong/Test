#ifndef AUTO_UGVERASERESPONSE_H
#define AUTO_UGVERASERESPONSE_H

#include <CFW.h>
#include "../Common/Common.h"

namespace AUTONOMOUS
{
namespace Data
{
namespace Common
{

typedef struct _StAuto_UGVEraseResponse
{
    flt64_t     SyncTime;       // 동기화 시간

} StAuto_UGVEraseResponse;

typedef struct _StAuto_UGVEraseResponseComm : public AUTONOMOUS::COMMLIB::Header, public StAuto_UGVEraseResponse
{
    virtual void setFrameData(uint8_t* buff)
    {
        buff = deserializeData(buff, SyncTime);
    }

    virtual void getFrameData(std::vector<uint8_t>& buff)
    {
        serializeData(buff, SyncTime);
    }

} StAuto_UGVEraseResponseComm;

}
}
}

#endif // AUTO_UGVERASERESPONSE_H
