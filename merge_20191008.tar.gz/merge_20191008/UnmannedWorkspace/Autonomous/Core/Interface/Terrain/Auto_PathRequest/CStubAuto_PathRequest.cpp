#include "CStubAuto_PathRequest.h"

namespace AUTONOMOUS
{
namespace Interface
{
namespace Terrain
{

CStubAuto_PathRequest::CStubAuto_PathRequest()
{
    m_snStubAuto_PathRequest = 0;
}

CStubAuto_PathRequest::~CStubAuto_PathRequest()
{ 

}

bool CStubAuto_PathRequest::CreateLogStubAuto_PathRequest(char *logName)
{
    char fname[1024] = "";
    sprintf(fname, "./%s.Auto_PathRequest", logName);

    return m_logStubAuto_PathRequest.Create(fname);
}

void CStubAuto_PathRequest::CloseLogStubAuto_PathRequest()
{
    m_logStubAuto_PathRequest.Destroy();
}


}
}
}
