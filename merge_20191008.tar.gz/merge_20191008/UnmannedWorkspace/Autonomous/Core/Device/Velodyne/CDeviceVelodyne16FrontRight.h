#ifndef CDEVICEVELODYNE16FRONTRIGHT_H
#define CDEVICEVELODYNE16FRONTRIGHT_H

#include "CVelodyneObject.h"

namespace AUTONOMOUS
{
namespace Device
{
namespace Velodyne
{

class CDeviceVelodyne16FrontRight : public AUTONOMOUS::Device::Velodyne::CObserverVelodyneObject
{
public:
	CDeviceVelodyne16FrontRight()
	: m_devVelodyne16FrontRight(this)
	{
	}

	virtual ~CDeviceVelodyne16FrontRight()
	{
	}

	virtual void OnVelodynePackFrontRight(AUTONOMOUS::Device::Velodyne::StVelodynePacket* pVelodynePack) = 0;
	virtual void OnVelodyneStatusFrontRight(AUTONOMOUS::Device::Velodyne::StVelodyneStatus* pVelodyneStatus) = 0;
    virtual void OnEMountFrontRight(AUTONOMOUS::Device::Velodyne::StEMount* pEMount) = 0;

	AUTONOMOUS::Device::Velodyne::CVelodyneObject* GetDeviceVelodyne16FrontRight() { return &m_devVelodyne16FrontRight; }

private :
	AUTONOMOUS::Device::Velodyne::CVelodyneObject 	m_devVelodyne16FrontRight;

	virtual void OnVelodynePack(AUTONOMOUS::Device::Velodyne::StVelodynePacket* pVelodynePack)
	{
		OnVelodynePackFrontRight(pVelodynePack);
	}

	virtual void OnVelodyneStatus(AUTONOMOUS::Device::Velodyne::StVelodyneStatus* pVelodyneStatus)
	{
		OnVelodyneStatusFrontRight(pVelodyneStatus);
	}

    virtual void OnEMount(AUTONOMOUS::Device::Velodyne::StEMount* pEMount)
    {
        OnEMountFrontRight(pEMount);
    }
};

}
}
}

#endif /* CDEVICEVELODYNE16FRONTRIGHT_H */
