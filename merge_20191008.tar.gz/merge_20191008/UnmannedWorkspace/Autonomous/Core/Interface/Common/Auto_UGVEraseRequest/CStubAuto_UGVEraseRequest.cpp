#include "CStubAuto_UGVEraseRequest.h"

namespace AUTONOMOUS
{
namespace Interface
{
namespace Common
{

CStubAuto_UGVEraseRequest::CStubAuto_UGVEraseRequest()
{
    m_snStubAuto_UGVEraseRequest = 0;
}

CStubAuto_UGVEraseRequest::~CStubAuto_UGVEraseRequest()
{ 

}

bool CStubAuto_UGVEraseRequest::CreateLogStubAuto_UGVEraseRequest(char *logName)
{
    char fname[1024] = "";
    sprintf(fname, "./%s.Auto_UGVEraseRequest", logName);

    return m_logStubAuto_UGVEraseRequest.Create(fname);
}

void CStubAuto_UGVEraseRequest::CloseLogStubAuto_UGVEraseRequest()
{
    m_logStubAuto_UGVEraseRequest.Destroy();
}


}
}
}
