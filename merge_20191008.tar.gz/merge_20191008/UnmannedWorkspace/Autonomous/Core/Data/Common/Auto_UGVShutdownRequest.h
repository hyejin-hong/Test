#ifndef AUTO_POWERREQUEST_H
#define AUTO_POWERREQUEST_H

#include <CFW.h>
#include "../Common/Common.h"

namespace AUTONOMOUS
{
namespace Data
{
namespace Common
{

typedef struct _StAuto_UGVShutdownRequest
{
    flt64_t SyncTime;   // 동기화 시간
    uint8_t Shutdown;   // 0 : 종료

} StAuto_UGVShutdownRequest;

typedef struct _StAuto_UGVShutdownRequestComm : public AUTONOMOUS::COMMLIB::Header, public StAuto_UGVShutdownRequest
{
    virtual void setFrameData(uint8_t* buff)
    {
        buff = deserializeData(buff, SyncTime);
        buff = deserializeData(buff, Shutdown);
    }

    virtual void getFrameData(std::vector<uint8_t>& buff)
    {
        serializeData(buff, SyncTime);
        serializeData(buff, Shutdown);
    }

} StAuto_UGVShutdownRequestComm;

}
}
}

#endif // AUTO_POWERREQUEST_H
