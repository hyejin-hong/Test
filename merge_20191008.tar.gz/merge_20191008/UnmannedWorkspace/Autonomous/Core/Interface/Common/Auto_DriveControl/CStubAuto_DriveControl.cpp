#include "CStubAuto_DriveControl.h"

namespace AUTONOMOUS
{
namespace Interface
{
namespace Common
{

CStubAuto_DriveControl::CStubAuto_DriveControl()
{
    m_snStubAuto_DriveControl = 0;
}

CStubAuto_DriveControl::~CStubAuto_DriveControl()
{ 

}

bool CStubAuto_DriveControl::CreateLogStubAuto_DriveControl(char *logName)
{
    char fname[1024] = "";
    sprintf(fname, "./%s.Auto_DriveControl", logName);

    return m_logStubAuto_DriveControl.Create(fname);
}

void CStubAuto_DriveControl::CloseLogStubAuto_DriveControl()
{
    m_logStubAuto_DriveControl.Destroy();
}


}
}
}
