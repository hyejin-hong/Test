#ifndef CPROXYESENSORDATA_IMAGE_H
#define CPROXYESENSORDATA_IMAGE_H

#include <Core/DevLib/Include/IO/CLogWriter/CLogWriter.h>

// ICD Data
#include "../../../Data/Sensor/SensorData_Image.h"

namespace AUTONOMOUS
{
namespace Interface
{
namespace Sensor
{

class CProxySensorData_Image
{
public :
    CProxySensorData_Image();
    virtual ~CProxySensorData_Image();

    virtual void OnSensorData_Image(AUTONOMOUS::Data::Sensor::StSensorData_ImageComm& data) = 0;

    // Log
    bool CreateLogProxySensorData_Image(char* logName);
    void CloseLogProxySensorData_Image();

private:
    std::vector<uint8_t>   m_vBuffProxySensorData_Image;
protected:
    DevLib::IO::CLogWriter m_logProxySensorData_Image;

    void _OnSensorData_Image(AUTONOMOUS::Data::Sensor::StSensorData_ImageComm& data);
};


}
}
}

#endif /* CPROXYESENSORDATA_IMAGE_H */
