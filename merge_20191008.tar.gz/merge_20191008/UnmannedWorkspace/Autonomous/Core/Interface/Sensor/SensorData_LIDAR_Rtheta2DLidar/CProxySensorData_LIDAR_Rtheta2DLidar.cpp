#include "CProxySensorData_LIDAR_Rtheta2DLidar.h"

namespace AUTONOMOUS
{
namespace Interface
{
namespace Sensor
{

CProxySensorData_LIDAR_Rtheta2DLidar::CProxySensorData_LIDAR_Rtheta2DLidar()
{
    AUTONOMOUS::COMMLIB::CFW::GetInstance().RegisterSub(MSG_CODE_SENSOR_SENSORDATA_LIDAR_RTHETA2DLIDAR, &CProxySensorData_LIDAR_Rtheta2DLidar::_OnSensorData_LIDAR_Rtheta2DLidar, this);
}

CProxySensorData_LIDAR_Rtheta2DLidar::~CProxySensorData_LIDAR_Rtheta2DLidar()
{

}

bool CProxySensorData_LIDAR_Rtheta2DLidar::CreateLogProxySensorData_LIDAR_Rtheta2DLidar(char *logName)
{
    char fname[1024] = "";
    sprintf(fname, "./%s.SensorData_LIDAR_Rtheta2DLidar", logName);

    return m_logProxySensorData_LIDAR_Rtheta2DLidar.Create(fname);
}

void CProxySensorData_LIDAR_Rtheta2DLidar::CloseLogProxySensorData_LIDAR_Rtheta2DLidar()
{
    m_logProxySensorData_LIDAR_Rtheta2DLidar.Destroy();
}

void CProxySensorData_LIDAR_Rtheta2DLidar::_OnSensorData_LIDAR_Rtheta2DLidar(AUTONOMOUS::Data::Sensor::StSensorData_LIDAR_RthetaComm& data)
{
    OnSensorData_LIDAR_Rtheta2DLidar(data);
    if( m_logProxySensorData_LIDAR_Rtheta2DLidar.IsRun() )
    {
        m_vBuffProxySensorData_LIDAR_Rtheta2DLidar.clear();
        data.getFrameData(m_vBuffProxySensorData_LIDAR_Rtheta2DLidar);
        m_logProxySensorData_LIDAR_Rtheta2DLidar.WriteData(m_vBuffProxySensorData_LIDAR_Rtheta2DLidar.data(), m_vBuffProxySensorData_LIDAR_Rtheta2DLidar.size());
    }
}

}
}
}
