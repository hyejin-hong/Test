#ifndef CPROXYEAUTO_UGVINTERFACESELECTION_H
#define CPROXYEAUTO_UGVINTERFACESELECTION_H

#include <Core/DevLib/Include/IO/CLogWriter/CLogWriter.h>

// ICD Data
#include "../../../Data/Common/Auto_UGVInterfaceSelection.h"

namespace AUTONOMOUS
{
namespace Interface
{
namespace Common
{

class CProxyAuto_UGVInterfaceSelection
{
public :
    CProxyAuto_UGVInterfaceSelection();
    virtual ~CProxyAuto_UGVInterfaceSelection();

    virtual void OnAuto_UGVInterfaceSelection(AUTONOMOUS::Data::Common::StAuto_UGVInterfaceSelectionComm& data) = 0;

    // Log
    bool CreateLogProxyAuto_UGVInterfaceSelection(char* logName);
    void CloseLogProxyAuto_UGVInterfaceSelection();

private:
    std::vector<uint8_t>   m_vBuffProxyAuto_UGVInterfaceSelection;
protected:
    DevLib::IO::CLogWriter m_logProxyAuto_UGVInterfaceSelection;

    void _OnAuto_UGVInterfaceSelection(AUTONOMOUS::Data::Common::StAuto_UGVInterfaceSelectionComm& data);
};


}
}
}

#endif /* CPROXYEAUTO_UGVINTERFACESELECTION_H */
