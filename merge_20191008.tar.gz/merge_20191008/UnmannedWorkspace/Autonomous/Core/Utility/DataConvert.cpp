#include "DataConvert.h"

#include <stdio.h>

namespace AUTONOMOUS
{
namespace Utility
{

void ConvertVelodyne16ToRTheta(
        AUTONOMOUS::Data::Sensor::StSensorData_LIDAR_Rtheta& dest,
        std::vector<AUTONOMOUS::Device::Velodyne::StVelodynePacket>& src)
{
    dest.LayerCount = 16;
    dest.SensorType = AUTONOMOUS::Data::Sensor::SENSOR_3DLIDAR_16L;

    unsigned int nTotalPoint = src.size() * AUTONOMOUS::Device::Velodyne::g_firingPerPacket * AUTONOMOUS::Device::Velodyne::g_laserPerFiring;
    dest.TotalPointNo = nTotalPoint;

    unsigned int countData = 0;

    for( unsigned int idxPack = 0; idxPack < src.size(); idxPack++ )
    {
        for( unsigned int  idxBlock = 0; idxBlock < AUTONOMOUS::Device::Velodyne::g_firingPerPacket; idxBlock++ )
        {
            double  stdAngle = src[idxPack].block[0].Azimuth * 0.01; // -- 기준 각도(deg)

            for( int  idxLayer = 0; idxLayer < AUTONOMOUS::Device::Velodyne::g_laserPerFiring; idxLayer++ )
            {
                int seqIndex = idxBlock * 2 + idxLayer % 2;
                int layerIndex = idxLayer % 16;
                double timeOffset = (55.296 * seqIndex) + (2.304 * layerIndex);
                double angleOffset = ( AUTONOMOUS::Device::Velodyne::g_velodyne16RPM / 60000000.0) * 360.0 * timeOffset;
                double curAngleH = stdAngle + angleOffset;

                unsigned short d = src[idxPack].block[idxBlock].layer[idxLayer].distance;
                dest.LidarData[countData].Angle       = (unsigned short)(curAngleH * 100.0);
                dest.LidarData[countData].Range       = (unsigned short)(d * 0.2);
                dest.LidarData[countData].LayerIndex  = layerIndex;
                dest.LidarData[countData].Intensity   = src[idxPack].block[idxBlock].layer[idxLayer].intensity;
                countData++;
            }
        }
    }

}

void ConvertVelodyne32ToRTheta(
        AUTONOMOUS::Data::Sensor::StSensorData_LIDAR_Rtheta& dest,
        const std::vector<AUTONOMOUS::Device::Velodyne::StVelodynePacket>& src,
        const AUTONOMOUS::Device::Velodyne::StCorrectionParams& correction)
{
    dest.LayerCount = 32;
    dest.SensorType = AUTONOMOUS::Data::Sensor::SENSOR_3DLIDAR_32L;

    unsigned int nTotalPoint = src.size() * AUTONOMOUS::Device::Velodyne::g_firingPerPacket * AUTONOMOUS::Device::Velodyne::g_laserPerFiring;
    dest.TotalPointNo = nTotalPoint;

    unsigned int countData = 0;

    for( unsigned int idxPack = 0; idxPack<src.size(); idxPack++ )
    {
        for( unsigned int  idxBlock = 0; idxBlock<AUTONOMOUS::Device::Velodyne::g_firingPerPacket; idxBlock++ )
        {
            for( unsigned int  idxLayer = 0; idxLayer<AUTONOMOUS::Device::Velodyne::g_laserPerFiring; idxLayer++ )
            {
                unsigned short d = src[idxPack].block[idxBlock].layer[idxLayer].distance;
                dest.LidarData[countData].Angle       = src[idxPack].block[idxBlock].Azimuth;
                dest.LidarData[countData].Range       = (unsigned short)(d*correction.distLBS + correction.correction[idxLayer].dist_correction);
                dest.LidarData[countData].LayerIndex  = idxLayer;
                dest.LidarData[countData].Intensity   = src[idxPack].block[idxBlock].layer[idxLayer].intensity;
                countData++;
            }
        }
    }
}

void ConvertMRS1000ToRTheta(AUTONOMOUS::Data::Sensor::StSensorData_LIDAR_Rtheta& dest, std::vector<AUTONOMOUS::Device::MRS1000::StMRS1000Packet>& src)
{
    dest.LayerCount = 4;
    dest.SensorType = AUTONOMOUS::Data::Sensor::SENSOR_2DLIDAR_MRS_1000;

    unsigned int nTotalPoint = 0;

    unsigned int countData = 0;

    for( unsigned int idxPack = 0; idxPack < src.size(); idxPack++)
    {
        nTotalPoint += src[idxPack].length;

        for(unsigned int idxBlock = 0; idxBlock < src[idxPack].length; idxBlock++)
        {
            dest.LidarData[countData].Angle         = (unsigned short)( (227.5 + (idxBlock * src[idxPack].resolution)) * 100) % 36000;
            dest.LidarData[countData].Range         = src[idxPack].scanData[idxBlock];
            dest.LidarData[countData].LayerIndex    = src[idxPack].layerIndex;
            dest.LidarData[countData].Intensity     = 0;
            countData++;
        }
    }

    dest.TotalPointNo = nTotalPoint;
}

}
}
