#include "../../Include/Utility/Config.h"
#include "../../3rd/cJSON/cJSON.h"
#include "../../Include/IO/CFile/CFile.h"
#include <vector>
#include <stdlib.h>
#include <string.h>

namespace DevLib
{
namespace Utility
{

static char __g_processor_name__[512] = "";
static char __g_config_name__[512] = "";

char* GetProcessorName()
{
    //    if( strlen(__g_processor_name__) == 0 )
    //    {
    //        QString pName = QFileInfo( QCoreApplication::applicationFilePath() ).fileName();
    //        strcpy(__g_processor_name__, pName.toLatin1().data());

    //        QString cName = pName;
    //        int pos = cName.indexOf("exe");
    //        if( pos >= 0 )
    //        {
    //            cName.replace("exe", "ini");
    //            cName.prepend("./");
    //        }
    //        else
    //        {
    //            cName.append(".ini");
    //            cName.prepend("./");
    //        }

    //        strcpy(__g_config_name__, cName.toLatin1().data());
    //    }

    return __g_processor_name__;
}

char* GetMakeConfigName()
{
    //    if( strlen(__g_config_name__) == 0 ) GetProcessorName();
    return __g_config_name__;
}

int GetConfigInt(const char *GroupName, const char *Idendity, int defValue, const char *configName)
{
    int rVal = defValue;

    DevLib::IO::CFile file;
    if( file.Create(configName, "rt") )
    {
        std::vector<char> buff;
        buff.resize(file.GetSize());
        file.Read(buff.data(), buff.size());
        file.Destroy();

        // Json 파싱
        cJSON* json = cJSON_Parse(buff.data());

        if( json )
        {
            cJSON *data = cJSON_GetObjectItem(json, GroupName);

            if( data )
            {
                cJSON * value = cJSON_GetObjectItem(data, Idendity);
                if( value )
                {
                    rVal = atoi(cJSON_Print(value));
                }
                else SetConfigInt(GroupName, Idendity, defValue, configName);
            }
            else SetConfigInt(GroupName, Idendity, defValue, configName);
        }
        else SetConfigInt(GroupName, Idendity, defValue, configName);
    }
    //    QString str;
    //    str.sprintf("%d", defValue);

    //    QSettings config(configName, QSettings::IniFormat);

    //    config.beginGroup(GroupName);
    //    QVariant var = config.value(Idendity, defValue);
    //    config.endGroup();

    //    if( str.compare(var.toString()) == 0 )
    //    {
    //        SetConfigInt(GroupName, Idendity, defValue, configName);
    //    }
    //    else
    //    {
    //        rVal = var.toInt();
    //    }


    return rVal;
}

void GetConfigString(const char *GroupName, const char *Idendity, const char *defValue, char *resultValue, int resultSize, const char *configName)
{
    //    QString str;
    //    str.sprintf("%s", defValue);

    //    QSettings config(configName, QSettings::IniFormat);
    //    config.beginGroup(GroupName);
    //    QVariant var = config.value(Idendity, defValue);
    //    config.endGroup();

    //    if( str.compare(var.toString()) == 0 )
    //    {
    //        SetConfigString(GroupName, Idendity, defValue, configName);
    //    }
    //    else
    //    {
    //        str = var.toString();
    //    }

    //    if( str.compare(defValue) == 0 ) SetConfigString(GroupName, Idendity, defValue, configName);
    //    if( resultSize < str.length() ) printf("resultSize Error\n");
    //    else strcpy(resultValue, str.toLatin1().data());

}

double GetConfigDouble(const char *GroupName, const char *Idendity, double defValue, const char *configName)
{
    double rVal = defValue;

    //    QSettings config(configName, QSettings::IniFormat);
    //    config.beginGroup(GroupName);
    //    QVariant var = config.value(Idendity, defValue);
    //    config.endGroup();
    //    if( IsEqual(rVal, var.toDouble()) )
    //    {
    //        SetConfigDouble(GroupName, Idendity, defValue, configName);
    //    }
    //    else
    //    {
    //        rVal = var.toDouble();
    //    }

    return rVal;
}

void SetConfigInt(const char *GroupName, const char *Idendity, int value, const char *configName)
{
    DevLib::IO::CFile file;
    if( file.Create(configName, "rt") )
    {
        std::vector<char> buff;
        buff.resize(file.GetSize()*2);
        file.Read(buff.data(), buff.size());
        file.Destroy();

        // Json 파싱
        cJSON* json = cJSON_Parse(buff.data());

        cJSON* itemGroup = cJSON_CreateNull();
        cJSON_AddItemToObject(json, GroupName, itemGroup);

        cJSON* itemValue = cJSON_CreateNumber(value);
        cJSON_AddItemToObject(itemGroup, Idendity, itemValue);

        if( file.Create(configName, "wt") )
        {
            char* pOut = cJSON_Print(json);
            file.Write(pOut, strlen(pOut));
        }
    }
    //    QSettings config(QString(configName), QSettings::IniFormat);
    //    config.beginGroup(GroupName);
    //    config.setValue(Idendity, value);
    //    config.endGroup();
}

void SetConfigString(const char *GroupName, const char *Idendity, const char *value, const char *configName)
{
    //    QSettings config(QString(configName), QSettings::IniFormat);
    //    config.beginGroup(GroupName);
    //    config.setValue(Idendity, value);
    //    config.endGroup();
}

void SetConfigDouble(const char *GroupName, const char *Idendity, double value, const char *configName)
{
    //    QSettings config(QString(configName), QSettings::IniFormat);
    //    config.beginGroup(GroupName);
    //    config.setValue(Idendity, value);
    //    config.endGroup();
}

}
}
