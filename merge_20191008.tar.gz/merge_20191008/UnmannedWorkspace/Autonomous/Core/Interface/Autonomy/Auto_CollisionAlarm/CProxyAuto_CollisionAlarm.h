#ifndef CPROXYEAUTO_COLLISIONALARM_H
#define CPROXYEAUTO_COLLISIONALARM_H

#include <Core/DevLib/Include/IO/CLogWriter/CLogWriter.h>

// ICD Data
#include "../../../Data/Autonomy/Auto_CollisionAlarm.h"

namespace AUTONOMOUS
{
namespace Interface
{
namespace Autonomy
{

class CProxyAuto_CollisionAlarm
{
public :
    CProxyAuto_CollisionAlarm();
    virtual ~CProxyAuto_CollisionAlarm();

    virtual void OnAuto_CollisionAlarm(AUTONOMOUS::Data::Autonomy::StAuto_CollisionAlarmComm& data) = 0;

    // Log
    bool CreateLogProxyAuto_CollisionAlarm(char* logName);
    void CloseLogProxyAuto_CollisionAlarm();

private:
    std::vector<uint8_t>   m_vBuffProxyAuto_CollisionAlarm;
protected:
    DevLib::IO::CLogWriter m_logProxyAuto_CollisionAlarm;

    void _OnAuto_CollisionAlarm(AUTONOMOUS::Data::Autonomy::StAuto_CollisionAlarmComm& data);
};


}
}
}

#endif /* CPROXYEAUTO_COLLISIONALARM_H */
