#include "CStubSensorData_FMCWRADAR.h"

namespace AUTONOMOUS
{
namespace Interface
{
namespace Sensor
{

CStubSensorData_FMCWRADAR::CStubSensorData_FMCWRADAR()
{
    m_snStubSensorData_FMCWRADAR = 0;
}

CStubSensorData_FMCWRADAR::~CStubSensorData_FMCWRADAR()
{ 

}

bool CStubSensorData_FMCWRADAR::CreateLogStubSensorData_FMCWRADAR(char *logName)
{
    char fname[1024] = "";
    sprintf(fname, "./%s.SensorData_FMCWRADAR", logName);

    return m_logStubSensorData_FMCWRADAR.Create(fname);
}

void CStubSensorData_FMCWRADAR::CloseLogStubSensorData_FMCWRADAR()
{
    m_logStubSensorData_FMCWRADAR.Destroy();
}


}
}
}
