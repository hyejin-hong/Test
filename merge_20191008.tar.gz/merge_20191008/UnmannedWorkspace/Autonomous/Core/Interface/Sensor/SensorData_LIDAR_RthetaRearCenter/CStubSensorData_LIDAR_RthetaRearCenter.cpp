#include "CStubSensorData_LIDAR_RthetaRearCenter.h"

namespace AUTONOMOUS
{
namespace Interface
{
namespace Sensor
{

CStubSensorData_LIDAR_RthetaRearCenter::CStubSensorData_LIDAR_RthetaRearCenter()
{
    m_snStubSensorData_LIDAR_RthetaRearCenter = 0;
}

CStubSensorData_LIDAR_RthetaRearCenter::~CStubSensorData_LIDAR_RthetaRearCenter()
{ 

}

bool CStubSensorData_LIDAR_RthetaRearCenter::CreateLogStubSensorData_LIDAR_RthetaRearCenter(char *logName)
{
    char fname[1024] = "";
    sprintf(fname, "./%s.SensorData_LIDAR_RthetaRearCenter", logName);

    return m_logStubSensorData_LIDAR_RthetaRearCenter.Create(fname);
}

void CStubSensorData_LIDAR_RthetaRearCenter::CloseLogStubSensorData_LIDAR_RthetaRearCenter()
{
    m_logStubSensorData_LIDAR_RthetaRearCenter.Destroy();
}


}
}
}
