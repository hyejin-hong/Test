#include "CommonVelodyne.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

namespace AUTONOMOUS
{
namespace Device
{
namespace Velodyne
{

static int8_t* itoa(AUTONOMOUS::int32_t val, AUTONOMOUS::int8_t* buf)
{
	sprintf(buf, "%d", val);

	return 0;
}

bool _StCorrctionParams::ReadCorrectionFile(const char* fileName)
{
	bool bRet = false;

	StCorrectionParams calibParams;

	/* 파일을 열고 데이터를 파싱한다. */
	FILE* p_xml_file = fopen(fileName, "rb");
	if(p_xml_file != NULL)
	{
		printf("Success open db.xml file. \r\n");
		fseek(p_xml_file,0,SEEK_END); // 동적 배열 할당
		//int32_t file_size = ftell(p_xml_file);
		fseek(p_xml_file,0,SEEK_SET);

		char *buf = new(std::nothrow) char[1024];
		char char_distLBS[256] = {"<distLSB_>"};

		/* 파일로 부터 distLSB_값을 추출한다.*/
		bool b_get_dist_LBS = false;
		while(fgets(buf, 1024, p_xml_file) && b_get_dist_LBS==false)
		{
			if(strstr(buf,char_distLBS))
			{
				char* token = strtok( buf, ">" );
				if( token )
				{
					token = strtok( NULL, "</" );
				}
				calibParams.distLBS = (float)atof(token);
				b_get_dist_LBS =true;
			}
		}
		printf("dist_LBS=%.1lf\n",calibParams.distLBS);


		/* 파일로 부터 correction값을 추출한다.*/
		for(uint32_t i=0 ; i<64 ; i++)
		{
			fseek(p_xml_file,0,SEEK_SET);
			char char_correction[256]={"<id_>"};
			char copy_string[7]={"</id_>"};
			if(i<10)
			{
				itoa(i, &char_correction[5]);
				memcpy(&char_correction[6],&copy_string,sizeof(copy_string));
			}
			else
			{
				itoa(i,&char_correction[5]);
				memcpy(&char_correction[7],&copy_string,sizeof(copy_string));
			}

			while(fgets(buf, 256, p_xml_file))
			{
				if(strstr(buf,char_correction))
				{
					char *buf_char = new(std::nothrow) char[512];

					for(int k=0 ; k<9 ; k++)
					{
						if( fgets(buf_char, 512, p_xml_file) )
						{
							char* token = strtok( buf_char, ">" );
							token = strtok( NULL, "<" );

							switch(k)
							{
							case 0 :
								calibParams.correction[i].rotate_correction = (float)atof(token);
								break;
							case 1 :
								calibParams.correction[i].vertical_correction = (float)atof(token);
								break;
							case 2 :
								calibParams.correction[i].dist_correction = (int)atoi(token);
								break;
							case 3 :
								calibParams.correction[i].dist_correction_x = (int)atoi(token);
								break;
							case 4 :
								calibParams.correction[i].dist_correction_y = (int)atoi(token);
								break;
							case 5 :
								calibParams.correction[i].vertical_offset_correction = (float)atof(token);
								break;
							case 6 :
								calibParams.correction[i].horize_offset_correction = (float)atof(token);
								break;
							case 7 :
								calibParams.correction[i].focal_distance = (int)atoi(token);
								break;
							case 8 :
								calibParams.correction[i].focal_slope = (float)atof(token);
								break;
							default:
							{
								break;
							}
							}
						}
					}
					delete[] buf_char;
				}
			}
		}
		delete[] buf;
		fclose(p_xml_file);

		bRet = true;
	}
	else
	{
		printf("Failed open db.xml file.\r\n");
		bRet = false;
	}
	/* db.xml 파일 파싱 끝 */

	if( bRet )
	{
		/* 파싱 데이터 출력 */
		printf("\ndistLBS : %.2f\r\n",calibParams.distLBS);
		for(int i=0 ; i<64 ; i++)
		{
			double vert_correction = calibParams.correction[i].vertical_correction;
			calibParams.correction[i].cos_vertical_angle = (float)cos(vert_correction*3.14159265358979323846/180.0);
			calibParams.correction[i].sin_vertical_angle = (float)sin(vert_correction*3.14159265358979323846/180.0);

			double rot_correction = calibParams.correction[i].rotate_correction;
			calibParams.correction[i].sin_rotation_correction = (float)sin(rot_correction*3.14159265358979323846/180.0);
			calibParams.correction[i].cos_rotation_correction = (float)cos(rot_correction*3.14159265358979323846/180.0);

			//double horiz_offset_correction = calibParams.correction[i].horize_offset_correction;
			//double vert_offset_correction = calibParams.correction[i].vertical_offset_correction;

			//printf("%d : ",i);
			//calibParams.correction[i].rotate_correction;
			//printf("ro: %.2lf ",calibParams.correction[i].rotate_correction);
			//calibParams.correction[i].vertical_correction;
			//printf("vo: %.2lf ",calibParams.correction[i].vertical_correction);
			//calibParams.correction[i].dist_correction;
			//printf("di: %d ",calibParams.correction[i].dist_correction);
			//calibParams.correction[i].vertical_offset_correction;
			//printf("v_o: %.2lf ",calibParams.correction[i].vertical_offset_correction);
			//calibParams.correction[i].horize_offset_correction;
			//printf("Ho: %.2lf\n",calibParams.correction[i].horize_offset_correction);
		}

		printf("\n");

		memcpy(this, &calibParams, sizeof calibParams);
	}

	return bRet;
}

}
}
}
