#ifndef SENSORDATA_LIDAR_TEMPER_H
#define SENSORDATA_LIDAR_TEMPER_H

#include "../Common/Common.h"

namespace AUTONOMOUS
{
namespace Data
{
namespace Sensor
{

// EMount BIT
typedef struct _StSensorData_EMount_BIT
{
    uint8_t     Header[2];
    uint8_t     MessageID;
    uint16_t    Length;
    uint8_t     Data;
    uint8_t     CRC;

    inline unsigned int GetSize() { return sizeof(_StSensorData_EMount_BIT); }
} __attribute__((packed)) StSensorData_EMount_BIT;


// Lidar Temper
typedef struct _StSensorData_LIDAR_Temper
{
    uint8_t     Header[2];
    uint8_t     MessageID;
    uint16_t    Length;
    uint16_t    TopTemperature;
    uint16_t    BottomTemperature;
    uint8_t     CRC;

    inline unsigned int GetSize() { return sizeof(_StSensorData_LIDAR_Temper); }
} __attribute__((packed)) StSensorData_LIDAR_Temper;

// EMount PowerControl
typedef struct _StSensorData_EMount_Power_Control
{
    uint8_t     Header[2];
    uint8_t     MessageID;
    uint16_t    Length;
    uint8_t     Control;
    uint8_t     CRC;

    inline unsigned int GetSize() { return sizeof(_StSensorData_EMount_Power_Control); }
} __attribute__((packed)) StSensorData_EMount_Power_Control;

// Lidar PhaseLock
typedef struct _StSensorData_LIDAR_Phase_Lock
{
    uint8_t     Header[2];
    uint8_t     MessageID;
    uint16_t    Length;
    uint8_t     Control;
    uint8_t     CRC;

    inline unsigned int GetSize() { return sizeof(_StSensorData_LIDAR_Phase_Lock); }
} __attribute__((packed)) _StSensorData_LIDAR_Phase_Lock;

// Lidar PhaseLock
typedef struct _StSensorData_EMount_Status
{
    uint8_t     Header[2];
    uint8_t     MessageID;
    uint16_t    Length;
    uint8_t     Data;
    uint8_t     CRC;

    inline unsigned int GetSize() { return sizeof(_StSensorData_EMount_Status); }
} __attribute__((packed)) StSensorData_EMount_Status;

}
}
}

#endif // SENSORDATA_LIDAR_TEMPER_H
