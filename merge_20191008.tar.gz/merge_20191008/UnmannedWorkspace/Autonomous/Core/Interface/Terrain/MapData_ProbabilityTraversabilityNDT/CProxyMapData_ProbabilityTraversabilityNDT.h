#ifndef CPROXYEMAPDATA_PROBABILITYTRAVERSABILITYNDT_H
#define CPROXYEMAPDATA_PROBABILITYTRAVERSABILITYNDT_H

#include <Core/DevLib/Include/IO/CLogWriter/CLogWriter.h>

// ICD Data
#include "../../../Data/Terrain/MapData_Probability.h"

namespace AUTONOMOUS
{
namespace Interface
{
namespace Terrain
{

class CProxyMapData_ProbabilityTraversabilityNDT
{
public :
    CProxyMapData_ProbabilityTraversabilityNDT();
    virtual ~CProxyMapData_ProbabilityTraversabilityNDT();

    virtual void OnMapData_ProbabilityTraversabilityNDT(AUTONOMOUS::Data::Terrain::StMapData_ProbabilityComm& data) = 0;

    // Log
    bool CreateLogProxyMapData_ProbabilityTraversabilityNDT(char* logName);
    void CloseLogProxyMapData_ProbabilityTraversabilityNDT();

private:
    std::vector<uint8_t>   m_vBuffProxyMapData_ProbabilityTraversabilityNDT;
protected:
    DevLib::IO::CLogWriter m_logProxyMapData_ProbabilityTraversabilityNDT;

    void _OnMapData_ProbabilityTraversabilityNDT(AUTONOMOUS::Data::Terrain::StMapData_ProbabilityComm& data);
};


}
}
}

#endif /* CPROXYEMAPDATA_PROBABILITYTRAVERSABILITYNDT_H */
