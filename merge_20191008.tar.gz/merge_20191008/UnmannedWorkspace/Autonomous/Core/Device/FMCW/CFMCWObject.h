/*
 * CFMCWObject.h
 *
 *  Created on: 2019. 4. 4.
 *      Author: hong
 */

#ifndef CFMCWOBJECT_H
#define CFMCWOBJECT_H
#include <vector>
#include <unistd.h>
#include <termios.h>
#include <stdio.h>
#include <fcntl.h>      // file control definitions
#include <errno.h>
#include <termios.h>
#include <memory.h>
#include <string.h>
#include <stdlib.h>
#include "../../DevLib/Include/IO/CSocketReceiver/CSocketReceiver.h"
#include "../../Data/Sensor/SensorData_FMCWRADAR.h"
#include "../../DevLib/Include/Core/CThread/CThread.h"

namespace UNMANNED
{
namespace Device
{
namespace FMCW
{

class CObserverFMCWObject
{
public :
	virtual ~CObserverFMCWObject() { }

    virtual void OnFMCWPack(UNMANNED::Data::Sensor::StFMCWRadar* pFMCWPack) = 0;
};

class CFMCWObject
: public DevLib::CThread
//, public DevLib::IO::CSocketReceiver
{
public:
	CFMCWObject(CObserverFMCWObject* pObserver = 0);
	virtual ~CFMCWObject();

	bool Create(char* bindIP, int port);						// Socket로 데이터 받기
	int PortOpen(const int8_t* device_name, speed_t baud_rate);

	bool Send();
	int SendData(void* src, int canID);

private:
	virtual void Run();									// 재� �의 함수

	CObserverFMCWObject* m_pObserverFMCWObject;

	std::vector<char>		m_readData;			// Raw Data

	int m_serialFd;
};

}
}
}




#endif /* CFMCWOBJECT_H */
