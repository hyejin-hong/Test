#ifndef CSTUBMAPDATA_OBJECT_H
#define CSTUBMAPDATA_OBJECT_H

#include <CFW.h>
#include <Core/DevLib/Include/IO/CLogWriter/CLogWriter.h>

// ICD Data
#include "../../../Data/Terrain/MapData_Object.h"

namespace AUTONOMOUS
{
namespace Interface
{
namespace Terrain
{

class CStubMapData_Object
{
public :
    CStubMapData_Object();
    virtual ~CStubMapData_Object();

    inline void WriteMapData_Object(AUTONOMOUS::Data::Terrain::StMapData_ObjectComm& data)
    {
        data.message_type   = MSG_TYPE_TERRAIN;
        data.message_ID     = MSG_CODE_TERRAIN_MAPDATA_OBJECT;
        data.QoS            = MSG_QOS_TERRAIN_MAPDATA_OBJECT;
        data.SN             = m_snStubMapData_Object++;

        AUTONOMOUS::COMMLIB::CFW::GetInstance().Send(data);

        if( m_logStubMapData_Object.IsRun() )
        {
            m_vBuffStubMapData_Object.clear();
            data.getFrameData(m_vBuffStubMapData_Object);
            m_logStubMapData_Object.WriteData(m_vBuffStubMapData_Object.data(), m_vBuffStubMapData_Object.size());
        }
    }

    // Log
    bool CreateLogStubMapData_Object(char* logName);
    void CloseLogStubMapData_Object();

private:
    std::vector<uint8_t>   m_vBuffStubMapData_Object;
    uint8_t                m_snStubMapData_Object;
protected:
    DevLib::IO::CLogWriter m_logStubMapData_Object;
};


}
}
}

#endif /* CSTUBMAPDATA_OBJECT_H */
