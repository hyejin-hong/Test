#include "CStubAuto_DriveControlAutonomy.h"

namespace AUTONOMOUS
{
namespace Interface
{
namespace Autonomy
{

CStubAuto_DriveControlAutonomy::CStubAuto_DriveControlAutonomy()
{
    m_snStubAuto_DriveControlAutonomy = 0;
}

CStubAuto_DriveControlAutonomy::~CStubAuto_DriveControlAutonomy()
{ 

}

bool CStubAuto_DriveControlAutonomy::CreateLogStubAuto_DriveControlAutonomy(char *logName)
{
    char fname[1024] = "";
    sprintf(fname, "./%s.Auto_DriveControlAutonomy", logName);

    return m_logStubAuto_DriveControlAutonomy.Create(fname);
}

void CStubAuto_DriveControlAutonomy::CloseLogStubAuto_DriveControlAutonomy()
{
    m_logStubAuto_DriveControlAutonomy.Destroy();
}


}
}
}
