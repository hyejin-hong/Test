#include "CProxySensorData_LIDAR_RthetaRearCenter.h"

namespace AUTONOMOUS
{
namespace Interface
{
namespace Sensor
{

CProxySensorData_LIDAR_RthetaRearCenter::CProxySensorData_LIDAR_RthetaRearCenter()
{
    AUTONOMOUS::COMMLIB::CFW::GetInstance().RegisterSub(MSG_CODE_SENSOR_SENSORDATA_LIDAR_RTHETAREARCENTER, &CProxySensorData_LIDAR_RthetaRearCenter::_OnSensorData_LIDAR_RthetaRearCenter, this);
}

CProxySensorData_LIDAR_RthetaRearCenter::~CProxySensorData_LIDAR_RthetaRearCenter()
{

}

bool CProxySensorData_LIDAR_RthetaRearCenter::CreateLogProxySensorData_LIDAR_RthetaRearCenter(char *logName)
{
    char fname[1024] = "";
    sprintf(fname, "./%s.SensorData_LIDAR_RthetaRearCenter", logName);

    return m_logProxySensorData_LIDAR_RthetaRearCenter.Create(fname);
}

void CProxySensorData_LIDAR_RthetaRearCenter::CloseLogProxySensorData_LIDAR_RthetaRearCenter()
{
    m_logProxySensorData_LIDAR_RthetaRearCenter.Destroy();
}

void CProxySensorData_LIDAR_RthetaRearCenter::_OnSensorData_LIDAR_RthetaRearCenter(AUTONOMOUS::Data::Sensor::StSensorData_LIDAR_RthetaComm& data)
{
    OnSensorData_LIDAR_RthetaRearCenter(data);
    if( m_logProxySensorData_LIDAR_RthetaRearCenter.IsRun() )
    {
        m_vBuffProxySensorData_LIDAR_RthetaRearCenter.clear();
        data.getFrameData(m_vBuffProxySensorData_LIDAR_RthetaRearCenter);
        m_logProxySensorData_LIDAR_RthetaRearCenter.WriteData(m_vBuffProxySensorData_LIDAR_RthetaRearCenter.data(), m_vBuffProxySensorData_LIDAR_RthetaRearCenter.size());
    }
}

}
}
}
