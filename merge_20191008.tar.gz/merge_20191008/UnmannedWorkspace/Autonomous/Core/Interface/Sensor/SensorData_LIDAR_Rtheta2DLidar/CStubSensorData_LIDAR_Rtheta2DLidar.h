#ifndef CSTUBSENSORDATA_LIDAR_RTHETA2DLIDAR_H
#define CSTUBSENSORDATA_LIDAR_RTHETA2DLIDAR_H

#include <CFW.h>
#include <Core/DevLib/Include/IO/CLogWriter/CLogWriter.h>

// ICD Data
#include "../../../Data/Sensor/SensorData_LIDAR_Rtheta.h"

namespace AUTONOMOUS
{
namespace Interface
{
namespace Sensor
{

class CStubSensorData_LIDAR_Rtheta2DLidar
{
public :
    CStubSensorData_LIDAR_Rtheta2DLidar();
    virtual ~CStubSensorData_LIDAR_Rtheta2DLidar();

    inline void WriteSensorData_LIDAR_Rtheta2DLidar(AUTONOMOUS::Data::Sensor::StSensorData_LIDAR_RthetaComm& data)
    {
        data.message_type   = MSG_TYPE_SENSOR;
        data.message_ID     = MSG_CODE_SENSOR_SENSORDATA_LIDAR_RTHETA2DLIDAR;
        data.QoS            = MSG_QOS_SENSOR_SENSORDATA_LIDAR_RTHETA2DLIDAR;
        data.SN             = m_snStubSensorData_LIDAR_Rtheta2DLidar++;

        AUTONOMOUS::COMMLIB::CFW::GetInstance().Send(data);

        if( m_logStubSensorData_LIDAR_Rtheta2DLidar.IsRun() )
        {
            m_vBuffStubSensorData_LIDAR_Rtheta2DLidar.clear();
            data.getFrameData(m_vBuffStubSensorData_LIDAR_Rtheta2DLidar);
            m_logStubSensorData_LIDAR_Rtheta2DLidar.WriteData(m_vBuffStubSensorData_LIDAR_Rtheta2DLidar.data(), m_vBuffStubSensorData_LIDAR_Rtheta2DLidar.size());
        }
    }

    // Log
    bool CreateLogStubSensorData_LIDAR_Rtheta2DLidar(char* logName);
    void CloseLogStubSensorData_LIDAR_Rtheta2DLidar();

private:
    std::vector<uint8_t>   m_vBuffStubSensorData_LIDAR_Rtheta2DLidar;
    uint8_t                m_snStubSensorData_LIDAR_Rtheta2DLidar;
protected:
    DevLib::IO::CLogWriter m_logStubSensorData_LIDAR_Rtheta2DLidar;
};


}
}
}

#endif /* CSTUBSENSORDATA_LIDAR_RTHETA2DLIDAR_H */
