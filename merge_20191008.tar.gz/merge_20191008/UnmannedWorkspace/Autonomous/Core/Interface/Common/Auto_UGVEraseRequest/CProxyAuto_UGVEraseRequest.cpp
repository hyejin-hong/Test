#include "CProxyAuto_UGVEraseRequest.h"

namespace AUTONOMOUS
{
namespace Interface
{
namespace Common
{

CProxyAuto_UGVEraseRequest::CProxyAuto_UGVEraseRequest()
{
    AUTONOMOUS::COMMLIB::CFW::GetInstance().RegisterSub(MSG_CODE_COMMON_AUTO_UGVERASEREQUEST, &CProxyAuto_UGVEraseRequest::_OnAuto_UGVEraseRequest, this);
}

CProxyAuto_UGVEraseRequest::~CProxyAuto_UGVEraseRequest()
{

}

bool CProxyAuto_UGVEraseRequest::CreateLogProxyAuto_UGVEraseRequest(char *logName)
{
    char fname[1024] = "";
    sprintf(fname, "./%s.Auto_UGVEraseRequest", logName);

    return m_logProxyAuto_UGVEraseRequest.Create(fname);
}

void CProxyAuto_UGVEraseRequest::CloseLogProxyAuto_UGVEraseRequest()
{
    m_logProxyAuto_UGVEraseRequest.Destroy();
}

void CProxyAuto_UGVEraseRequest::_OnAuto_UGVEraseRequest(AUTONOMOUS::Data::Common::StAuto_UGVEraseRequestComm& data)
{
    OnAuto_UGVEraseRequest(data);
    if( m_logProxyAuto_UGVEraseRequest.IsRun() )
    {
        m_vBuffProxyAuto_UGVEraseRequest.clear();
        data.getFrameData(m_vBuffProxyAuto_UGVEraseRequest);
        m_logProxyAuto_UGVEraseRequest.WriteData(m_vBuffProxyAuto_UGVEraseRequest.data(), m_vBuffProxyAuto_UGVEraseRequest.size());
    }
}

}
}
}
