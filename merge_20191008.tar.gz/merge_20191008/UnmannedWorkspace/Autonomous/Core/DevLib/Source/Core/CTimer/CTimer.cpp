#include "../../../Include/Core/CTimer/CTimer.h"


#include <stdlib.h>
#include <pthread.h>

namespace DevLib
{

void TimerCaller(sigval_t sv)
{
	CTimer* pThis = (CTimer*)sv.sival_ptr;

	pThis->OnTimer(0);
}

CTimer::CTimer()
: m_bTimer(false)
{
		m_timerId 		= new timer_t;				// timer_t --> void*
}

CTimer::~CTimer()
{
}

bool CTimer::TimerStart(int ms, TIMER_CALLBACK func, void* param)
{
	sigevent ptimerEvent;

	bool bRet = false;

	if(IsTimerOn()==true)
	{
		TimerStop();
	}

	if(IsTimerOn() == false)
	{
		m_param.pCallBack = func;
		m_param.pParam = param;

		ptimerEvent.sigev_value.sival_ptr = this;							// @suppress("Field cannot be resolved")
		ptimerEvent.sigev_notify = SIGEV_THREAD; 							// @suppress("Field cannot be resolved")
		ptimerEvent.sigev_notify_function = TimerCaller;					// @suppress("Field cannot be resolved")
		ptimerEvent.sigev_notify_attributes = 0; 							// @suppress("Field cannot be resolved")

		if(timer_create(CLOCK_REALTIME, &ptimerEvent, &m_timerId) == 0)
		{
			long sec = ms * 0.001;
			long msec = (ms % 1000) * 1000000;
			struct itimerspec time = { { sec, msec} , { sec, msec} };

			if(timer_settime(m_timerId, 0, &time, 0) == 0)
			{
				bRet = true;
				m_bTimer = true;
			}

		}
	}
	return bRet;
}

void CTimer::TimerStop()
{
	if(IsTimerOn())
	{
		timer_delete(m_timerId);
	}
	m_bTimer = false;
}

bool CTimer::IsTimerOn()
{
	return m_bTimer;
}

void CTimer::OnTimer(void*)
{
	if( m_param.pCallBack ) m_param.pCallBack(m_param.pParam);
}

}

