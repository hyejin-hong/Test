#ifndef AUTO_NAVIGATION_H
#define AUTO_NAVIGATION_H

#include <CFW.h>
#include "../Common/Common.h"

namespace AUTONOMOUS
{
namespace Data
{
namespace Common
{

typedef struct _StNavigationDetail
{
        flt64_t	TimeStamp;          // 시간정보
        int8_t	Zone[2];            // Zone 정보

        // MGRS 위치 정보
        flt64_t	East;               // 항법 East( Meter )
        flt64_t	North;              // 항법 North( Meter )
        flt64_t	Elevation;          // 항법 Elevation( Meter )

        // 플랫폼 자세
        flt64_t	Roll;               // 항법 Roll ( -PI ~ PI )
        flt64_t	Pitch;              // 항법 Pitch ( -PI ~ PI )
        flt64_t	Heading;            // 항법 Heading ( -PI ~ PI )

        // 선속도
        flt64_t	VelocityLinearX;    // 항법 X축 방향 선속도
        flt64_t	VelocityLinearY;	// 항법 Y축 방향 선속도
        flt64_t	VelocityLinearZ;	// 항법 Z축 방향 선속도

        // 각속도
        flt64_t	VelocityAngluarX;	// 항법 X축 방향 각속도
        flt64_t	VelocityAngluarY;	// 항법 Y축 방향 각속도
        flt64_t	VelocityAngluarZ;	// 항법 Z축 방향 각속도
} StNavigationDetail;

typedef struct
{
    flt64_t             SyncTime;   // 동기화 시간

    StNavigationDetail  NavigationDetail;

}  StAuto_Navigation;


typedef struct _StAuto_NavigationComm : public AUTONOMOUS::COMMLIB::Header, public StAuto_Navigation
{
    virtual void setFrameData(uint8_t* buff)
    {
        buff = deserializeData(buff, SyncTime);
        buff = deserializeData(buff, NavigationDetail.TimeStamp);
        std::for_each(NavigationDetail.Zone, NavigationDetail.Zone + 2, [&](int8_t& d)
        {
            buff = deserializeData(buff, d);
        });
        buff = deserializeData(buff, NavigationDetail.East);
        buff = deserializeData(buff, NavigationDetail.North);
        buff = deserializeData(buff, NavigationDetail.Elevation);
        buff = deserializeData(buff, NavigationDetail.Roll);
        buff = deserializeData(buff, NavigationDetail.Pitch);
        buff = deserializeData(buff, NavigationDetail.Heading);
        buff = deserializeData(buff, NavigationDetail.VelocityLinearX);
        buff = deserializeData(buff, NavigationDetail.VelocityLinearY);
        buff = deserializeData(buff, NavigationDetail.VelocityLinearZ);
        buff = deserializeData(buff, NavigationDetail.VelocityAngluarX);
        buff = deserializeData(buff, NavigationDetail.VelocityAngluarY);
        buff = deserializeData(buff, NavigationDetail.VelocityAngluarZ);
    }

    virtual void getFrameData(std::vector<uint8_t>& buff)
    {
        serializeData(buff, SyncTime);
        serializeData(buff, NavigationDetail.TimeStamp);
        std::for_each(NavigationDetail.Zone, NavigationDetail.Zone + 2, [&](int8_t d)
        {
            serializeData(buff, d);
        });
        serializeData(buff, NavigationDetail.East);
        serializeData(buff, NavigationDetail.North);
        serializeData(buff, NavigationDetail.Elevation);
        serializeData(buff, NavigationDetail.Roll);
        serializeData(buff, NavigationDetail.Pitch);
        serializeData(buff, NavigationDetail.Heading);
        serializeData(buff, NavigationDetail.VelocityLinearX);
        serializeData(buff, NavigationDetail.VelocityLinearY);
        serializeData(buff, NavigationDetail.VelocityLinearZ);
        serializeData(buff, NavigationDetail.VelocityAngluarX);
        serializeData(buff, NavigationDetail.VelocityAngluarY);
        serializeData(buff, NavigationDetail.VelocityAngluarZ);
    }

}  StAuto_NavigationComm;


}
}
}

#endif // AUTO_NAVIGATION_H
