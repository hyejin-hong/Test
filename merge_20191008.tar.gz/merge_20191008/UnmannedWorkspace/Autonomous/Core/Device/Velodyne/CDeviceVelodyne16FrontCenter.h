#ifndef CDEVICEVELODYNE16FRONTCENTER_H
#define CDEVICEVELODYNE16FRONTCENTER_H

#include "CVelodyneObject.h"

namespace AUTONOMOUS
{
namespace Device
{
namespace Velodyne
{

class CDeviceVelodyne16FrontCenter : public AUTONOMOUS::Device::Velodyne::CObserverVelodyneObject
{
public:
	CDeviceVelodyne16FrontCenter()
	: m_devVelodyne16FrontCenter(this)
	{
	}

	virtual ~CDeviceVelodyne16FrontCenter()
	{
	}

	virtual void OnVelodynePackFrontCenter(AUTONOMOUS::Device::Velodyne::StVelodynePacket* pVelodynePack) = 0;
	virtual void OnVelodyneStatusFrontCenter(AUTONOMOUS::Device::Velodyne::StVelodyneStatus* pVelodyneStatus) = 0;
    virtual void OnEMountFrontCenter(AUTONOMOUS::Device::Velodyne::StEMount* pEMount) = 0;

	AUTONOMOUS::Device::Velodyne::CVelodyneObject* GetDeviceVelodyne16FrontCenter() { return &m_devVelodyne16FrontCenter; }

private :
	AUTONOMOUS::Device::Velodyne::CVelodyneObject 	m_devVelodyne16FrontCenter;

	virtual void OnVelodynePack(AUTONOMOUS::Device::Velodyne::StVelodynePacket* pVelodynePack)
	{
		OnVelodynePackFrontCenter(pVelodynePack);
	}

	virtual void OnVelodyneStatus(AUTONOMOUS::Device::Velodyne::StVelodyneStatus* pVelodyneStatus)
	{
		OnVelodyneStatusFrontCenter(pVelodyneStatus);
	}

    virtual void OnEMount(AUTONOMOUS::Device::Velodyne::StEMount* pEMount)
    {
        OnEMountFrontCenter(pEMount);
    }
};

}
}
}

#endif /* CDEVICEVELODYNE16FRONTCENTER_H */
