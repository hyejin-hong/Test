#ifndef CPROXYESEND_LPPRESULT_H
#define CPROXYESEND_LPPRESULT_H

#include <Core/DevLib/Include/IO/CLogWriter/CLogWriter.h>

// ICD Data
#include "../../../Data/Autonomy/Send_LPPResult.h"

namespace AUTONOMOUS
{
namespace Interface
{
namespace Autonomy
{

class CProxySend_LPPResult
{
public :
    CProxySend_LPPResult();
    virtual ~CProxySend_LPPResult();

    virtual void OnSend_LPPResult(AUTONOMOUS::Data::Autonomy::StSend_LPPResultComm& data) = 0;

    // Log
    bool CreateLogProxySend_LPPResult(char* logName);
    void CloseLogProxySend_LPPResult();

private:
    std::vector<uint8_t>   m_vBuffProxySend_LPPResult;
protected:
    DevLib::IO::CLogWriter m_logProxySend_LPPResult;

    void _OnSend_LPPResult(AUTONOMOUS::Data::Autonomy::StSend_LPPResultComm& data);
};


}
}
}

#endif /* CPROXYESEND_LPPRESULT_H */
