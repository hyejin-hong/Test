#include "CStubAuto_ComponentStatus.h"

namespace AUTONOMOUS
{
namespace Interface
{
namespace Common
{

CStubAuto_ComponentStatus::CStubAuto_ComponentStatus()
{
    m_snStubAuto_ComponentStatus = 0;
}

CStubAuto_ComponentStatus::~CStubAuto_ComponentStatus()
{ 

}

bool CStubAuto_ComponentStatus::CreateLogStubAuto_ComponentStatus(char *logName)
{
    char fname[1024] = "";
    sprintf(fname, "./%s.Auto_ComponentStatus", logName);

    return m_logStubAuto_ComponentStatus.Create(fname);
}

void CStubAuto_ComponentStatus::CloseLogStubAuto_ComponentStatus()
{
    m_logStubAuto_ComponentStatus.Destroy();
}


}
}
}
