#include "CStubSensorData_LIDAR_RthetaFrontCenter.h"

namespace AUTONOMOUS
{
namespace Interface
{
namespace Sensor
{

CStubSensorData_LIDAR_RthetaFrontCenter::CStubSensorData_LIDAR_RthetaFrontCenter()
{
    m_snStubSensorData_LIDAR_RthetaFrontCenter = 0;
}

CStubSensorData_LIDAR_RthetaFrontCenter::~CStubSensorData_LIDAR_RthetaFrontCenter()
{ 

}

bool CStubSensorData_LIDAR_RthetaFrontCenter::CreateLogStubSensorData_LIDAR_RthetaFrontCenter(char *logName)
{
    char fname[1024] = "";
    sprintf(fname, "./%s.SensorData_LIDAR_RthetaFrontCenter", logName);

    return m_logStubSensorData_LIDAR_RthetaFrontCenter.Create(fname);
}

void CStubSensorData_LIDAR_RthetaFrontCenter::CloseLogStubSensorData_LIDAR_RthetaFrontCenter()
{
    m_logStubSensorData_LIDAR_RthetaFrontCenter.Destroy();
}


}
}
}
