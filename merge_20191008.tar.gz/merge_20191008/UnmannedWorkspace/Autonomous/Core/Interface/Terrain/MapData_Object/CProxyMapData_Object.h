#ifndef CPROXYEMAPDATA_OBJECT_H
#define CPROXYEMAPDATA_OBJECT_H

#include <Core/DevLib/Include/IO/CLogWriter/CLogWriter.h>

// ICD Data
#include "../../../Data/Terrain/MapData_Object.h"

namespace AUTONOMOUS
{
namespace Interface
{
namespace Terrain
{

class CProxyMapData_Object
{
public :
    CProxyMapData_Object();
    virtual ~CProxyMapData_Object();

    virtual void OnMapData_Object(AUTONOMOUS::Data::Terrain::StMapData_ObjectComm& data) = 0;

    // Log
    bool CreateLogProxyMapData_Object(char* logName);
    void CloseLogProxyMapData_Object();

private:
    std::vector<uint8_t>   m_vBuffProxyMapData_Object;
protected:
    DevLib::IO::CLogWriter m_logProxyMapData_Object;

    void _OnMapData_Object(AUTONOMOUS::Data::Terrain::StMapData_ObjectComm& data);
};


}
}
}

#endif /* CPROXYEMAPDATA_OBJECT_H */
