#include "CProxyAuto_UGVEStopRequest.h"

namespace AUTONOMOUS
{
namespace Interface
{
namespace Common
{

CProxyAuto_UGVEStopRequest::CProxyAuto_UGVEStopRequest()
{
    AUTONOMOUS::COMMLIB::CFW::GetInstance().RegisterSub(MSG_CODE_COMMON_AUTO_UGVESTOPREQUEST, &CProxyAuto_UGVEStopRequest::_OnAuto_UGVEStopRequest, this);
}

CProxyAuto_UGVEStopRequest::~CProxyAuto_UGVEStopRequest()
{

}

bool CProxyAuto_UGVEStopRequest::CreateLogProxyAuto_UGVEStopRequest(char *logName)
{
    char fname[1024] = "";
    sprintf(fname, "./%s.Auto_UGVEStopRequest", logName);

    return m_logProxyAuto_UGVEStopRequest.Create(fname);
}

void CProxyAuto_UGVEStopRequest::CloseLogProxyAuto_UGVEStopRequest()
{
    m_logProxyAuto_UGVEStopRequest.Destroy();
}

void CProxyAuto_UGVEStopRequest::_OnAuto_UGVEStopRequest(AUTONOMOUS::Data::Common::StAuto_UGVEStopRequestComm& data)
{
    OnAuto_UGVEStopRequest(data);
    if( m_logProxyAuto_UGVEStopRequest.IsRun() )
    {
        m_vBuffProxyAuto_UGVEStopRequest.clear();
        data.getFrameData(m_vBuffProxyAuto_UGVEStopRequest);
        m_logProxyAuto_UGVEStopRequest.WriteData(m_vBuffProxyAuto_UGVEStopRequest.data(), m_vBuffProxyAuto_UGVEStopRequest.size());
    }
}

}
}
}
