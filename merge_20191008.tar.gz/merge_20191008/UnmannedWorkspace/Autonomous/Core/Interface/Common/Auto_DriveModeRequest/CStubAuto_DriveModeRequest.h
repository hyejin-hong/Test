#ifndef CSTUBAUTO_DRIVEMODEREQUEST_H
#define CSTUBAUTO_DRIVEMODEREQUEST_H

#include <CFW.h>
#include <Core/DevLib/Include/IO/CLogWriter/CLogWriter.h>

// ICD Data
#include "../../../Data/Common/Auto_DriveModeRequest.h"

namespace AUTONOMOUS
{
namespace Interface
{
namespace Common
{

class CStubAuto_DriveModeRequest
{
public :
    CStubAuto_DriveModeRequest();
    virtual ~CStubAuto_DriveModeRequest();

    inline void WriteAuto_DriveModeRequest(AUTONOMOUS::Data::Common::StAuto_DriveModeRequestComm& data)
    {
        data.message_type   = MSG_TYPE_COMMON;
        data.message_ID     = MSG_CODE_COMMON_AUTO_DRIVEMODEREQUEST;
        data.QoS            = MSG_QOS_COMMON_AUTO_DRIVEMODEREQUEST;
        data.SN             = m_snStubAuto_DriveModeRequest++;

        AUTONOMOUS::COMMLIB::CFW::GetInstance().Send(data);

        if( m_logStubAuto_DriveModeRequest.IsRun() )
        {
            m_vBuffStubAuto_DriveModeRequest.clear();
            data.getFrameData(m_vBuffStubAuto_DriveModeRequest);
            m_logStubAuto_DriveModeRequest.WriteData(m_vBuffStubAuto_DriveModeRequest.data(), m_vBuffStubAuto_DriveModeRequest.size());
        }
    }

    // Log
    bool CreateLogStubAuto_DriveModeRequest(char* logName);
    void CloseLogStubAuto_DriveModeRequest();

private:
    std::vector<uint8_t>   m_vBuffStubAuto_DriveModeRequest;
    uint8_t                m_snStubAuto_DriveModeRequest;
protected:
    DevLib::IO::CLogWriter m_logStubAuto_DriveModeRequest;
};


}
}
}

#endif /* CSTUBAUTO_DRIVEMODEREQUEST_H */
