#ifndef CLANEDETECTOR_H
#define CLANEDETECTOR_H

#include <CViewImage/CViewImage.h>

#include <Core/Interface/Sensor/SensorData_Image/CProxySensorData_Image.h>
#include <Core/Interface/Common/Auto_DriveModeRequest/CProxyAuto_DriveModeRequest.h>
#include <Core/Interface/Common/Auto_ComponentStatus/CStubAuto_ComponentStatus.h>
#include <Core/Interface/Sensor/SensorData_LIDAR_RthetaFrontCenter/CProxySensorData_LIDAR_RthetaFrontCenter.h>
#include <Core/Interface/Terrain/Auto_PathRequest/CStubAuto_PathRequest.h>
#include <Core/DevLib/Include/Core/CElapsedTimer/CElapsedTimer.h>
#include <Core/DevLib/Include/Utility/CProcess.h>

#include <Core/DevLib/Include/Core/CEvent/CEvent.h>

#include "Algorithm/DetectCross.hpp"
#include "Algorithm/DetectLane.h"

class CLaneDetector
        : public DevLib::Utility::CProcess
        , public AUTONOMOUS::Interface::Sensor::CProxySensorData_Image
        , public AUTONOMOUS::Interface::Common::CStubAuto_ComponentStatus
        , public AUTONOMOUS::Interface::Sensor::CProxySensorData_LIDAR_RthetaFrontCenter
        , public AUTONOMOUS::Interface::Terrain::CStubAuto_PathRequest
{
public:
    CLaneDetector();

    // 프로그램 시작시 초기화 : 완료후 대기 모드 로 전
    virtual void OnPreCreate();

    // 작업 함수 호출
    virtual void OnRunning();

    // 종료를 위한 호출
    virtual void OnShutdown();

    // 현재 상태를 보고 하기 위한 타이머
    virtual void OnTimerReportStatus();

    // 키보드 입력
    virtual void OnCommand(char value);


    virtual void OnSensorData_Image(AUTONOMOUS::Data::Sensor::StSensorData_ImageComm& data);
    virtual void OnAuto_DriveModeRequest(AUTONOMOUS::Data::Common::StAuto_DriveModeRequestComm& data);
    virtual void OnSensorData_LIDAR_RthetaFrontCenter(AUTONOMOUS::Data::Sensor::StSensorData_LIDAR_RthetaComm& data);

    CDetectLane DL;

    DevLib::CEvent  m_eUpdate;
    AUTONOMOUS::Data::Sensor::StSensorData_ImageComm* m_imgData;
    AUTONOMOUS::Data::Sensor::StSensorData_ImageComm* m_imgDataBuff;

    Mat result_gpp_img;
};

#endif // CLANEDETECTOR_H
