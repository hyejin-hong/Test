#ifndef CVIEWIMAGE_H
#define CVIEWIMAGE_H

#include <QWidget>
#include <QPainter>
#include <QImage>

class CViewImage : public QWidget
{
    Q_OBJECT
public:
    explicit CViewImage(QWidget *parent = 0, const char* title = "ImageWindow");

    void ShowImage(QImage& img);
    void ShowImage(unsigned char* pImage, int width, int height, int nChannel = 3);

signals:
    void ShowWindow();
    void Redraw();

protected slots:
    void DrawImage();

protected :
    QImage  m_img;
    void paintEvent(QPaintEvent* event) Q_DECL_OVERRIDE;
};

#endif // CVIEWIMAGE_H
