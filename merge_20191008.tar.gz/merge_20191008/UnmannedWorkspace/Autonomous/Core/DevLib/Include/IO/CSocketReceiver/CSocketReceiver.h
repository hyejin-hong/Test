#ifndef CSOCKETRECEIVER_H
#define CSOCKETRECEIVER_H

#include "../../Core/CThread/CThread.h"
#include "../CSocket/CSocket.h"

namespace DevLib
{
namespace IO
{

class CObserverReceiver
{
public :
    CObserverReceiver(){}
    virtual ~CObserverReceiver();

    virtual void OnReceived(DevLib::IO::CSocket* pClient);
};

class CSocketReceiver : public DevLib::CThread, public DevLib::IO::CSocket
{
public:
    CSocketReceiver(int sockFD = -1);
    virtual ~CSocketReceiver();

    void SetObserver(CObserverReceiver* pObserver);

    virtual void OnReceive();
    virtual void OnClosed();
    virtual void OnTimeOut();

private:
    virtual void Run();
    CObserverReceiver* m_pObserverReceiver;
};

}
}
#endif /* CSOCKETRECEIVER_H */
