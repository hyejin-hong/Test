#include "CProxyMapData_ProbabilityTraversabilityNDT.h"

namespace AUTONOMOUS
{
namespace Interface
{
namespace Terrain
{

CProxyMapData_ProbabilityTraversabilityNDT::CProxyMapData_ProbabilityTraversabilityNDT()
{
    AUTONOMOUS::COMMLIB::CFW::GetInstance().RegisterSub(MSG_CODE_TERRAIN_MAPDATA_PROBABILITYTRAVERSABILITYNDT, &CProxyMapData_ProbabilityTraversabilityNDT::_OnMapData_ProbabilityTraversabilityNDT, this);
}

CProxyMapData_ProbabilityTraversabilityNDT::~CProxyMapData_ProbabilityTraversabilityNDT()
{

}

bool CProxyMapData_ProbabilityTraversabilityNDT::CreateLogProxyMapData_ProbabilityTraversabilityNDT(char *logName)
{
    char fname[1024] = "";
    sprintf(fname, "./%s.MapData_ProbabilityTraversabilityNDT", logName);

    return m_logProxyMapData_ProbabilityTraversabilityNDT.Create(fname);
}

void CProxyMapData_ProbabilityTraversabilityNDT::CloseLogProxyMapData_ProbabilityTraversabilityNDT()
{
    m_logProxyMapData_ProbabilityTraversabilityNDT.Destroy();
}

void CProxyMapData_ProbabilityTraversabilityNDT::_OnMapData_ProbabilityTraversabilityNDT(AUTONOMOUS::Data::Terrain::StMapData_ProbabilityComm& data)
{
    OnMapData_ProbabilityTraversabilityNDT(data);
    if( m_logProxyMapData_ProbabilityTraversabilityNDT.IsRun() )
    {
        m_vBuffProxyMapData_ProbabilityTraversabilityNDT.clear();
        data.getFrameData(m_vBuffProxyMapData_ProbabilityTraversabilityNDT);
        m_logProxyMapData_ProbabilityTraversabilityNDT.WriteData(m_vBuffProxyMapData_ProbabilityTraversabilityNDT.data(), m_vBuffProxyMapData_ProbabilityTraversabilityNDT.size());
    }
}

}
}
}
