#include "CProxyAuto_PathResponse.h"

namespace AUTONOMOUS
{
namespace Interface
{
namespace Terrain
{

CProxyAuto_PathResponse::CProxyAuto_PathResponse()
{
    AUTONOMOUS::COMMLIB::CFW::GetInstance().RegisterSub(MSG_CODE_TERRAIN_AUTO_PATHRESPONSE, &CProxyAuto_PathResponse::_OnAuto_PathResponse, this);
}

CProxyAuto_PathResponse::~CProxyAuto_PathResponse()
{

}

bool CProxyAuto_PathResponse::CreateLogProxyAuto_PathResponse(char *logName)
{
    char fname[1024] = "";
    sprintf(fname, "./%s.Auto_PathResponse", logName);

    return m_logProxyAuto_PathResponse.Create(fname);
}

void CProxyAuto_PathResponse::CloseLogProxyAuto_PathResponse()
{
    m_logProxyAuto_PathResponse.Destroy();
}

void CProxyAuto_PathResponse::_OnAuto_PathResponse(AUTONOMOUS::Data::Terrain::StAuto_PathResponseComm& data)
{
    OnAuto_PathResponse(data);
    if( m_logProxyAuto_PathResponse.IsRun() )
    {
        m_vBuffProxyAuto_PathResponse.clear();
        data.getFrameData(m_vBuffProxyAuto_PathResponse);
        m_logProxyAuto_PathResponse.WriteData(m_vBuffProxyAuto_PathResponse.data(), m_vBuffProxyAuto_PathResponse.size());
    }
}

}
}
}
