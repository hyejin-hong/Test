#ifndef COMMON_H
#define COMMON_H

namespace AUTONOMOUS
{
// 기본 자료형 재정의
typedef char			int8_t;
typedef short			int16_t;
typedef int                     int32_t;
typedef float			flt32_t;
typedef double			flt64_t;
typedef long 			int64_t;

typedef unsigned char		uint8_t;
typedef unsigned short		uint16_t;
typedef unsigned int		uint32_t;
typedef unsigned long 		uint64_t;

// Message Info
enum eMessageType
{
    MSG_TYPE_UNMANNED   = 0x28, // 자율(체계 기준)
    MSG_TYPE_COMMON     = 0x29, // 자율 공통
    MSG_TYPE_SENSOR     = 0x2A, // 센서신호처리
    MSG_TYPE_TERRAIN    = 0x2B, // 환경인식
    MSG_TYPE_AUTONOMY   = 0x2C, // 자율판단
    MSG_TYPE_ANALYSIS   = 0x2D  // 로깅/성능 분석
};

enum eMessageCode
{
    // Common
    MSG_CODE_COMMON_AUTO_NAVIGATION                         = 0x10,
    MSG_CODE_COMMON_AUTO_DRIVECONTROL                       = 0X11,
    MSG_CODE_COMMON_AUTO_UGVESTOPREQUEST                    = 0X92,
    MSG_CODE_COMMON_AUTO_UGVSHUTDOWNREQUEST                 = 0X93,
    MSG_CODE_COMMON_AUTO_UGVERASEREQUEST                    = 0X94,
    MSG_CODE_COMMON_AUTO_UGVERASERESPONSE                   = 0X95,
    MSG_CODE_COMMON_AUTO_COMPONENTSTATUS                    = 0X16,
    MSG_CODE_COMMON_AUTO_DRIVEMODEREQUEST                   = 0X97,
    MSG_CODE_COMMON_AUTO_REMOTECONTROL                      = 0X18,

    // Sensor
    MSG_CODE_SENSOR_SENSORDATA_LIDAR_RTHETAFRONTCENTER      = 0X21,
    MSG_CODE_SENSOR_SENSORDATA_LIDAR_RTHETAFRONTLEFT        = 0X22,
    MSG_CODE_SENSOR_SENSORDATA_LIDAR_RTHETAFRONTRIGHT       = 0X23,
    MSG_CODE_SENSOR_SENSORDATA_LIDAR_RTHETAREARCENTER       = 0X24,
    MSG_CODE_SENSOR_SENSORDATA_LIDAR_RTHETA2DLIDAR          = 0X25,
    MSG_CODE_SENSOR_SENSORDATA_IMAGE                        = 0X26,
    MSG_CODE_SENSOR_SENSORDATA_FMCWRADAR                    = 0X27,

    // Terrian
    MSG_CODE_TERRAIN_MAPDATA_PROBABILITYTRAVERSABILITY      = 0X31,
    MSG_CODE_TERRAIN_MAPDATA_PROBABILITYTRAVERSABILITYNDT   = 0X32,
    MSG_CODE_TERRAIN_MAPDATA_PROBABILITYFUSED               = 0X33,
    MSG_CODE_TERRAIN_MAPDATA_OBJECT                         = 0X34,
    MSG_CODE_TERRAIN_MAPDATA_PERCEPTIONRESULT               = 0X35,
    MSG_CODE_TERRAIN_AUTO_PATHREQUEST                       = 0X36,
    MSG_CODE_TERRAIN_AUTO_PATHRESPONSE                      = 0XC7,
    MSG_CODE_TERRAIN_AUTO_OBSTACLE                          = 0X38,

    // Autonomy
    MSG_CODE_AUTONOMY_SEND_GLOBALPATH                       = 0XC1,
    MSG_CODE_AUTONOMY_SEND_LPPRESULT                        = 0X42,
    MSG_CODE_AUTONOMY_AUTO_DRIVECONTROLAUTONOMY             = 0X43,
    MSG_CODE_AUTONOMY_AUTO_COLLISIONALARM                   = 0XC4,
    MSG_CODE_AUTONOMY_AUTO_CONTROLREQUEST                   = 0X19,

    // Analysis
    MSG_CODE_ANALYSIS_AUTO_LOG_CONTROL                      = 0xE1
};

enum eMessageQoS
{
    MSG_QOS_COMMON_AUTO_NAVIGATION                          = 0x48,
    MSG_QOS_COMMON_AUTO_DRIVEMODEREQUEST                    = 0X25,
    MSG_QOS_COMMON_AUTO_REMOTECONTROL                       = 0X4B,
    MSG_QOS_COMMON_AUTO_DRIVECONTROL                        = 0X4B,
    MSG_QOS_COMMON_AUTO_UGVESTOPREQUEST                     = 0X6E,
    MSG_QOS_COMMON_AUTO_UGVSHUTDOWNREQUEST                  = 0X25,
    MSG_QOS_COMMON_AUTO_UGVERASEREQUEST                     = 0X25,
    MSG_QOS_COMMON_AUTO_UGVERASERESPONSE                    = 0X25,
    MSG_QOS_COMMON_AUTO_COMPONENTSTATUS                     = 0X24,
    MSG_QOS_SENSOR_SENSORDATA_LIDAR_RTHETAFRONTCENTER       = 0X24,
    MSG_QOS_SENSOR_SENSORDATA_LIDAR_RTHETAFRONTLEFT         = 0X24,
    MSG_QOS_SENSOR_SENSORDATA_LIDAR_RTHETAFRONTRIGHT        = 0X24,
    MSG_QOS_SENSOR_SENSORDATA_LIDAR_RTHETAREARCENTER        = 0X24,
    MSG_QOS_SENSOR_SENSORDATA_LIDAR_RTHETA2DLIDAR           = 0X24,
    MSG_QOS_SENSOR_SENSORDATA_IMAGE                         = 0X24,
    MSG_QOS_SENSOR_SENSORDATA_FMCWRADAR                     = 0X24,
    MSG_QOS_TERRAIN_MAPDATA_PROBABILITY                     = 0X24,
    MSG_QOS_TERRAIN_MAPDATA_PROBABILITYTRAVERSABILITY       = 0X24,
    MSG_QOS_TERRAIN_MAPDATA_PROBABILITYTRAVERSABILITYNDT    = 0X24,
    MSG_QOS_TERRAIN_MAPDATA_PROBABILITYFUSED                = 0X24,
    MSG_QOS_TERRAIN_MAPDATA_OBJECT                          = 0X24,
    MSG_QOS_TERRAIN_MAPDATA_PERCEPTIONRESULT                = 0X24,
    MSG_QOS_TERRAIN_AUTO_PATHREQUEST                        = 0X24,
    MSG_QOS_TERRAIN_AUTO_PATHRESPONSE                       = 0X24,
    MSG_QOS_TERRAIN_AUTO_OBSTACLE                           = 0X4B,
    MSG_QOS_AUTONOMY_SEND_GLOBALPATH                        = 0X91,
    MSG_QOS_AUTONOMY_SEND_LPPRESULT                         = 0X24,
    MSG_QOS_AUTONOMY_AUTO_DRIVECONTROLAUTONOMY              = 0X24,
    MSG_QOS_AUTONOMY_AUTO_COLLISIONALARM                    = 0X6D,
    MSG_QOS_AUTONOMY_AUTO_CONTROLREQUEST                    = 0X6D,
    MSG_QOS_ANALYSIS_AUTO_LOG_CONTROL                       = 0x91
};


// Target Info
typedef struct
{
    uint8_t	Unit 		: 3;
    uint8_t	Component	: 5;
} StTargetInfo;

// Common Mode
typedef struct _StMode
{
    union
    {
        struct
        {
            // 주행 모드
            // 0 : 대기
            // 1 : 원격주행
            // 3 : 수동주행
            // 4 : 경로주행
            // 5 : 종속주행
            // 6 : 자율복귀
            uint8_t Drive  : 3;

            uint8_t Reserved : 5;
        } ModeDetail;
        uint8_t Mode;
    };
} StMode;

// Common Gear
typedef struct _StGear
{
    union
    {
        struct
        {
            // 변속기
            // 0 : 주차
            // 1 : 중립
            // 2 : 전진
            // 4 : 후진
            // 8 : 제자리 선회
            uint8_t Gear        : 4;
            uint8_t Reserved    : 4;
        } GearDetail;
        uint8_t Gear;
    };
} StGear;

// Autonomy GPP
typedef struct _StGPP
{
    int8_t      Zone[2];            // UTM Zone 정보
    flt64_t     North;              // North 좌표
    flt64_t     East;               // East 좌표
    uint16_t    CommandVelocity;    // 목표 속도
} StGPP;

}

#endif // COMMON_H
